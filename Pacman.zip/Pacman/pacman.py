# """
# Pacman.py
# 
# This module contains the implementation of the classic Pacman game along with the logic to manage game states and rules governing the interactions between Pacman and ghosts. The structure is divided into three main sections:
# 
# 1. **GameState Interface**: This component defines the `GameState` class, which encapsulates the complete state of the game, including the positions of Pacman and ghosts, food locations, capsules, scores, and win/lose conditions. Various accessor methods enable agents to interact with and reason about the game state without direct access to the underlying data structure.
# 
#    Key Methods:
#    - `getLegalActions(agentIndex=0)`: Returns a list of legal actions for the specified agent (Pacman or ghost).
#    - `generateSuccessor(agentIndex, action)`: Produces the next game state after the specified agent performs the action.
#    - `getPacmanState()`: Retrieves the state of Pacman.
#    - `getGhostStates()`: Returns the states of all ghosts.
#    - `getScore()`: Gets the current score.
#    - `getCapsules()`: Provides the current locations of capsules on the board.
#    - `isWin() / isLose()`: Checks for winning or losing conditions.
# 
# 2. **Game Rules**: This section encapsulates the core game rules including how Pacman and ghosts interact with their environment. The classes `ClassicGameRules`, `PacmanRules`, and `GhostRules` define the mechanics for moving agents, detecting collisions, and managing states related to game progression and scoring.
# 
#    Key Classes:
#    - `ClassicGameRules`: Manages game flow, initializes the game, and processes win/lose conditions.
#    - `PacmanRules`: Contains logic for Pacman's movements and actions, including consuming food and capsules.
#    - `GhostRules`: Outlines the operational rules for ghosts, including movement restrictions and collision checks with Pacman.
# 
# 3. **Game Framework**: This section provides the framework required to start and run the game. It handles input parameters from the command line for game configuration (e.g., number of games, layout files, agent types, etc.) and integrates these into a runnable game instance.
# 
#    Key Functions:
#    - `readCommand(argv)`: Parses command-line arguments and sets up configurations for the game.
#    - `runGames(layout, pacman, ghosts, display, ...)`: Initializes and runs multiple game instances based on provided parameters.
#    - `replayGame(layout, actions, display)`: Allows replaying a recorded game from a previously saved state.
# 
# Dependencies:
# This module relies on several external components such as `Actions`, `Directions`, and utility functions like `nearestPoint` and `manhattanDistance`, which are defined outside this file.
# 
# Usage:
# To run the game, execute this script from the command line with the command:
# `python pacman.py`
# The keys 'a', 's', 'd', and 'w' (or arrow keys) control Pacman's movement.
# 
# This module serves as the backbone for implementing agent-based decision-making in the Pacman game environment, providing a structured and modular approach to game logic and state management.
# """

"""
Pacman.py holds the logic for the classic pacman game along with the main
code to run a game.  This file is divided into three sections:

  (i)  Your interface to the pacman world:
          Pacman is a complex environment.  You probably don't want to
          read through all of the code we wrote to make the game runs
          correctly.  This section contains the parts of the code
          that you will need to understand in order to complete the
          project.  There is also some code in game.py that you should
          understand.

  (ii)  The hidden secrets of pacman:
          This section contains all of the logic code that the pacman
          environment uses to decide who can move where, who dies when
          things collide, etc.  You shouldn't need to read this section
          of code, but you can if you want.

  (iii) Framework to start a game:
          The final section contains the code for reading the command
          you use to set up the game, then starting up a new game, along with
          linking in all the external parts (agent functions, graphics).
          Check this section out to see all the options available to you.

To play your first game, type 'python pacman.py' from the command line.
The keys are 'a', 's', 'd', and 'w' to move (or arrow keys).  Have fun!
"""
from game import GameStateData
from game import Game
from game import Directions
from game import Actions
from util import nearestPoint
from util import manhattanDistance
import util, layout
import sys, types, time, random, os


class GameState:
    """
    A GameState specifies the full game state, including the food, capsules,
    agent configurations and score changes.

    GameStates are used by the Game object to capture the actual state of the game and
    can be used by agents to reason about the game.

    Much of the information in a GameState is stored in a GameStateData object.  We
    strongly suggest that you access that data via the accessor methods below rather
    than referring to the GameStateData object directly.

    Note that in classic Pacman, Pacman is always agent 0.
    """
    explored = set()

    def getAndResetExplored():
        """
    ""\"
    Retrieves the set of explored game states and then clears the explored set.

    This function is used to obtain the states that have been previously explored
    during the game and resets the internal state for future exploration.

    Returns:
        Set[GameState]: A copy of the previously explored game states.

    Usage Example:
        >>> explored_states = GameState.getAndResetExplored()
        >>> print(explored_states)  # Output: set of GameState objects that were explored
    """
        tmp = GameState.explored.copy()
        GameState.explored = set()
        return tmp
    getAndResetExplored = staticmethod(getAndResetExplored)

    def getLegalActions(self, agentIndex=0):
        """
        Returns the legal actions for the agent specified.
        """
        if self.isWin() or self.isLose():
            return []
        if agentIndex == 0:
            return PacmanRules.getLegalActions(self)
        else:
            return GhostRules.getLegalActions(self, agentIndex)

    def generateSuccessor(self, agentIndex, action):
        """
        Returns the successor state after the specified agent takes the action.
        """
        if self.isWin() or self.isLose():
            raise Exception("Can't generate a successor of a terminal state.")
        state = GameState(self)
        if agentIndex == 0:
            state.data._eaten = [(False) for i in range(state.getNumAgents())]
            PacmanRules.applyAction(state, action)
        else:
            GhostRules.applyAction(state, action, agentIndex)
        if agentIndex == 0:
            state.data.scoreChange += -TIME_PENALTY
        else:
            GhostRules.decrementTimer(state.data.agentStates[agentIndex])
        GhostRules.checkDeath(state, agentIndex)
        state.data._agentMoved = agentIndex
        state.data.score += state.data.scoreChange
        GameState.explored.add(self)
        GameState.explored.add(state)
        return state

    def getLegalPacmanActions(self):
        """
    ""\"
    Retrieves the legal actions available to Pacman in the current game state.

    This function calls the general method for getting legal actions but
    specifies that the agent in question is Pacman (agent index 0).

    Parameters:
        None

    Returns:
        List[str]: A list of legal action strings that Pacman can take in the current state.
    
    Usage Example:
        >>> legal_actions = game_state.getLegalPacmanActions()
        >>> print(legal_actions)  # Output: ['North', 'South', 'East', 'West'], depending on the current state
    """
        return self.getLegalActions(0)

    def generatePacmanSuccessor(self, action):
        """
        Generates the successor state after the specified pacman move
        """
        return self.generateSuccessor(0, action)

    def getPacmanState(self):
        """
        Returns an AgentState object for pacman (in game.py)

        state.pos gives the current position
        state.direction gives the travel vector
        """
        return self.data.agentStates[0].copy()

    def getPacmanPosition(self):
        """
    ""\"
    Retrieves the current position of Pacman in the game state.

    This function accesses the state data to obtain the coordinates of 
    Pacman's current location on the game board.

    Parameters:
        None

    Returns:
        Tuple[float, float]: A tuple containing the (x, y) coordinates of Pacman's position.

    Usage Example:
        >>> position = game_state.getPacmanPosition()
        >>> print(position)  # Output: (5.0, 6.0), representing Pacman's current coordinates
    """
        return self.data.agentStates[0].getPosition()

    def getGhostStates(self):
        """
    ""\"
    Retrieves the states of all ghosts in the current game state.

    This function returns a list of agent state objects for each ghost in the game, 
    which contain information such as their positions and potential actions.

    Parameters:
        None

    Returns:
        List[AgentState]: A list of AgentState objects representing the states of each ghost.

    Usage Example:
        >>> ghost_states = game_state.getGhostStates()
        >>> print(ghost_states)  # Output: [<AgentState object>, <AgentState object>, ...], representing each ghost's state
    """
        return self.data.agentStates[1:]

    def getGhostState(self, agentIndex):
        """
    ""\"
    Retrieves the state of a specific ghost agent in the current game state.

    This function allows access to the properties of the specified ghost,
    including its position and any other relevant attributes.

    Parameters:
        agentIndex (int): The index of the ghost agent whose state is to be retrieved.
                          This index must be greater than 0 and less than the total
                          number of agents in the game.

    Returns:
        AgentState: The AgentState object corresponding to the specified ghost agent.

    Usage Example:
        >>> ghost_state = game_state.getGhostState(1)
        >>> print(ghost_state)  # Output: <AgentState object>, representing the state of the ghost at index 1
    """
        if agentIndex == 0 or agentIndex >= self.getNumAgents():
            raise Exception('Invalid index passed to getGhostState')
        return self.data.agentStates[agentIndex]

    def getGhostPosition(self, agentIndex):
        """
    ""\"
    Retrieves the current position of a specific ghost agent in the game state.

    This function allows access to the (x, y) coordinates of the specified ghost's
    position on the game board.

    Parameters:
        agentIndex (int): The index of the ghost agent whose position is to be retrieved.
                          This index must be greater than 0, as index 0 is reserved for Pacman.

    Returns:
        Tuple[float, float]: A tuple containing the (x, y) coordinates of the specified ghost's position.

    Usage Example:
        >>> ghost_position = game_state.getGhostPosition(1)
        >>> print(ghost_position)  # Output: (3.0, 4.0), representing the ghost's current coordinates
    """
        if agentIndex == 0:
            raise Exception("Pacman's index passed to getGhostPosition")
        return self.data.agentStates[agentIndex].getPosition()

    def getGhostPositions(self):
        """
    ""\"
    Retrieves the positions of all ghost agents in the current game state.

    This function returns a list of tuples, where each tuple contains the (x, y) coordinates
    of each ghost's position on the game board.

    Parameters:
        None

    Returns:
        List[Tuple[float, float]]: A list of tuples, with each tuple representing the (x, y)
        coordinates of a ghost's position.

    Usage Example:
        >>> ghost_positions = game_state.getGhostPositions()
        >>> print(ghost_positions)  # Output: [(3.0, 4.0), (5.0, 6.0), ...], representing the positions of all ghosts
    """
        return [s.getPosition() for s in self.getGhostStates()]

    def getNumAgents(self):
        """
    ""\"
    Retrieves the total number of agents in the current game state.

    This function counts and returns the number of agents, which includes both Pacman and
    all ghost agents present in the game.

    Parameters:
        None

    Returns:
        int: The total number of agents in the game, including Pacman and ghosts.

    Usage Example:
        >>> num_agents = game_state.getNumAgents()
        >>> print(num_agents)  # Output: 5, if there are 1 Pacman and 4 ghosts
    """
        return len(self.data.agentStates)

    def getScore(self):
        """
    ""\"
    Retrieves the current score of the game.

    This function returns the score accumulated by Pacman, which is influenced by factors
    such as food consumption, capsule consumption, and penalties for losing.

    Parameters:
        None

    Returns:
        float: The current score of the game as a floating-point number.

    Usage Example:
        >>> current_score = game_state.getScore()
        >>> print(current_score)  # Output: 120.0, representing Pacman's current score
    """
        return float(self.data.score)

    def getCapsules(self):
        """
        Returns a list of positions (x,y) of the remaining capsules.
        """
        return self.data.capsules

    def getNumFood(self):
        """
    ""\"
    Retrieves the number of food pellets remaining in the game.

    This function counts the remaining food items on the board, which Pacman can consume
    to increase his score. The count is updated whenever food is eaten.

    Parameters:
        None

    Returns:
        int: The total number of food pellets still available in the game.

    Usage Example:
        >>> num_food = game_state.getNumFood()
        >>> print(num_food)  # Output: 10, indicating that there are 10 food pellets remaining
    """
        return self.data.food.count()

    def getFood(self):
        """
        Returns a Grid of boolean food indicator variables.

        Grids can be accessed via list notation, so to check
        if there is food at (x,y), just call

        currentFood = state.getFood()
        if currentFood[x][y] == True: ...
        """
        return self.data.food

    def getWalls(self):
        """
        Returns a Grid of boolean wall indicator variables.

        Grids can be accessed via list notation, so to check
        if there is a wall at (x,y), just call

        walls = state.getWalls()
        if walls[x][y] == True: ...
        """
        return self.data.layout.walls

    def hasFood(self, x, y):
        """
    ""\"
    Checks whether food is present at a specified location on the game board.

    This function determines if there is a food pellet at the given (x, y) coordinates.

    Parameters:
        x (int): The x-coordinate of the position to check for food.
        y (int): The y-coordinate of the position to check for food.

    Returns:
        bool: True if there is food at the specified position, False otherwise.

    Usage Example:
        >>> is_food_present = game_state.hasFood(5, 6)
        >>> print(is_food_present)  # Output: True, if there is food at position (5, 6)
    """
        return self.data.food[x][y]

    def hasWall(self, x, y):
        """
    ""\"
    Checks whether there is a wall present at a specified location on the game board.

    This function determines if the specified (x, y) coordinates are blocked by a wall.

    Parameters:
        x (int): The x-coordinate of the position to check for a wall.
        y (int): The y-coordinate of the position to check for a wall.

    Returns:
        bool: True if there is a wall at the specified position, False otherwise.

    Usage Example:
        >>> is_wall_present = game_state.hasWall(3, 4)
        >>> print(is_wall_present)  # Output: True, if there is a wall at position (3, 4)
    """
        return self.data.layout.walls[x][y]

    def isLose(self):
        """
    ""\"
    Checks if the current game state represents a losing condition for Pacman.

    This function determines whether Pacman has lost the game, which occurs
    when he collides with a ghost that is not scared.

    Parameters:
        None

    Returns:
        bool: True if the game state is a loss for Pacman, False otherwise.

    Usage Example:
        >>> lost_game = game_state.isLose()
        >>> print(lost_game)  # Output: True, if Pacman has lost the game
    """
        return self.data._lose

    def isWin(self):
        """
    ""\"
    Checks if the current game state represents a winning condition for Pacman.

    This function determines whether Pacman has won the game, which occurs
    when all the food pellets on the board have been consumed.

    Parameters:
        None

    Returns:
        bool: True if the game state is a win for Pacman, False otherwise.

    Usage Example:
        >>> won_game = game_state.isWin()
        >>> print(won_game)  # Output: True, if Pacman has won the game
    """
        return self.data._win

    def __init__(self, prevState=None):
        """
        Generates a new state by copying information from its predecessor.
        """
        if prevState != None:
            self.data = GameStateData(prevState.data)
        else:
            self.data = GameStateData()

    def deepCopy(self):
        """
    ""\"
    Creates a deep copy of the current game state.

    This function generates a new instance of the game state that is a complete,
    independent copy of the original. This is useful for preserving the state at
    a given point in time while allowing for further state changes without
    affecting the original.

    Parameters:
        None

    Returns:
        GameState: A new GameState object that is a deep copy of the current state.

    Usage Example:
        >>> copied_state = game_state.deepCopy()
        >>> print(copied_state)  # Output: A new GameState object that mirrors the original
    """
        state = GameState(self)
        state.data = self.data.deepCopy()
        return state

    def __eq__(self, other):
        """
        Allows two states to be compared.
        """
        return hasattr(other, 'data') and self.data == other.data

    def __hash__(self):
        """
        Allows states to be keys of dictionaries.
        """
        return hash(self.data)

    def __str__(self):
        """
    ""\"
    Returns a string representation of the current game state.

    This function generates a human-readable string that summarizes the key
    attributes of the game state, including scores, positions of agents,
    and other relevant information. It is useful for debugging and logging
    purposes.

    Parameters:
        None

    Returns:
        str: A string representation of the current game state.

    Usage Example:
        >>> state_description = str(game_state)
        >>> print(state_description)  # Output: A string summarizing the game state attributes
    """
        return str(self.data)

    def initialize(self, layout, numGhostAgents=1000):
        """
        Creates an initial game state from a layout array (see layout.py).
        """
        self.data.initialize(layout, numGhostAgents)


SCARED_TIME = 40
COLLISION_TOLERANCE = 0.7
TIME_PENALTY = 1


class ClassicGameRules:
    """
    These game rules manage the control flow of a game, deciding when
    and how the game starts and ends.
    """

    def __init__(self, timeout=30):
        """
    ""\"
    Initializes a new instance of the GameState class.

    The constructor creates a game state, optionally based on a predecessor state.
    If a predecessor state is provided, the new instance is initialized by copying
    the data from the existing state. Otherwise, a new game state is created with
    default values.

    Parameters:
        prevState (GameState, optional): A GameState object that serves as the 
                                          predecessor state from which to copy data. 
                                          If None, initializes a new GameState with
                                          default settings.

    Returns:
        None: This function does not return a value, but initializes the instance
              attributes for the game state.

    Usage Example:
        >>> new_state = GameState()  # Initializes a new game state
        >>> previous_state = GameState()  # Initializes another game state
        >>> copied_state = GameState(previous_state)  # Initializes a state based on the previous one
    """
        self.timeout = timeout

    def newGame(self, layout, pacmanAgent, ghostAgents, display, quiet=
        False, catchExceptions=False):
        """
    ""\"
    Initializes a new game with the specified layout and agents.

    This function sets up a new game instance based on the provided layout,
    Pacman agent, ghost agents, and display options. It configures the initial
    state of the game and prepares it for play.

    Parameters:
        layout (Layout): The layout object that defines the game board structure,
                         including walls, food, and capsules.
        pacmanAgent (Agent): The agent object representing Pacman that controls
                             Pacman's actions during the game.
        ghostAgents (List[Agent]): A list of agent objects representing the ghosts
                                    that will interact with Pacman.
        display (Display): The display object responsible for rendering the game
                           graphics or text output.
        quiet (bool, optional): A flag indicating whether to suppress output for
                                quiet mode. Defaults to False.
        catchExceptions (bool, optional): A flag indicating whether to enable
                                           exception handling during the game.
                                           Defaults to False.

    Returns:
        Game: A new Game object that is initialized with the provided layout,
              agents, and display settings.

    Usage Example:
        >>> layout = getLayout('mediumClassic')  # Get the game layout
        >>> pacman_agent = PacmanAgent()  # Create a Pacman agent
        >>> ghost_agents = [GhostAgent(i) for i in range(4)]  # Create ghost agents
        >>> display = GraphicsDisplay()  # Set the display
        >>> game = newGame(layout, pacman_agent, ghost_agents, display)  # Start a new game
    """
        agents = [pacmanAgent] + ghostAgents[:layout.getNumGhosts()]
        initState = GameState()
        initState.initialize(layout, len(ghostAgents))
        game = Game(agents, display, self, catchExceptions=catchExceptions)
        game.state = initState
        self.initialState = initState.deepCopy()
        self.quiet = quiet
        return game

    def process(self, state, game):
        """
        Checks to see whether it is time to end the game.
        """
        if state.isWin():
            self.win(state, game)
        if state.isLose():
            self.lose(state, game)

    def win(self, state, game):
        """
    ""\"
    Handles the logic for the winning condition of the game.

    This function is called when the game state indicates that Pacman has won.
    It performs necessary actions such as notifying the player of their victory
    and marking the game as over.

    Parameters:
        state (GameState): The current game state that is being evaluated for a win.
        game (Game): The Game object managing the overall game flow and state.

    Returns:
        None: This function does not return a value but updates the game state
              to reflect a win.

    Usage Example:
        >>> rules.win(current_state, current_game)  # Call win function when Pacman wins
    """
        if not self.quiet:
            print('Pacman emerges victorious! Score: %d' % state.data.score)
        game.gameOver = True

    def lose(self, state, game):
        """
    ""\"
    Handles the logic for the losing condition of the game.

    This function is called when the game state indicates that Pacman has lost.
    It executes necessary actions such as notifying the player of their defeat
    and updating the game state to mark it as over.

    Parameters:
        state (GameState): The current game state that is being evaluated for a loss.
        game (Game): The Game object responsible for managing the overall game state and flow.

    Returns:
        None: This function does not return a value but modifies the game state
              to indicate that Pacman has lost.

    Usage Example:
        >>> rules.lose(current_state, current_game)  # Call lose function when Pacman loses
    """
        if not self.quiet:
            print('Pacman died! Score: %d' % state.data.score)
        game.gameOver = True

    def getProgress(self, game):
        """
    ""\"
    Computes the progress of the game as a ratio of remaining food to the initial amount.

    This function calculates and returns a float value representing the current progress of the game,
    which is defined as the ratio of the number of food pellets remaining to the total number of food
    pellets present at the start of the game. This is used to evaluate how close Pacman is to winning.

    Parameters:
        game (Game): The Game object for which the progress is being computed.

    Returns:
        float: A float value between 0 and 1 representing the fraction of food remaining 
               in the game. A value of 1 indicates no food has been eaten, while a value of 0 indicates all food has been consumed.

    Usage Example:
        >>> progress = rules.getProgress(current_game)  # Get the current progress of the game
        >>> print(progress)  # Output: 0.75, indicating that 75% of the food remains
    """
        return float(game.state.getNumFood()) / self.initialState.getNumFood()

    def agentCrash(self, game, agentIndex):
        """
    ""\"
    Handles the scenario when an agent crashes during the game.

    This function is invoked when an agent, either Pacman or a ghost, encounters a crash scenario.
    It prints a notification indicating which agent crashed.

    Parameters:
        game (Game): The Game object that is currently running, which contains the state and data of the game.
        agentIndex (int): The index of the agent that crashed. A value of 0 corresponds to Pacman,
                          while other values correspond to ghost agents.

    Returns:
        None: This function does not return a value but executes side effects such as logging the crash.

    Usage Example:
        >>> rules.agentCrash(current_game, 0)  # Notify of a crash for Pacman
        >>> rules.agentCrash(current_game, 1)  # Notify of a crash for the first ghost
    """
        if agentIndex == 0:
            print('Pacman crashed')
        else:
            print('A ghost crashed')

    def getMaxTotalTime(self, agentIndex):
        """
    ""\"
    Retrieves the maximum total time allowed for an agent's actions during the game.

    This function returns the maximum amount of time (in seconds) that an agent is permitted
    to spend computing its actions before a timeout occurs. This is useful for managing
    the responsiveness and pacing of the game.

    Parameters:
        agentIndex (int): The index of the agent for which the maximum total time is being retrieved.
                          This index corresponds to different agents, with Pacman being index 0.

    Returns:
        int: The maximum total time allowed in seconds for the specified agent's computations.

    Usage Example:
        >>> max_time = rules.getMaxTotalTime(0)  # Retrieve the maximum time for Pacman
        >>> print(max_time)  # Output: 30, for example, indicating the maximum time in seconds
    """
        return self.timeout

    def getMaxStartupTime(self, agentIndex):
        """
    ""\"
    Retrieves the maximum startup time allowed for an agent at the beginning of the game.

    This function returns the maximum amount of time (in seconds) that an agent can spend
    preparing its initial actions before a timeout occurs. This is important for ensuring that
    agents begin their actions in a timely manner.

    Parameters:
        agentIndex (int): The index of the agent for which the maximum startup time is being retrieved.
                          This index corresponds to different agents, with Pacman being index 0.

    Returns:
        int: The maximum startup time allowed in seconds for the specified agent's initial computations.

    Usage Example:
        >>> startup_time = rules.getMaxStartupTime(0)  # Retrieve the maximum startup time for Pacman
        >>> print(startup_time)  # Output: 30, for example, indicating the maximum time in seconds
    """
        return self.timeout

    def getMoveWarningTime(self, agentIndex):
        """
    ""\"
    Retrieves the warning time allowed for an agent before making a move.

    This function returns the amount of time (in seconds) that is allocated for warning the
    agent prior to executing its move. This time can be used to provide feedback to the agent
    about its impending move.

    Parameters:
        agentIndex (int): The index of the agent for which the move warning time is being retrieved.
                          This index corresponds to different agents, with Pacman being index 0.

    Returns:
        int: The move warning time allowed in seconds for the specified agent before executing its move.

    Usage Example:
        >>> warning_time = rules.getMoveWarningTime(0)  # Retrieve the move warning time for Pacman
        >>> print(warning_time)  # Output: 5, for example, indicating the warning time in seconds
    """
        return self.timeout

    def getMoveTimeout(self, agentIndex):
        """
    ""\"
    Retrieves the timeout period for an agent's movement.

    This function returns the maximum amount of time (in seconds) that an agent is allowed
    to take to compute its move before it is considered to have timed out. This is essential
    for ensuring that the game runs smoothly and that agents do not take an excessive amount
    of time to make decisions.

    Parameters:
        agentIndex (int): The index of the agent for which the move timeout is being retrieved.
                          This index corresponds to different agents, with Pacman being index 0.

    Returns:
        int: The move timeout duration in seconds for the specified agent.

    Usage Example:
        >>> move_timeout = rules.getMoveTimeout(0)  # Retrieve the move timeout for Pacman
        >>> print(move_timeout)  # Output: 30, for example, indicating the maximum time in seconds
    """
        return self.timeout

    def getMaxTimeWarnings(self, agentIndex):
        """
    ""\"
    Retrieves the maximum number of time warning messages that can be issued to an agent.

    This function specifies how many warnings an agent can receive if it is approaching
    the time limits for its actions. This helps to manage the agent's decision-making process
    and ensures it does not exceed allocated time without being informed.

    Parameters:
        agentIndex (int): The index of the agent for which the maximum time warnings are being retrieved.
                          This index corresponds to different agents, with Pacman being index 0.

    Returns:
        int: The maximum number of time warnings allowed for the specified agent.

    Usage Example:
        >>> max_warnings = rules.getMaxTimeWarnings(0)  # Retrieve the max time warnings for Pacman
        >>> print(max_warnings)  # Output: 3, for example, indicating the maximum number of warnings
    """
        return 0


class PacmanRules:
    """
    These functions govern how pacman interacts with his environment under
    the classic game rules.
    """
    PACMAN_SPEED = 1

    def getLegalActions(state):
        """
        Returns a list of possible actions.
        """
        return Actions.getPossibleActions(state.getPacmanState().
            configuration, state.data.layout.walls)
    getLegalActions = staticmethod(getLegalActions)

    def applyAction(state, action):
        """
        Edits the state to reflect the results of the action.
        """
        legal = PacmanRules.getLegalActions(state)
        if action not in legal:
            raise Exception('Illegal action ' + str(action))
        pacmanState = state.data.agentStates[0]
        vector = Actions.directionToVector(action, PacmanRules.PACMAN_SPEED)
        pacmanState.configuration = (pacmanState.configuration.
            generateSuccessor(vector))
        next = pacmanState.configuration.getPosition()
        nearest = nearestPoint(next)
        if manhattanDistance(nearest, next) <= 0.5:
            PacmanRules.consume(nearest, state)
    applyAction = staticmethod(applyAction)

    def consume(position, state):
        """
    ""\"
    Processes the consumption of food or capsules at a specified position in the game state.

    This function updates the game state when Pacman eats food or a capsule at the 
    given coordinates. It modifies the score accordingly, removes the food or capsule 
    from the board, and resets the scared timers for any ghosts if a capsule is consumed.

    Parameters:
        position (Tuple[int, int]): A tuple representing the (x, y) coordinates where
                                     food or a capsule is to be consumed.

        state (GameState): The current game state that will be modified based on the consumption.

    Returns:
        None: This function does not return a value but updates the game state in place.

    Usage Example:
        >>> consume((3, 4), current_game_state)  # Pacman consumes food or a capsule at (3, 4)
    """
        x, y = position
        if state.data.food[x][y]:
            state.data.scoreChange += 10
            state.data.food = state.data.food.copy()
            state.data.food[x][y] = False
            state.data._foodEaten = position
            numFood = state.getNumFood()
            if numFood == 0 and not state.data._lose:
                state.data.scoreChange += 500
                state.data._win = True
        if position in state.getCapsules():
            state.data.capsules.remove(position)
            state.data._capsuleEaten = position
            for index in range(1, len(state.data.agentStates)):
                state.data.agentStates[index].scaredTimer = SCARED_TIME
    consume = staticmethod(consume)


class GhostRules:
    """
    These functions dictate how ghosts interact with their environment.
    """
    GHOST_SPEED = 1.0

    def getLegalActions(state, ghostIndex):
        """
        Ghosts cannot stop, and cannot turn around unless they
        reach a dead end, but can turn 90 degrees at intersections.
        """
        conf = state.getGhostState(ghostIndex).configuration
        possibleActions = Actions.getPossibleActions(conf, state.data.
            layout.walls)
        reverse = Actions.reverseDirection(conf.direction)
        if Directions.STOP in possibleActions:
            possibleActions.remove(Directions.STOP)
        if reverse in possibleActions and len(possibleActions) > 1:
            possibleActions.remove(reverse)
        return possibleActions
    getLegalActions = staticmethod(getLegalActions)

    def applyAction(state, action, ghostIndex):
        """
    ""\"
    Updates the game state to reflect the results of a specified action taken by Pacman.

    This function modifies the state based on the action provided, updating Pacman's position,
    checking for food consumption, and ensuring that the action is legal according to the
    game's rules.

    Parameters:
        state (GameState): The current game state that will be modified.
        action (str): A string representing the action that Pacman intends to take, 
                      which must be a legal action.

    Returns:
        None: This function does not return a value but alters the game state
              to reflect the outcomes of the action.

    Usage Example:
        >>> applyAction(current_game_state, 'North')  # Pacman moves north in the current state
    """
        legal = GhostRules.getLegalActions(state, ghostIndex)
        if action not in legal:
            raise Exception('Illegal ghost action ' + str(action))
        ghostState = state.data.agentStates[ghostIndex]
        speed = GhostRules.GHOST_SPEED
        if ghostState.scaredTimer > 0:
            speed /= 2.0
        vector = Actions.directionToVector(action, speed)
        ghostState.configuration = ghostState.configuration.generateSuccessor(
            vector)
    applyAction = staticmethod(applyAction)

    def decrementTimer(ghostState):
        """
    ""\"
    Decrements the scared timer for a ghost agent in the game state.

    This function reduces the scared timer of the specified ghost by one, indicating that 
    the ghost's frightened state is diminishing. If the timer reaches zero, the ghost returns
    to its normal behavior.

    Parameters:
        ghostState (AgentState): The state of the ghost whose scared timer is to be decremented.

    Returns:
        None: This function does not return a value but updates the ghost's scared timer in place.

    Usage Example:
        >>> decrementTimer(current_ghost_state)  # Decrement the scared timer for the given ghost state
    """
        timer = ghostState.scaredTimer
        if timer == 1:
            ghostState.configuration.pos = nearestPoint(ghostState.
                configuration.pos)
        ghostState.scaredTimer = max(0, timer - 1)
    decrementTimer = staticmethod(decrementTimer)

    def checkDeath(state, agentIndex):
        """
    ""\"
    Checks for collisions between Pacman and ghosts, determining if Pacman has died.

    This function evaluates whether Pacman has come into contact with any ghosts that are in
    their normal (non-scared) state. If a collision is detected, it triggers the appropriate
    death handling logic for Pacman.

    Parameters:
        state (GameState): The current game state being evaluated for potential collisions.
        agentIndex (int): The index of the agent that has just moved; specifically, 
                          if it is Pacman (index 0), it checks against all ghosts.

    Returns:
        None: This function does not return a value but modifies the game state if a death condition is met.

    Usage Example:
        >>> checkDeath(current_game_state, 0)  # Check for death after Pacman's move
    """
        pacmanPosition = state.getPacmanPosition()
        if agentIndex == 0:
            for index in range(1, len(state.data.agentStates)):
                ghostState = state.data.agentStates[index]
                ghostPosition = ghostState.configuration.getPosition()
                if GhostRules.canKill(pacmanPosition, ghostPosition):
                    GhostRules.collide(state, ghostState, index)
        else:
            ghostState = state.data.agentStates[agentIndex]
            ghostPosition = ghostState.configuration.getPosition()
            if GhostRules.canKill(pacmanPosition, ghostPosition):
                GhostRules.collide(state, ghostState, agentIndex)
    checkDeath = staticmethod(checkDeath)

    def collide(state, ghostState, agentIndex):
        """
    ""\"
    Handles the collision between Pacman and a ghost, updating the game state accordingly.

    This function determines the outcome of a collision based on the state of the ghost (whether
    it is scared or not) and updates the score and game state. If the ghost is scared, it is
    treated as eaten, and if not, it marks Pacman as dead.

    Parameters:
        state (GameState): The current game state being modified after the collision.
        ghostState (AgentState): The state of the ghost involved in the collision.
        agentIndex (int): The index of the ghost agent that is colliding with Pacman.

    Returns:
        None: This function does not return a value but updates the game state to reflect the collision outcome.

    Usage Example:
        >>> collide(current_game_state, ghost_agent_state, 1)  # Handle collision with ghost 1
    """
        if ghostState.scaredTimer > 0:
            state.data.scoreChange += 200
            GhostRules.placeGhost(state, ghostState)
            ghostState.scaredTimer = 0
            state.data._eaten[agentIndex] = True
        elif not state.data._win:
            state.data.scoreChange -= 500
            state.data._lose = True
    collide = staticmethod(collide)

    def canKill(pacmanPosition, ghostPosition):
        """
    ""\"
    Determines if a ghost can kill Pacman based on their positions.

    This function checks whether the distance between the ghost and Pacman is within the defined
    collision tolerance, indicating that the ghost has successfully made contact with Pacman.

    Parameters:
        pacmanPosition (Tuple[float, float]): A tuple representing the (x, y) coordinates of Pacman's position.
        ghostPosition (Tuple[float, float]): A tuple representing the (x, y) coordinates of the ghost's position.

    Returns:
        bool: True if the ghost can kill Pacman (i.e., they are close enough), False otherwise.

    Usage Example:
        >>> can_kill = canKill(pacman_pos, ghost_pos)  # Check if the ghost can kill Pacman
        >>> print(can_kill)  # Output: True or False depending on their positions
    """
        return manhattanDistance(ghostPosition, pacmanPosition
            ) <= COLLISION_TOLERANCE
    canKill = staticmethod(canKill)

    def placeGhost(state, ghostState):
        """
    ""\"
    Resets the position of a ghost to its starting location in the game state.

    This function places the specified ghost back to its original starting position, typically
    used when the ghost is eaten by Pacman or when certain game events dictate that the ghost 
    should be repositioned.

    Parameters:
        state (GameState): The current game state being modified.
        ghostState (AgentState): The state of the ghost that is to be reset to its starting position.

    Returns:
        None: This function does not return a value but updates the ghost's position in the game state.

    Usage Example:
        >>> placeGhost(current_game_state, ghost_agent_state)  # Reset the ghost's position to its starting location
    """
        ghostState.configuration = ghostState.start
    placeGhost = staticmethod(placeGhost)


def default(str):
    """
    ""\"
    Provides a default string format for command line options.

    This function appends a default value to a given string for use in command-line option descriptions,
    allowing for consistent documentation across various command-line parameters.

    Parameters:
        str (str): The base string to which the default value will be appended.

    Returns:
        str: The original string concatenated with an indication of the default value.

    Usage Example:
        >>> option_description = default('Number of games')
        >>> print(option_description)  # Output: 'Number of games [Default: %default]'
    """
    return str + ' [Default: %default]'


def parseAgentArgs(str):
    """
    ""\"
    Parses a string of agent arguments into a dictionary of key-value pairs.

    This function takes a comma-separated string of options, optionally including 
    key-value pairs, and returns a dictionary where each key corresponds to an 
    option name and the associated value is either the provided value or the default.

    Parameters:
        str (Optional[str]): A string containing agent arguments in the format 
                             "key1=value1,key2,value3=value3". If None, an empty 
                             dictionary is returned.

    Returns:
        dict: A dictionary containing the parsed agent options as key-value pairs.

    Usage Example:
        >>> args = parseAgentArgs("numTraining=5,quiet")
        >>> print(args)  # Output: {'numTraining': '5', 'quiet': '1'}
    """
    if str == None:
        return {}
    pieces = str.split(',')
    opts = {}
    for p in pieces:
        if '=' in p:
            key, val = p.split('=')
        else:
            key, val = p, 1
        opts[key] = val
    return opts


def readCommand(argv):
    """
    Processes the command used to run pacman from the command line.
    """
    from optparse import OptionParser
    usageStr = """
    USAGE:      python pacman.py <options>
    EXAMPLES:   (1) python pacman.py
                    - starts an interactive game
                (2) python pacman.py --layout smallClassic --zoom 2
                OR  python pacman.py -l smallClassic -z 2
                    - starts an interactive game on a smaller board, zoomed in
    """
    parser = OptionParser(usageStr)
    parser.add_option('-n', '--numGames', dest='numGames', type='int', help
        =default('the number of GAMES to play'), metavar='GAMES', default=1)
    parser.add_option('-l', '--layout', dest='layout', help=default(
        'the LAYOUT_FILE from which to load the map layout'), metavar=
        'LAYOUT_FILE', default='mediumClassic')
    parser.add_option('-p', '--pacman', dest='pacman', help=default(
        'the agent TYPE in the pacmanAgents module to use'), metavar='TYPE',
        default='KeyboardAgent')
    parser.add_option('-t', '--textGraphics', action='store_true', dest=
        'textGraphics', help='Display output as text only', default=False)
    parser.add_option('-q', '--quietTextGraphics', action='store_true',
        dest='quietGraphics', help=
        'Generate minimal output and no graphics', default=False)
    parser.add_option('-g', '--ghosts', dest='ghost', help=default(
        'the ghost agent TYPE in the ghostAgents module to use'), metavar=
        'TYPE', default='RandomGhost')
    parser.add_option('-k', '--numghosts', type='int', dest='numGhosts',
        help=default('The maximum number of ghosts to use'), default=4)
    parser.add_option('-z', '--zoom', type='float', dest='zoom', help=
        default('Zoom the size of the graphics window'), default=1.0)
    parser.add_option('-f', '--fixRandomSeed', action='store_true', dest=
        'fixRandomSeed', help=
        'Fixes the random seed to always play the same game', default=False)
    parser.add_option('-r', '--recordActions', action='store_true', dest=
        'record', help=
        'Writes game histories to a file (named by the time they were played)',
        default=False)
    parser.add_option('--replay', dest='gameToReplay', help=
        'A recorded game file (pickle) to replay', default=None)
    parser.add_option('-a', '--agentArgs', dest='agentArgs', help=
        'Comma separated values sent to agent. e.g. "opt1=val1,opt2,opt3=val3"'
        )
    parser.add_option('-x', '--numTraining', dest='numTraining', type='int',
        help=default('How many episodes are training (suppresses output)'),
        default=0)
    parser.add_option('--frameTime', dest='frameTime', type='float', help=
        default('Time to delay between frames; <0 means keyboard'), default=0.1
        )
    parser.add_option('-c', '--catchExceptions', action='store_true', dest=
        'catchExceptions', help=
        'Turns on exception handling and timeouts during games', default=False)
    parser.add_option('--timeout', dest='timeout', type='int', help=default
        (
        'Maximum length of time an agent can spend computing in a single game'
        ), default=30)
    options, otherjunk = parser.parse_args(argv)
    if len(otherjunk) != 0:
        raise Exception('Command line input not understood: ' + str(otherjunk))
    args = dict()
    if options.fixRandomSeed:
        random.seed('cs188')
    args['layout'] = layout.getLayout(options.layout)
    if args['layout'] == None:
        raise Exception('The layout ' + options.layout + ' cannot be found')
    noKeyboard = options.gameToReplay == None and (options.textGraphics or
        options.quietGraphics)
    pacmanType = loadAgent(options.pacman, noKeyboard)
    agentOpts = parseAgentArgs(options.agentArgs)
    if options.numTraining > 0:
        args['numTraining'] = options.numTraining
        if 'numTraining' not in agentOpts:
            agentOpts['numTraining'] = options.numTraining
    pacman = pacmanType(**agentOpts)
    args['pacman'] = pacman
    if 'numTrain' in agentOpts:
        options.numQuiet = int(agentOpts['numTrain'])
        options.numIgnore = int(agentOpts['numTrain'])
    ghostType = loadAgent(options.ghost, noKeyboard)
    args['ghosts'] = [ghostType(i + 1) for i in range(options.numGhosts)]
    if options.quietGraphics:
        import textDisplay
        args['display'] = textDisplay.NullGraphics()
    elif options.textGraphics:
        import textDisplay
        textDisplay.SLEEP_TIME = options.frameTime
        args['display'] = textDisplay.PacmanGraphics()
    else:
        import graphicsDisplay
        args['display'] = graphicsDisplay.PacmanGraphics(options.zoom,
            frameTime=options.frameTime)
    args['numGames'] = options.numGames
    args['record'] = options.record
    args['catchExceptions'] = options.catchExceptions
    args['timeout'] = options.timeout
    if options.gameToReplay != None:
        print('Replaying recorded game %s.' % options.gameToReplay)
        import pickle
        f = open(options.gameToReplay, 'rb')
        try:
            recorded = pickle.load(f)
        finally:
            f.close()
        recorded['display'] = args['display']
        replayGame(**recorded)
        sys.exit(0)
    return args


def loadAgent(pacman, nographics):
    """
    ""\"
    Loads and returns the specified agent class from the corresponding module.

    This function searches through the Python path directories to find and import the module
    containing the specified agent class. If the agent is found, it is returned for instantiation.
    If the agent requires graphical display and no graphics mode is specified, an exception is raised.

    Parameters:
        pacman (str): The name of the Pacman agent class to load.
        nographics (bool): A flag indicating whether graphical display is disabled.

    Returns:
        Type: The class of the specified Pacman agent, ready for instantiation.

    Raises:
        Exception: If the specified agent is not found in any module or if a graphical agent
                   is requested without the graphical display.

    Usage Example:
        >>> pacman_agent_class = loadAgent('GreedyAgent', nographics=False)
        >>> pacman_agent = pacman_agent_class()  # Instantiate the loaded agent
    """
    pythonPathStr = os.path.expandvars('$PYTHONPATH')
    if pythonPathStr.find(';') == -1:
        pythonPathDirs = pythonPathStr.split(':')
    else:
        pythonPathDirs = pythonPathStr.split(';')
    pythonPathDirs.append('.')
    for moduleDir in pythonPathDirs:
        if not os.path.isdir(moduleDir):
            continue
        moduleNames = [f for f in os.listdir(moduleDir) if f.endswith(
            'gents.py')]
        for modulename in moduleNames:
            try:
                module = __import__(modulename[:-3])
            except ImportError:
                continue
            if pacman in dir(module):
                if nographics and modulename == 'keyboardAgents.py':
                    raise Exception(
                        'Using the keyboard requires graphics (not text display)'
                        )
                return getattr(module, pacman)
    raise Exception('The agent ' + pacman +
        ' is not specified in any *Agents.py.')


def replayGame(layout, actions, display):
    """
    ""\"
    Replays a recorded game using the specified layout, actions, and display.

    This function takes the layout of the game, a sequence of actions corresponding to
    the moves made during the recorded game, and a display object to render the game graphics.
    It initializes a new game instance and executes the recorded actions sequentially
    to simulate the game playback.

    Parameters:
        layout (Layout): The layout object defining the structure of the game board.
        actions (List[Tuple[int, int]]): A list of tuples representing the recorded actions
                                          taken during the game, where each tuple contains
                                          the index of the agent and the action performed.
        display (Display): The display object responsible for rendering the game graphics
                           or text output during the replay.

    Returns:
        None: This function does not return a value but executes the replay of the game on the display.

    Usage Example:
        >>> replayGame(layout, recorded_actions, display)  # Replay the game with specified layout and actions
    """
    import pacmanAgents, ghostAgents
    rules = ClassicGameRules()
    agents = [pacmanAgents.GreedyAgent()] + [ghostAgents.RandomGhost(i + 1) for
        i in range(layout.getNumGhosts())]
    game = rules.newGame(layout, agents[0], agents[1:], display)
    state = game.state
    display.initialize(state.data)
    for action in actions:
        state = state.generateSuccessor(*action)
        display.update(state.data)
        rules.process(state, game)
    display.finish()


def runGames(layout, pacman, ghosts, display, numGames, record, numTraining
    =0, catchExceptions=False, timeout=30):
    """
    ""\"
    Initializes and runs multiple instances of the Pacman game.

    This function sets up and executes a specified number of game instances using the
    provided layout, Pacman agent, ghost agents, display format, and other game settings. 
    It collects game results such as scores and win rates, and can also record game histories 
    if desired.

    Parameters:
        layout (Layout): The layout object defining the structure and components of the game board.
        pacman (Agent): The agent representing Pacman, which will control Pacman's actions.
        ghosts (List[Agent]): A list of agents representing the ghost characters in the game.
        display (Display): The display object responsible for rendering graphics or text output.
        numGames (int): The total number of game instances to run.
        record (bool): A flag indicating whether to save the game histories to files.
        numTraining (int, optional): The number of training episodes, defaulting to 0.
        catchExceptions (bool, optional): A flag indicating whether to enable exception handling, defaulting to False.
        timeout (int, optional): The maximum allowed time for an agent's actions in seconds, defaulting to 30.

    Returns:
        List[Game]: A list of Game objects representing all the games that were run.

    Usage Example:
        >>> games = runGames(layout, pacman_agent, ghost_agents, display, numGames=10, record=True)
        >>> print(len(games))  # Output: 10, indicating that 10 games were executed
    """
    import __main__
    __main__.__dict__['_display'] = display
    rules = ClassicGameRules(timeout)
    games = []
    for i in range(numGames):
        beQuiet = i < numTraining
        if beQuiet:
            import textDisplay
            gameDisplay = textDisplay.NullGraphics()
            rules.quiet = True
        else:
            gameDisplay = display
            rules.quiet = False
        game = rules.newGame(layout, pacman, ghosts, gameDisplay, beQuiet,
            catchExceptions)
        game.run()
        if not beQuiet:
            games.append(game)
        if record:
            import time, pickle
            fname = 'recorded-game-%d' % (i + 1) + '-'.join([str(t) for t in
                time.localtime()[1:6]])
            f = open(fname, 'wb')
            components = {'layout': layout, 'actions': game.moveHistory}
            pickle.dump(components, f)
            f.close()
    if numGames - numTraining > 0:
        scores = [game.state.getScore() for game in games]
        wins = [game.state.isWin() for game in games]
        winRate = wins.count(True) / float(len(wins))
        print('Average Score:', sum(scores) / float(len(scores)))
        print('Scores:       ', ', '.join([str(score) for score in scores]))
        print('Win Rate:      %d/%d (%.2f)' % (wins.count(True), len(wins),
            winRate))
        print('Record:       ', ', '.join([['Loss', 'Win'][int(w)] for w in
            wins]))
    return games


if __name__ == '__main__':
    """
    The main function called when pacman.py is run
    from the command line:

    > python pacman.py

    See the usage string for more details.

    > python pacman.py --help
    """
    args = readCommand(sys.argv[1:])
    runGames(**args)
    pass
