# """
# File: grading.py
# ----------------
# This file contains the implementation of a grading framework designed for autograding projects. The framework establishes a structure for managing project grades, including functions for grading questions based on a defined set of criteria, outputting results in multiple formats, and managing messages related to grading processes. The Grades class serves as the core of the grading functionality, allowing educators to evaluate student submissions systematically.
# 
# Class Definitions:
# ------------------
# 1. Class Grades:
#    This class is responsible for defining the grading scheme for a project and providing various methods for grading individual questions, managing prerequisites, and producing output for different platforms (such as edX or GradeScope).
# 
#    Attributes:
#    - project (str): The name of the project being graded.
#    - questions (list): A list of questions to be graded.
#    - maxes (dict): A dictionary mapping each question to its maximum achievable score.
#    - points (Counter): A counter to track the score obtained on each question.
#    - messages (dict): A dictionary to store messages associated with each question.
#    - start (tuple): A timestamp representing when grading started.
#    - sane (bool): A flag indicating the sanity of the grading process.
#    - currentQuestion (str): The currently graded question.
#    - edxOutput (bool): A flag for generating output specific to edX.
#    - gsOutput (bool): A flag for generating output specific to GradeScope.
#    - mute (bool): A flag for controlling output visibility during grading.
#    - prereqs (defaultdict): A dictionary containing prerequisite relationships between questions.
# 
#    Methods:
#    - __init__(projectName, questionsAndMaxesList, gsOutput=False, edxOutput=False, muteOutput=False): Initializes an instance of Grades, setting up the project name, questions, maximum scores, and output preferences.
#    - addPrereq(question, prereq): Adds a prerequisite relationship between questions.
#    - grade(gradingModule, exceptionMap={}, bonusPic=False): Grades each question by invoking grading functions from the provided grading module. Handles exceptions and tracks completion of questions.
#    - addExceptionMessage(q, inst, traceback): Formats and adds exception messages to the grading output.
#    - addErrorHints(exceptionMap, errorInstance, questionNum): Retrieves and adds hints or specific error messages based on exceptions encountered during grading.
#    - produceGradeScopeOutput(): Outputs grading results suitable for the GradeScope platform in JSON format.
#    - produceOutput(): Generates grading results formatted for the edX platform in HTML.
#    - fail(message, raw=False): Marks the grading as unsuccessful, sets the current question score to zero, and adds a failure message.
#    - assignZeroCredit(): Assigns zero credit for the currently graded question.
#    - addPoints(amt): Increases the score for the currently graded question by a specified amount.
#    - deductPoints(amt): Decreases the score for the currently graded question by a specified amount.
#    - assignFullCredit(message="", raw=False): Assigns full credit for the currently graded question and optionally adds a message.
#    - addMessage(message, raw=False): Adds a formatted message to the current question's output. Outputs the message to console if not in raw format.
#    - addMessageToEmail(message): A deprecated method for adding messages for email notifications.
# 
# 2. Class Counter:
#    This class extends a standard dictionary to provide a default value of zero for non-existing keys. It also includes a method to compute the total count of all keys.
# 
#    Attributes:
#    - Inherits from dict.
# 
#    Methods:
#    - __getitem__(idx): Retrieves the count for a given index, returning zero if the index does not exist in the dictionary.
#    - totalCount(): Returns the sum of counts for all keys in the Counter.
# 
# """

"""Common code for autograders"""
import cgi
import time
import sys
import json
import traceback
import pdb
from collections import defaultdict
import util


class Grades:
    """A data structure for project grades, along with formatting code to display them"""

    def __init__(self, projectName, questionsAndMaxesList, gsOutput=False,
        edxOutput=False, muteOutput=False):
        """
    Defines the grading scheme for a project
      projectName: project name
      questionsAndMaxesDict: a list of (question name, max points per question)
    """
        self.questions = [el[0] for el in questionsAndMaxesList]
        self.maxes = dict(questionsAndMaxesList)
        self.points = Counter()
        self.messages = dict([(q, []) for q in self.questions])
        self.project = projectName
        self.start = time.localtime()[1:6]
        self.sane = True
        self.currentQuestion = None
        self.edxOutput = edxOutput
        self.gsOutput = gsOutput
        self.mute = muteOutput
        self.prereqs = defaultdict(set)
        print('Starting on %d-%d at %d:%02d:%02d' % self.start)

    def addPrereq(self, question, prereq):
        """
    def addPrereq(self, question, prereq):
        ""\"
        Add a prerequisite relationship between two questions in the grading system.

        This method associates a specified prerequisite question with a target question,
        indicating that the target question cannot be graded until the prerequisite question
        is completed.

        Parameters:
        question (str): The target question that depends on the completion of the prerequisite.
        prereq (str): The prerequisite question that must be completed before grading the target question.

        Returns:
        None

        Example:
        >>> grades = Grades('Project 1', [('q1', 5), ('q2', 10)])
        >>> grades.addPrereq('q2', 'q1')
        >>> print(grades.prereqs)
        defaultdict(<class 'set'>, {'q2': {'q1'}})
        ""\"
```"""
        self.prereqs[question].add(prereq)

    def grade(self, gradingModule, exceptionMap={}, bonusPic=False):
        """
    Grades each question
      gradingModule: the module with all the grading functions (pass in with sys.modules[__name__])
    """
        completedQuestions = set([])
        for q in self.questions:
            print('\nQuestion %s' % q)
            print('=' * (9 + len(q)))
            print
            self.currentQuestion = q
            incompleted = self.prereqs[q].difference(completedQuestions)
            if len(incompleted) > 0:
                prereq = incompleted.pop()
                print(
                    """*** NOTE: Make sure to complete Question %s before working on Question %s,
*** because Question %s builds upon your answer for Question %s.
"""
                     % (prereq, q, q, prereq))
                continue
            if self.mute:
                util.mutePrint()
            try:
                util.TimeoutFunction(getattr(gradingModule, q), 1800)(self)
            except Exception as inst:
                self.addExceptionMessage(q, inst, traceback)
                self.addErrorHints(exceptionMap, inst, q[1])
            except:
                self.fail('FAIL: Terminated with a string exception.')
            finally:
                if self.mute:
                    util.unmutePrint()
            if self.points[q] >= self.maxes[q]:
                completedQuestions.add(q)
            print('\n### Question %s: %d/%d ###\n' % (q, self.points[q],
                self.maxes[q]))
        print('\nFinished at %d:%02d:%02d' % time.localtime()[3:6])
        print('\nProvisional grades\n==================')
        for q in self.questions:
            print('Question %s: %d/%d' % (q, self.points[q], self.maxes[q]))
        print('------------------')
        print('Total: %d/%d' % (self.points.totalCount(), sum(self.maxes.
            values())))
        if bonusPic and self.points.totalCount() == 25:
            print(
                """

                     ALL HAIL GRANDPAC.
              LONG LIVE THE GHOSTBUSTING KING.

                  ---      ----      ---
                  |  \\    /  + \\    /  |
                  | + \\--/      \\--/ + |
                  |   +     +          |
                  | +     +        +   |
                @@@@@@@@@@@@@@@@@@@@@@@@@@
              @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            \\   @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
             \\ /  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              V   \\   @@@@@@@@@@@@@@@@@@@@@@@@@@@@
                   \\ /  @@@@@@@@@@@@@@@@@@@@@@@@@@
                    V     @@@@@@@@@@@@@@@@@@@@@@@@
                            @@@@@@@@@@@@@@@@@@@@@@
                    /\\      @@@@@@@@@@@@@@@@@@@@@@
                   /  \\  @@@@@@@@@@@@@@@@@@@@@@@@@
              /\\  /    @@@@@@@@@@@@@@@@@@@@@@@@@@@
             /  \\ @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            /    @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                @@@@@@@@@@@@@@@@@@@@@@@@@@
                    @@@@@@@@@@@@@@@@@@

"""
                )
        print(
            """
Your grades are NOT yet registered.  To register your grades, make sure
to follow your instructor's guidelines to receive credit on your project.
"""
            )
        if self.edxOutput:
            self.produceOutput()
        if self.gsOutput:
            self.produceGradeScopeOutput()

    def addExceptionMessage(self, q, inst, traceback):
        """
    Method to format the exception message, this is more complicated because
    we need to cgi.escape the traceback but wrap the exception in a <pre> tag
    """
        self.fail('FAIL: Exception raised: %s' % inst)
        self.addMessage('')
        for line in traceback.format_exc().split('\n'):
            self.addMessage(line)

    def addErrorHints(self, exceptionMap, errorInstance, questionNum):
        """
    def addErrorHints(self, exceptionMap, errorInstance, questionNum):
        ""\"
        Retrieve and add error hints related to exceptions encountered during grading.

        This method checks an exception map for hints based on the type of the raised
        error. It first looks for specific hints related to the current question and,
        if none are found, falls back to general error messages based on the error type.

        Parameters:
        exceptionMap (dict): A dictionary mapping question identifiers to specific error types
                             and their corresponding hints.
        errorInstance (Exception): The exception that was raised during grading, used to identify the error type.
        questionNum (str): The number or identifier of the question currently being graded.

        Returns:
        None

        Example:
        >>> exception_map = {
        ...     'q1': {TypeError: "Ensure your inputs are of the correct type."},
        ...     'TypeError': "Check the types of your variables."
        ... }
        >>> grades = Grades('Project 1', [('q1', 5)])
        >>> error_instance = TypeError("Invalid type")
        >>> grades.addErrorHints(exception_map, error_instance, '1')
        >>> print(grades.messages['q1'])
        ["Check the types of your variables.", "Ensure your inputs are of the correct type."]
        ""\"
```"""
        typeOf = str(type(errorInstance))
        questionName = 'q' + questionNum
        errorHint = ''
        if exceptionMap.get(questionName):
            questionMap = exceptionMap.get(questionName)
            if questionMap.get(typeOf):
                errorHint = questionMap.get(typeOf)
        if exceptionMap.get(typeOf):
            errorHint = exceptionMap.get(typeOf)
        if not errorHint:
            return ''
        for line in errorHint.split('\n'):
            self.addMessage(line)

    def produceGradeScopeOutput(self):
        """
    def produceGradeScopeOutput(self):
        ""\"
        Generate and output the results of the grading process in a format suitable for GradeScope.

        This method constructs a JSON object that includes the total score, maximum score,
        and detailed results for individual questions. It writes this information to a
        'gradescope_response.json' file, which can then be submitted to the GradeScope system.

        Parameters:
        None

        Returns:
        None

        Example:
        >>> grades = Grades('Project 1', [('q1', 5), ('q2', 10)])
        >>> grades.addPoints(5)  # Award full points for question 1
        >>> grades.addPoints(8)  # Partial points for question 2
        >>> grades.produceGradeScopeOutput()
        >>> # Check the contents of 'gradescope_response.json' for the generated output.
        ""\"
```"""
        out_dct = {}
        total_possible = sum(self.maxes.values())
        total_score = sum(self.points.values())
        out_dct['score'] = total_score
        out_dct['max_score'] = total_possible
        out_dct['output'] = 'Total score (%d / %d)' % (total_score,
            total_possible)
        tests_out = []
        for name in self.questions:
            test_out = {}
            test_out['name'] = name
            test_out['score'] = self.points[name]
            test_out['max_score'] = self.maxes[name]
            is_correct = self.points[name] >= self.maxes[name]
            test_out['output'
                ] = '  Question {num} ({points}/{max}) {correct}'.format(num
                =name[1] if len(name) == 2 else name, points=test_out[
                'score'], max=test_out['max_score'], correct='X' if not
                is_correct else '')
            test_out['tags'] = []
            tests_out.append(test_out)
        out_dct['tests'] = tests_out
        with open('gradescope_response.json', 'w') as outfile:
            json.dump(out_dct, outfile)
        return

    def produceOutput(self):
        """
    def produceOutput(self):
        ""\"
        Generate and output the results of the grading process in a format suitable for edX.

        This method constructs an HTML formatted string that summarizes the total score,
        maximum score, and details for each question, including any messages associated
        with the questions. The output is written to an 'edx_response.html' file, which
        can be used for reporting grading results in the edX platform.

        Parameters:
        None

        Returns:
        None

        Example:
        >>> grades = Grades('Project 1', [('q1', 5), ('q2', 10)])
        >>> grades.addPoints(5)  # Award full points for question 1
        >>> grades.addPoints(7)  # Partial points for question 2
        >>> grades.produceOutput()
        >>> # Check the contents of 'edx_response.html' for the generated HTML output.
        ""\"
```"""
        edxOutput = open('edx_response.html', 'w')
        edxOutput.write('<div>')
        total_possible = sum(self.maxes.values())
        total_score = sum(self.points.values())
        checkOrX = '<span class="incorrect"/>'
        if total_score >= total_possible:
            checkOrX = '<span class="correct"/>'
        header = (
            """
        <h3>
            Total score ({total_score} / {total_possible})
        </h3>
    """
            .format(total_score=total_score, total_possible=total_possible,
            checkOrX=checkOrX))
        edxOutput.write(header)
        for q in self.questions:
            if len(q) == 2:
                name = q[1]
            else:
                name = q
            checkOrX = '<span class="incorrect"/>'
            if self.points[q] >= self.maxes[q]:
                checkOrX = '<span class="correct"/>'
            messages = '<pre>%s</pre>' % '\n'.join(self.messages[q])
            output = (
                """
        <div class="test">
          <section>
          <div class="shortform">
            Question {q} ({points}/{max}) {checkOrX}
          </div>
        <div class="longform">
          {messages}
        </div>
        </section>
      </div>
      """
                .format(q=name, max=self.maxes[q], messages=messages,
                checkOrX=checkOrX, points=self.points[q]))
            edxOutput.write(output)
        edxOutput.write('</div>')
        edxOutput.close()
        edxOutput = open('edx_grade', 'w')
        edxOutput.write(str(self.points.totalCount()))
        edxOutput.close()

    def fail(self, message, raw=False):
        """Sets sanity check bit to false and outputs a message"""
        self.sane = False
        self.assignZeroCredit()
        self.addMessage(message, raw)

    def assignZeroCredit(self):
        """
    def assignZeroCredit(self):
        ""\"
        Assign zero credit for the currently graded question.

        This method sets the score for the current question being graded to zero,
        indicating that the student did not earn any points for that question. 
        This is typically called when a question fails certain sanity checks or 
        if an error has occurred during grading.

        Parameters:
        None

        Returns:
        None

        Example:
        >>> grades = Grades('Project 1', [('q1', 5)])
        >>> grades.assignZeroCredit()
        >>> print(grades.points['q1'])
        0
        ""\"
```"""
        self.points[self.currentQuestion] = 0

    def addPoints(self, amt):
        """
    def addPoints(self, amt):
        ""\"
        Increase the score for the currently graded question by a specified amount.

        This method adds a given number of points to the score of the question that is
        currently being graded. It is typically used to reward students for correctly
        answering parts of a question.

        Parameters:
        amt (int): The amount of points to be added to the current question's score. 
                   This value can be positive or negative, impacting the total score accordingly.

        Returns:
        None

        Example:
        >>> grades = Grades('Project 1', [('q1', 5)])
        >>> grades.addPoints(3)  # Award 3 points for question 1
        >>> print(grades.points['q1'])
        3
        ""\"
```"""
        self.points[self.currentQuestion] += amt

    def deductPoints(self, amt):
        """
    def deductPoints(self, amt):
        ""\"
        Decrease the score for the currently graded question by a specified amount.

        This method reduces the current score of the question being graded by the 
        provided number of points. It is typically used to penalize students for 
        incorrect answers or for failing specific criteria.

        Parameters:
        amt (int): The amount of points to be deducted from the current question's score. 
                   This value should be positive, reflecting a penalty to the total score.

        Returns:
        None

        Example:
        >>> grades = Grades('Project 1', [('q1', 5)])
        >>> grades.addPoints(5)  # Award full points for question 1
        >>> grades.deductPoints(2)  # Deduct 2 points for some errors
        >>> print(grades.points['q1'])
        3
        ""\"
```"""
        self.points[self.currentQuestion] -= amt

    def assignFullCredit(self, message='', raw=False):
        """
    def assignFullCredit(self, message="", raw=False):
        ""\"
        Assign full credit for the currently graded question.

        This method sets the score for the current question being graded to its maximum value, 
        indicating that the student has earned full points for that question. It can also 
        optionally add a message associated with this action.

        Parameters:
        message (str, optional): An optional message to be added to the current question's
                                 output, providing context or feedback for the full credit.
                                 Defaults to an empty string.
        raw (bool, optional): A flag indicating whether the message should be treated as raw
                              (unformatted) output. Defaults to False.

        Returns:
        None

        Example:
        >>> grades = Grades('Project 1', [('q1', 5)])
        >>> grades.assignFullCredit("Excellent work!")  # Assign full credit with a message
        >>> print(grades.points['q1'])
        5
        >>> print(grades.messages['q1'])
        ['Excellent work!']
        ""\"
```"""
        self.points[self.currentQuestion] = self.maxes[self.currentQuestion]
        if message != '':
            self.addMessage(message, raw)

    def addMessage(self, message, raw=False):
        """
    def addMessage(self, message, raw=False):
        ""\"
        Add a formatted message to the current question's output.

        This method appends a given message to the list of messages associated with
        the question currently being graded. If the `raw` parameter is set to False,
        the message is formatted for HTML output; otherwise, it is treated as raw text.

        Parameters:
        message (str): The message to be added to the current question's output.
        raw (bool, optional): A flag indicating whether the message should be treated as
                              raw (unformatted) output. Defaults to False.

        Returns:
        None

        Example:
        >>> grades = Grades('Project 1', [('q1', 5)])
        >>> grades.addMessage("This is a note.", raw=False)  # Add a formatted message
        >>> grades.addMessage("This is raw text.", raw=True)  # Add a raw message
        >>> print(grades.messages['q1'])
        ['This is a note.', 'This is raw text.']
        ""\"
```"""
        if not raw:
            if self.mute:
                util.unmutePrint()
            print('*** ' + message)
            if self.mute:
                util.mutePrint()
            message = cgi.escape(message)
        self.messages[self.currentQuestion].append(message)

    def addMessageToEmail(self, message):
        """
    def addMessageToEmail(self, message):
        ""\"
        Add a message to the list meant for email notifications.

        This method is intended to append a message for email notifications related to
        the grading process. It has been marked as deprecated and may not be used in future
        versions of the grading system.

        Parameters:
        message (str): The message to be added for email notifications.

        Returns:
        None

        Example:
        >>> grades = Grades('Project 1', [('q1', 5)])
        >>> grades.addMessageToEmail("Reminder: Check your submission completeness.")
        >>> # Note: This method is deprecated and does not have a direct output effect.
        ""\"
```"""
        print('WARNING**** addMessageToEmail is deprecated %s' % message)
        for line in message.split('\n'):
            pass


class Counter(dict):
    """
  Dict with default 0
  """

    def __getitem__(self, idx):
        """
    def __getitem__(self, idx):
        ""\"
        Retrieve the count for a given index, returning zero if the index does not exist.

        This method overrides the default behavior of dictionary item access to ensure that
        any attempt to access a key that does not exist in the dictionary returns a count
        of zero instead of raising a KeyError. This is useful for counting scenarios where
        missing keys should default to zero.

        Parameters:
        idx (any): The key or index for which the count is to be retrieved.

        Returns:
        int: The count associated with the provided index, or zero if the index does not exist.

        Example:
        >>> counter = Counter()
        >>> counter['a']  # Accessing a non-existing key
        0
        >>> counter['a'] += 5  # Incrementing the count for 'a'
        >>> counter['a']
        5
        ""\"
```"""
        try:
            return dict.__getitem__(self, idx)
        except KeyError:
            return 0

    def totalCount(self):
        """
    Returns the sum of counts for all keys.
    """
        return sum(self.values())
