# """
# graphicsDisplay.py
# 
# This module is responsible for the graphical display of the Pacman game, including rendering the game board, Pacman, ghosts, food, capsules, and other game elements. It utilizes a custom graphics utility for drawing shapes and handling the rendering loop.
# 
# Classes:
# - InfoPane: A class that handles the display of the information pane showing the score and other game information.
#     - __init__(self, layout, gridSize): Initializes the InfoPane with the layout and grid size.
#     - toScreen(self, pos, y=None): Translates a point to screen coordinates relative to the info pane.
#     - drawPane(self): Draws the initial pane showing the score.
#     - initializeGhostDistances(self, distances): Initializes the display for ghost distances.
#     - updateScore(self, score): Updates the displayed score.
#     - setTeam(self, isBlue): Displays the team information (Red or Blue).
#     - updateGhostDistances(self, distances): Updates the displayed ghost distances.
#     - Additional methods for drawing and updating ghost and Pacman icons, and handling messages.
# 
# - PacmanGraphics: A class that handles the overall graphical rendering of the Pacman game.
#     - __init__(self, zoom=1.0, frameTime=0.0, capture=False): Initializes the graphics with options for zoom, frame time, and capture mode.
#     - checkNullDisplay(self): Checks if the graphical display is not initialized.
#     - initialize(self, state, isBlue=False): Initializes graphics related to the game state and team color.
#     - startGraphics(self, state): Sets up the graphical window and defines the layout.
#     - drawDistributions(self, state): Draws the probability distributions on the layout (for agent beliefs).
#     - drawStaticObjects(self, state): Draws static game objects such as walls and food.
#     - drawAgentObjects(self, state): Draws the agent objects (Pacman and ghosts).
#     - swapImages(self, agentIndex, newState): Swaps the displayed image for a pacman or ghost due to capture.
#     - update(self, newState): Updates the display with the new game state.
#     - make_window(self, width, height): Creates the window for the game graphics.
#     - drawPacman(self, pacman, index): Draws the Pacman character on the screen.
#     - movePacman(self, position, direction, image): Moves the Pacman character to a new position.
#     - animatePacman(self, pacman, prevPacman, image): Animates Pacman's movement between positions.
#     - getGhostColor(self, ghost, ghostIndex): Returns the color for a ghost based on its state.
#     - drawGhost(self, ghost, agentIndex): Draws a ghost on the screen.
#     - moveGhost(self, ghost, ghostIndex, prevGhost, ghostImageParts): Moves the ghost to a new position.
#     - getPosition(self, agentState): Retrieves the position of an agent (Pacman or ghost).
#     - getDirection(self, agentState): Retrieves the direction in which the agent is moving.
#     - finish(self): Ends the graphics display session.
#     - to_screen(self, point): Converts a coordinate point to screen coordinates.
# 
# - FirstPersonPacmanGraphics: A subclass of PacmanGraphics that implements a first-person perspective for the Pacman character.
#     - __init__(self, zoom=1.0, showGhosts=True, capture=False, frameTime=0): Initializes the first-person graphics display.
#     - initialize(self, state, isBlue=False): Initializes graphics related to the first-person view.
#     - lookAhead(self, config, state): Adjusts display settings based on the current configuration of the agent.
#     - getGhostColor(self, ghost, ghostIndex): Overrides the method to provide different ghost color behavior in first-person view.
# 
# Functions:
# - add(x, y): Adds two tuples representing coordinates.
# - saveFrame(): Saves the current graphical output to a PostScript file.
# """

from graphicsUtils import *
import math, time
from game import Directions
DEFAULT_GRID_SIZE = 30.0
INFO_PANE_HEIGHT = 35
BACKGROUND_COLOR = formatColor(0, 0, 0)
WALL_COLOR = formatColor(0.0 / 255.0, 51.0 / 255.0, 255.0 / 255.0)
INFO_PANE_COLOR = formatColor(0.4, 0.4, 0)
SCORE_COLOR = formatColor(0.9, 0.9, 0.9)
PACMAN_OUTLINE_WIDTH = 2
PACMAN_CAPTURE_OUTLINE_WIDTH = 4
GHOST_COLORS = []
GHOST_COLORS.append(formatColor(0.9, 0, 0))
GHOST_COLORS.append(formatColor(0, 0.3, 0.9))
GHOST_COLORS.append(formatColor(0.98, 0.41, 0.07))
GHOST_COLORS.append(formatColor(0.1, 0.75, 0.7))
GHOST_COLORS.append(formatColor(1.0, 0.6, 0.0))
GHOST_COLORS.append(formatColor(0.4, 0.13, 0.91))
TEAM_COLORS = GHOST_COLORS[:2]
GHOST_SHAPE = [(0, 0.3), (0.25, 0.75), (0.5, 0.3), (0.75, 0.75), (0.75, -
    0.5), (0.5, -0.75), (-0.5, -0.75), (-0.75, -0.5), (-0.75, 0.75), (-0.5,
    0.3), (-0.25, 0.75)]
GHOST_SIZE = 0.65
SCARED_COLOR = formatColor(1, 1, 1)
GHOST_VEC_COLORS = [colorToVector(c) for c in GHOST_COLORS]
PACMAN_COLOR = formatColor(255.0 / 255.0, 255.0 / 255.0, 61.0 / 255)
PACMAN_SCALE = 0.5
FOOD_COLOR = formatColor(1, 1, 1)
FOOD_SIZE = 0.1
LASER_COLOR = formatColor(1, 0, 0)
LASER_SIZE = 0.02
CAPSULE_COLOR = formatColor(1, 1, 1)
CAPSULE_SIZE = 0.25
WALL_RADIUS = 0.15


class InfoPane:

    def __init__(self, layout, gridSize):
        """
    Initializes the graphical display for the Pacman game.

    This constructor sets up the graphics environment by initializing various parameters 
    such as zoom level, frame time, and capture mode. It establishes the window dimensions
    and prepares the graphics for rendering game elements.

    Parameters:
    zoom (float): The zoom level for scaling the graphics. Default is 1.0.
    frameTime (float): The time in seconds to wait between frames for animation. 
                       Default is 0.0 for immediate updates.
    capture (bool): A flag indicating whether the game is in capture mode, which alters 
                    the appearance of characters. Default is False.

    Returns:
    None

    Example:
    >>> graphics = PacmanGraphics(zoom=1.5, frameTime=0.02, capture=True)
"""
        self.gridSize = gridSize
        self.width = layout.width * gridSize
        self.base = (layout.height + 1) * gridSize
        self.height = INFO_PANE_HEIGHT
        self.fontSize = 24
        self.textColor = PACMAN_COLOR
        self.drawPane()

    def toScreen(self, pos, y=None):
        """
          Translates a point relative from the bottom left of the info pane.
        """
        if y == None:
            x, y = pos
        else:
            x = pos
        x = self.gridSize + x
        y = self.base + y
        return x, y

    def drawPane(self):
        """
    Draws the initial information pane displaying the score.

    This method creates a text display on the info pane that shows the current score in 
    a formatted manner. It is called during the initialization of the info pane.

    Parameters:
    None

    Returns:
    None

    Example:
    >>> info_pane = InfoPane(layout, gridSize)
    >>> info_pane.drawPane()  # This will display the initial score as "SCORE:    0\"
"""
        self.scoreText = text(self.toScreen(0, 0), self.textColor,
            'SCORE:    0', 'Times', self.fontSize, 'bold')

    def initializeGhostDistances(self, distances):
        """
    Initializes the display of distances to ghosts in the info pane.

    This method creates text elements in the info pane that show the current distances 
    from the Pacman to each ghost. It sets up the necessary text objects for updating 
    as the game progresses.

    Parameters:
    distances (list of str): A list of strings representing the distances to each ghost.

    Returns:
    None

    Example:
    >>> info_pane = InfoPane(layout, gridSize)
    >>> ghost_distances = ['10', '5', '7']  # Example distances to ghosts
    >>> info_pane.initializeGhostDistances(ghost_distances)  # Initializes ghost distance display
"""
        self.ghostDistanceText = []
        size = 20
        if self.width < 240:
            size = 12
        if self.width < 160:
            size = 10
        for i, d in enumerate(distances):
            t = text(self.toScreen(self.width // 2 + self.width // 8 * i, 0
                ), GHOST_COLORS[i + 1], d, 'Times', size, 'bold')
            self.ghostDistanceText.append(t)

    def updateScore(self, score):
        """
    Updates the displayed score in the info pane.

    This method modifies the text that shows the current score based on the provided 
    score value. It ensures that the displayed score is up-to-date during the game.

    Parameters:
    score (int): The current score to be displayed. This value is formatted and 
                 updated in the info pane.

    Returns:
    None

    Example:
    >>> info_pane = InfoPane(layout, gridSize)
    >>> info_pane.updateScore(150)  # Updates the score display to "SCORE:  150\"
"""
        changeText(self.scoreText, 'SCORE: % 4d' % score)

    def setTeam(self, isBlue):
        """
    Sets and displays the team information in the info pane.

    This method updates the information pane to indicate whether the player is part 
    of the Red team or the Blue team based on the provided flag. The corresponding 
    team's name is displayed at the designated location in the info pane.

    Parameters:
    isBlue (bool): A boolean flag indicating whether the player is on the Blue team. 
                   If True, "BLUE TEAM" will be displayed; otherwise, "RED TEAM" is shown.

    Returns:
    None

    Example:
    >>> info_pane = InfoPane(layout, gridSize)
    >>> info_pane.setTeam(True)  # Sets and displays "BLUE TEAM" in the info pane
"""
        text = 'RED TEAM'
        if isBlue:
            text = 'BLUE TEAM'
        self.teamText = text(self.toScreen(300, 0), self.textColor, text,
            'Times', self.fontSize, 'bold')

    def updateGhostDistances(self, distances):
        """
    Updates the displayed distances to ghosts in the info pane.

    This method refreshes the text displaying the distances from Pacman to each ghost. 
    If the distances have already been initialized, this function will update the text 
    elements with the new distances provided. If there are no distances, it will do nothing.

    Parameters:
    distances (list of str): A list of strings representing the current distances to each ghost.

    Returns:
    None

    Example:
    >>> info_pane = InfoPane(layout, gridSize)
    >>> new_distances = ['3', '2', '5']  # Updated distances to ghosts
    >>> info_pane.updateGhostDistances(new_distances)  # Updates the ghost distance display
"""
        if len(distances) == 0:
            return
        if 'ghostDistanceText' not in dir(self):
            self.initializeGhostDistances(distances)
        else:
            for i, d in enumerate(distances):
                changeText(self.ghostDistanceText[i], d)

    def drawGhost(self):
        """
    Draws a ghost character on the screen.

    This method creates a graphical representation of a ghost based on its current
    state and position within the game. It uses the ghost's color and shape to render
    the character on the display, including its eyes. 

    Parameters:
    ghost (AgentState): The current state of the ghost, which contains position and
                        direction information.
    agentIndex (int): The index of the ghost in the list of agents, used to determine
                      the ghost's color and behavior.

    Returns:
    list: A list of graphical objects representing the ghost, including its body and eyes.

    Example:
    >>> ghost_state = ...  # Obtain the ghost's state from the game
    >>> index = 0  # Index of the ghost in the agent list
    >>> ghost_image_parts = graphics.drawGhost(ghost_state, index)  # Draws the ghost on the screen
"""
        pass

    def drawPacman(self):
        """
    Draws the Pacman character on the screen.

    This method creates a graphical representation of Pacman based on its current 
    state and position. It renders Pacman with the appropriate color, size, and 
    direction of movement, including an outline if it is in capture mode.

    Parameters:
    pacman (AgentState): The current state of the Pacman, which contains position 
                         and direction information.
    index (int): The index of the Pacman in the list of agents, used to determine 
                  its color and appearance, especially in capture mode.

    Returns:
    list: A list of graphical objects representing Pacman, including the circular body 
          and endpoints for the mouth depicting its direction.

    Example:
    >>> pacman_state = ...  # Obtain the Pacman's state from the game
    >>> index = 0  # Index of Pacman in the agent list
    >>> pacman_image = graphics.drawPacman(pacman_state, index)  # Draws Pacman on the screen
"""
        pass

    def drawWarning(self):
        """
    Draws a warning indicator on the screen.

    This method is responsible for displaying a warning message or visual cue 
    to alert the player about important game events or status changes. This may 
    involve highlighting certain elements or displaying text in the info pane.

    Parameters:
    None

    Returns:
    None

    Example:
    >>> info_pane = InfoPane(layout, gridSize)
    >>> info_pane.drawWarning()  # Displays a warning to the player in the info pane
"""
        pass

    def clearIcon(self):
        """
    Clears the icon representation from the display.

    This method removes any graphical icon or representation of an agent (such as 
    Pacman or a ghost) from the screen. It is typically called when an agent is no 
    longer relevant, such as when it has been captured or has exited the game.

    Parameters:
    None

    Returns:
    None

    Example:
    >>> info_pane = InfoPane(layout, gridSize)
    >>> info_pane.clearIcon()  # Removes the icon representation from the info pane
"""
        pass

    def updateMessage(self, message):
        """
    Updates the displayed message in the info pane.

    This method modifies the text displayed to the player in the info pane 
    to reflect the current game status, alerts, or other informational messages. 
    It allows the game to communicate important updates to the player.

    Parameters:
    message (str): The message to be displayed to the player, which can provide 
                   status updates or alerts during the game.

    Returns:
    None

    Example:
    >>> info_pane = InfoPane(layout, gridSize)
    >>> info_pane.updateMessage("Warning: Ghosts are nearby!")  # Updates the message in the info pane
"""
        pass

    def clearMessage(self):
        """
    Clears the displayed message in the info pane.

    This method removes any currently displayed message in the info pane, allowing 
    for a fresh state for subsequent messages. It is typically called when the 
    relevant context of a previous message has changed or is no longer applicable.

    Parameters:
    None

    Returns:
    None

    Example:
    >>> info_pane = InfoPane(layout, gridSize)
    >>> info_pane.clearMessage()  # Clears the previous message from the info pane
"""
        pass


class PacmanGraphics:

    def __init__(self, zoom=1.0, frameTime=0.0, capture=False):
        """
    Initializes the InfoPane object for displaying game information.

    This constructor sets up the information pane at the bottom of the game window, 
    including the dimensions, text styles, and initial score display. It serves as 
    a container for any information relevant to the player, such as score and ghost 
    distances.

    Parameters:
    layout (Layout): The layout object of the game that defines the size and structure 
                     of the game grid.
    gridSize (float): The size of each grid cell in pixels, determining the scaling of 
                      the graphical elements within the info pane.

    Returns:
    None

    Example:
    >>> info_pane = InfoPane(layout, 30.0)  # Creates an InfoPane with a specified layout and grid size
"""
        self.have_window = 0
        self.currentGhostImages = {}
        self.pacmanImage = None
        self.zoom = zoom
        self.gridSize = DEFAULT_GRID_SIZE * zoom
        self.capture = capture
        self.frameTime = frameTime

    def checkNullDisplay(self):
        """
    Checks if the graphical display has been initialized.

    This method determines whether the graphics display is null or not initialized, 
    indicating that graphics cannot be rendered. It can be used to prevent 
    attempting to draw or update graphical elements when the display is not ready.

    Parameters:
    None

    Returns:
    bool: Returns True if the display is not initialized (null), and False otherwise.

    Example:
    >>> graphics = PacmanGraphics()
    >>> if graphics.checkNullDisplay(): 
    ...     print("Graphics has not been initialized.")
"""
        return False

    def initialize(self, state, isBlue=False):
        """
    Initializes the graphical display with the current game state.

    This method sets up the graphics environment by starting the graphical window, 
    rendering static elements such as walls and food, and drawing the agent objects 
    (Pacman and ghosts). It prepares the environment for visual updates as the game 
    progresses.

    Parameters:
    state (GameState): The current state of the game, which includes information 
                       about the layout, agent states, and other static and dynamic 
                       game elements.
    isBlue (bool): A flag indicating whether the current game session is for the Blue team. 
                   Default is False.

    Returns:
    None

    Example:
    >>> game_state = ...  # obtain the current state of the game
    >>> graphics = PacmanGraphics()
    >>> graphics.initialize(game_state, isBlue=True)  # Initializes graphics for the Blue team
"""
        self.isBlue = isBlue
        self.startGraphics(state)
        self.distributionImages = None
        self.drawStaticObjects(state)
        self.drawAgentObjects(state)
        self.previousState = state

    def startGraphics(self, state):
        """
    Sets up the graphical window and layout for the game.

    This method initializes the graphics environment by creating a window based on the 
    dimensions of the game layout. It configures the info pane and prepares the display 
    for subsequent rendering of game elements.

    Parameters:
    state (GameState): The current state of the game, which includes the layout 
                       information needed to set up the graphical window.

    Returns:
    None

    Example:
    >>> graphics = PacmanGraphics()
    >>> game_state = ...  # obtain the current state of the game
    >>> graphics.startGraphics(game_state)  # Initializes the graphics window for the game
"""
        self.layout = state.layout
        layout = self.layout
        self.width = layout.width
        self.height = layout.height
        self.make_window(self.width, self.height)
        self.infoPane = InfoPane(layout, self.gridSize)
        self.currentState = layout

    def drawDistributions(self, state):
        """
    Draws probability distributions on the game layout.

    This method creates a visual representation of the agent's belief distributions 
    over the game grid. It helps in visualizing the likelihood of the agent's 
    beliefs about the positions of ghosts based on the current state of the game.

    Parameters:
    state (GameState): The current state of the game, which includes layout information 
                       and any relevant distribution data for agents.

    Returns:
    None

    Example:
    >>> graphics = PacmanGraphics()
    >>> game_state = ...  # obtain the current state of the game
    >>> graphics.drawDistributions(game_state)  # Draws the belief distributions onto the game grid
"""
        walls = state.layout.walls
        dist = []
        for x in range(walls.width):
            distx = []
            dist.append(distx)
            for y in range(walls.height):
                screen_x, screen_y = self.to_screen((x, y))
                block = square((screen_x, screen_y), 0.5 * self.gridSize,
                    color=BACKGROUND_COLOR, filled=1, behind=2)
                distx.append(block)
        self.distributionImages = dist

    def drawStaticObjects(self, state):
        """
    Draws all static objects on the game layout.

    This method renders the static elements of the game environment, such as walls, 
    food, and capsules, onto the graphical display. It ensures that these elements are 
    visually represented according to the current game state before any dynamic objects 
    (like agents) are drawn.

    Parameters:
    state (GameState): The current state of the game, which contains information about 
                       the layout including the positions of walls, food, and capsules.

    Returns:
    None

    Example:
    >>> graphics = PacmanGraphics()
    >>> game_state = ...  # obtain the current state of the game
    >>> graphics.drawStaticObjects(game_state)  # Draws the static elements of the game layout
"""
        layout = self.layout
        self.drawWalls(layout.walls)
        self.food = self.drawFood(layout.food)
        self.capsules = self.drawCapsules(layout.capsules)
        refresh()

    def drawAgentObjects(self, state):
        """
    Draws the agent objects (Pacman and ghosts) on the screen.

    This method is responsible for rendering all agent characters in the current game state. 
    It distinguishes between Pacman and ghost characters, drawing each with their respective 
    attributes based on their states, such as position and direction.

    Parameters:
    state (GameState): The current state of the game, which includes information 
                       about the agent states and their configurations.

    Returns:
    None

    Example:
    >>> graphics = PacmanGraphics()
    >>> game_state = ...  # obtain the current state of the game
    >>> graphics.drawAgentObjects(game_state)  # Draws all agents (Pacman and ghosts) on the screen
"""
        self.agentImages = []
        for index, agent in enumerate(state.agentStates):
            if agent.isPacman:
                image = self.drawPacman(agent, index)
                self.agentImages.append((agent, image))
            else:
                image = self.drawGhost(agent, index)
                self.agentImages.append((agent, image))
        refresh()

    def swapImages(self, agentIndex, newState):
        """
          Changes an image from a ghost to a pacman or vis versa (for capture)
        """
        prevState, prevImage = self.agentImages[agentIndex]
        for item in prevImage:
            remove_from_screen(item)
        if newState.isPacman:
            image = self.drawPacman(newState, agentIndex)
            self.agentImages[agentIndex] = newState, image
        else:
            image = self.drawGhost(newState, agentIndex)
            self.agentImages[agentIndex] = newState, image
        refresh()

    def update(self, newState):
        """
    Updates the graphical display with the new game state.

    This method refreshes the visual representation of the game by updating the positions 
    and states of agents (Pacman and ghosts) in accordance with the provided new game state. 
    It manages animations for moving agents, updates scores, and reflects any changes to 
    food or capsules consumed during the game.

    Parameters:
    newState (GameState): The new state of the game that contains updated information 
                          about agent positions, scores, and any changes to the game layout.

    Returns:
    None

    Example:
    >>> graphics = PacmanGraphics()
    >>> new_game_state = ...  # obtain the updated state of the game
    >>> graphics.update(new_game_state)  # Updates the display with the new game state
"""
        agentIndex = newState._agentMoved
        agentState = newState.agentStates[agentIndex]
        if self.agentImages[agentIndex][0].isPacman != agentState.isPacman:
            self.swapImages(agentIndex, agentState)
        prevState, prevImage = self.agentImages[agentIndex]
        if agentState.isPacman:
            self.animatePacman(agentState, prevState, prevImage)
        else:
            self.moveGhost(agentState, agentIndex, prevState, prevImage)
        self.agentImages[agentIndex] = agentState, prevImage
        if newState._foodEaten != None:
            self.removeFood(newState._foodEaten, self.food)
        if newState._capsuleEaten != None:
            self.removeCapsule(newState._capsuleEaten, self.capsules)
        self.infoPane.updateScore(newState.score)
        if 'ghostDistances' in dir(newState):
            self.infoPane.updateGhostDistances(newState.ghostDistances)

    def make_window(self, width, height):
        """
    Creates the graphical window for the game display.

    This method initializes a window for the game graphics based on the given width and height, 
    which are calculated from the layout of the game. It sets the background color and title 
    for the window, preparing it for rendering game elements.

    Parameters:
    width (int): The width of the game layout, in grid cells, which will be converted to pixels 
                 based on the grid size.
    height (int): The height of the game layout, in grid cells, which will also be converted to 
                  pixels based on the grid size.

    Returns:
    None

    Example:
    >>> graphics = PacmanGraphics()
    >>> graphics.make_window(28, 31)  # Creates a window for a game layout of 28x31 grid cells
"""
        grid_width = (width - 1) * self.gridSize
        grid_height = (height - 1) * self.gridSize
        screen_width = 2 * self.gridSize + grid_width
        screen_height = 2 * self.gridSize + grid_height + INFO_PANE_HEIGHT
        begin_graphics(screen_width, screen_height, BACKGROUND_COLOR,
            'CS188 Pacman')

    def drawPacman(self, pacman, index):
        """
    Draws the Pacman character on the screen.

    This method creates a graphical representation of the Pacman character based on 
    its current state and position within the game. It renders Pacman with the correct 
    color, size, direction of movement, and an outline when in capture mode.

    Parameters:
    pacman (AgentState): The current state of the Pacman, which includes information 
                         about its position and direction of movement.
    index (int): The index of Pacman in the list of agents, used to determine its 
                  color and appearance, particularly when in capture mode.

    Returns:
    list: A list of graphical objects representing Pacman, including the body and 
          endpoints for the mouth indicating its direction.

    Example:
    >>> pacman_state = ...  # Obtain the Pacman's current state from the game
    >>> index = 0  # Index of Pacman in the agent list
    >>> pacman_image = graphics.drawPacman(pacman_state, index)  # Draws Pacman on the screen
"""
        position = self.getPosition(pacman)
        screen_point = self.to_screen(position)
        endpoints = self.getEndpoints(self.getDirection(pacman))
        width = PACMAN_OUTLINE_WIDTH
        outlineColor = PACMAN_COLOR
        fillColor = PACMAN_COLOR
        if self.capture:
            outlineColor = TEAM_COLORS[index % 2]
            fillColor = GHOST_COLORS[index]
            width = PACMAN_CAPTURE_OUTLINE_WIDTH
        return [circle(screen_point, PACMAN_SCALE * self.gridSize,
            fillColor=fillColor, outlineColor=outlineColor, endpoints=
            endpoints, width=width)]

    def getEndpoints(self, direction, position=(0, 0)):
        """
    Calculates the endpoints for the Pacman's mouth based on the direction of movement.

    This method determines the angular endpoints that define the open mouth of the 
    Pacman character. It uses the current direction to calculate the range of angles 
    for the mouth's opening, which is animated as Pacman moves around the game field.

    Parameters:
    direction (str): The direction in which Pacman is facing, represented as a string 
                     (e.g., 'North', 'South', 'East', 'West').
    position (tuple): A tuple representing the current (x, y) position of Pacman. 
                      Defaults to (0, 0) if not provided.

    Returns:
    tuple: A tuple containing two values representing the start and end angles 
           of the mouth's opening.

    Example:
    >>> endpoints = graphics.getEndpoints('North', (5, 5))  # Gets the endpoints for Pacman facing North
    >>> print(endpoints)  # Outputs the tuple of angles for the mouth opening
"""
        x, y = position
        pos = x - int(x) + y - int(y)
        width = 30 + 80 * math.sin(math.pi * pos)
        delta = width / 2
        if direction == 'West':
            endpoints = 180 + delta, 180 - delta
        elif direction == 'North':
            endpoints = 90 + delta, 90 - delta
        elif direction == 'South':
            endpoints = 270 + delta, 270 - delta
        else:
            endpoints = 0 + delta, 0 - delta
        return endpoints

    def movePacman(self, position, direction, image):
        """
    Moves the Pacman character to a new position on the screen.

    This method updates the graphical representation of Pacman by moving its position 
    based on the calculated screen coordinates. It adjusts the direction of the mouth 
    based on the current direction of movement, providing a visual indication of the 
    character's movement.

    Parameters:
    position (tuple): A tuple representing the new (x, y) coordinates to which Pacman 
                      will be moved on the screen.
    direction (str): The direction in which Pacman is currently facing, used to adjust 
                     the orientation of the mouth.
    image (list): A list of graphical objects representing the current drawing of Pacman, 
                  which will be updated to reflect the new position.

    Returns:
    None

    Example:
    >>> new_position = (150, 150)  # New screen coordinates for Pacman
    >>> direction = 'East'  # Direction Pacman is facing
    >>> graphics.movePacman(new_position, direction, pacman_image)  # Moves Pacman to the new position
"""
        screenPosition = self.to_screen(position)
        endpoints = self.getEndpoints(direction, position)
        r = PACMAN_SCALE * self.gridSize
        moveCircle(image[0], screenPosition, r, endpoints)
        refresh()

    def animatePacman(self, pacman, prevPacman, image):
        """
    Animates the movement of the Pacman character between positions.

    This method provides a smooth transition for Pacman when it moves from one position 
    to another. It splits the movement into multiple frames, allowing for gradual 
    animation and visual updates. It can also handle user input to allow for stepping 
    through the animation at a controlled pace.

    Parameters:
    pacman (AgentState): The current state of Pacman, containing updated position 
                         information.
    prevPacman (AgentState): The previous state of Pacman, used to determine the 
                             starting position for the animation.
    image (list): A list of graphical objects representing the current drawing of Pacman, 
                  which will be animated to reflect the movement.

    Returns:
    None

    Example:
    >>> current_state = ...  # Obtain the current state of Pacman
    >>> previous_state = ...  # Obtain the previous state of Pacman
    >>> graphics.animatePacman(current_state, previous_state, pacman_image)  # Animates Pacman movement
"""
        if self.frameTime < 0:
            print('Press any key to step forward, "q" to play')
            keys = wait_for_keys()
            if 'q' in keys:
                self.frameTime = 0.1
        if self.frameTime > 0.01 or self.frameTime < 0:
            start = time.time()
            fx, fy = self.getPosition(prevPacman)
            px, py = self.getPosition(pacman)
            frames = 4.0
            for i in range(1, int(frames) + 1):
                pos = px * i / frames + fx * (frames - i
                    ) / frames, py * i / frames + fy * (frames - i) / frames
                self.movePacman(pos, self.getDirection(pacman), image)
                refresh()
                sleep(abs(self.frameTime) / frames)
        else:
            self.movePacman(self.getPosition(pacman), self.getDirection(
                pacman), image)
        refresh()

    def getGhostColor(self, ghost, ghostIndex):
        """
    Retrieves the color representation of a ghost character based on its state.

    This method determines and returns the appropriate color for a ghost depending 
    on whether it is in a scared state or not. The color may vary based on the ghost's 
    index, allowing for different visual appearances for each ghost.

    Parameters:
    ghost (AgentState): The current state of the ghost, which contains information 
                        about its scared timer.
    ghostIndex (int): The index of the ghost in the list of agents, used to select 
                      the corresponding ghost color.

    Returns:
    Color: A color representation of the ghost, which can be a standard color or 
           a scared color if the ghost is frightened.

    Example:
    >>> ghost_state = ...  # Obtain the ghost's current state from the game
    >>> ghost_color = graphics.getGhostColor(ghost_state, 1)  # Gets the color for the second ghost
"""
        if ghost.scaredTimer > 0:
            return SCARED_COLOR
        else:
            return GHOST_COLORS[ghostIndex]

    def drawGhost(self, ghost, agentIndex):
        """
    Draws a ghost character on the screen.

    This method creates a graphical representation of a ghost based on its current 
    state and position within the game. It renders the ghost with the appropriate 
    color, shape, and features such as eyes, depending on whether the ghost is 
    in a scared state or not.

    Parameters:
    ghost (AgentState): The current state of the ghost, which includes information 
                        about its position, direction, and whether it is scared.
    agentIndex (int): The index of the ghost in the list of agents, used to determine 
                      the ghost's color and behavior when rendering it on the screen.

    Returns:
    list: A list of graphical objects representing the ghost, including its body and 
          facial features such as eyes.

    Example:
    >>> ghost_state = ...  # Obtain the ghost's current state from the game
    >>> index = 0  # Index of the ghost in the agent list
    >>> ghost_image_parts = graphics.drawGhost(ghost_state, index)  # Draws the ghost on the screen
"""
        pos = self.getPosition(ghost)
        dir = self.getDirection(ghost)
        screen_x, screen_y = self.to_screen(pos)
        coords = []
        for x, y in GHOST_SHAPE:
            coords.append((x * self.gridSize * GHOST_SIZE + screen_x, y *
                self.gridSize * GHOST_SIZE + screen_y))
        colour = self.getGhostColor(ghost, agentIndex)
        body = polygon(coords, colour, filled=1)
        WHITE = formatColor(1.0, 1.0, 1.0)
        BLACK = formatColor(0.0, 0.0, 0.0)
        dx = 0
        dy = 0
        if dir == 'North':
            dy = -0.2
        if dir == 'South':
            dy = 0.2
        if dir == 'East':
            dx = 0.2
        if dir == 'West':
            dx = -0.2
        leftEye = circle((screen_x + self.gridSize * GHOST_SIZE * (-0.3 + 
            dx / 1.5), screen_y - self.gridSize * GHOST_SIZE * (0.3 - dy / 
            1.5)), self.gridSize * GHOST_SIZE * 0.2, WHITE, WHITE)
        rightEye = circle((screen_x + self.gridSize * GHOST_SIZE * (0.3 + 
            dx / 1.5), screen_y - self.gridSize * GHOST_SIZE * (0.3 - dy / 
            1.5)), self.gridSize * GHOST_SIZE * 0.2, WHITE, WHITE)
        leftPupil = circle((screen_x + self.gridSize * GHOST_SIZE * (-0.3 +
            dx), screen_y - self.gridSize * GHOST_SIZE * (0.3 - dy)), self.
            gridSize * GHOST_SIZE * 0.08, BLACK, BLACK)
        rightPupil = circle((screen_x + self.gridSize * GHOST_SIZE * (0.3 +
            dx), screen_y - self.gridSize * GHOST_SIZE * (0.3 - dy)), self.
            gridSize * GHOST_SIZE * 0.08, BLACK, BLACK)
        ghostImageParts = []
        ghostImageParts.append(body)
        ghostImageParts.append(leftEye)
        ghostImageParts.append(rightEye)
        ghostImageParts.append(leftPupil)
        ghostImageParts.append(rightPupil)
        return ghostImageParts

    def moveEyes(self, pos, dir, eyes):
        """
    Moves the eyes of a ghost character to match its current position and direction.

    This method updates the graphical representation of the ghost's eyes based on the 
    ghost's current position and the direction it is facing. This adds a dynamic and 
    expressive quality to the ghost's appearance, making it appear more lifelike during 
    movement.

    Parameters:
    pos (tuple): A tuple representing the current (x, y) position of the ghost on the 
                 screen.
    dir (str): The direction in which the ghost is currently facing, used to adjust 
               the position of the eyes accordingly.
    eyes (list): A list of graphical objects representing the ghost's eyes, which will 
                 be moved to reflect the ghost’s current position and direction.

    Returns:
    None

    Example:
    >>> ghost_position = (100, 150)  # Current screen coordinates of the ghost
    >>> direction = 'North'  # Direction the ghost is facing
    >>> graphics.moveEyes(ghost_position, direction, ghost_eye_parts)  # Moves the ghost's eyes accordingly
"""
        screen_x, screen_y = self.to_screen(pos)
        dx = 0
        dy = 0
        if dir == 'North':
            dy = -0.2
        if dir == 'South':
            dy = 0.2
        if dir == 'East':
            dx = 0.2
        if dir == 'West':
            dx = -0.2
        moveCircle(eyes[0], (screen_x + self.gridSize * GHOST_SIZE * (-0.3 +
            dx / 1.5), screen_y - self.gridSize * GHOST_SIZE * (0.3 - dy / 
            1.5)), self.gridSize * GHOST_SIZE * 0.2)
        moveCircle(eyes[1], (screen_x + self.gridSize * GHOST_SIZE * (0.3 +
            dx / 1.5), screen_y - self.gridSize * GHOST_SIZE * (0.3 - dy / 
            1.5)), self.gridSize * GHOST_SIZE * 0.2)
        moveCircle(eyes[2], (screen_x + self.gridSize * GHOST_SIZE * (-0.3 +
            dx), screen_y - self.gridSize * GHOST_SIZE * (0.3 - dy)), self.
            gridSize * GHOST_SIZE * 0.08)
        moveCircle(eyes[3], (screen_x + self.gridSize * GHOST_SIZE * (0.3 +
            dx), screen_y - self.gridSize * GHOST_SIZE * (0.3 - dy)), self.
            gridSize * GHOST_SIZE * 0.08)

    def moveGhost(self, ghost, ghostIndex, prevGhost, ghostImageParts):
        """
    Moves a ghost character to its new position on the screen.

    This method updates the graphical representation of a ghost by moving its position 
    based on the provided new coordinates. It animates the ghost's movement, updating the 
    visual elements to ensure a smooth transition. It also adjusts the color of the ghost 
    based on its state (scared or normal) and moves the ghost's eyes accordingly.

    Parameters:
    ghost (AgentState): The current state of the ghost, which includes information 
                        about its new position and scared state.
    ghostIndex (int): The index of the ghost in the list of agents, used to determine 
                      the ghost's color and appearance.
    prevGhost (AgentState): The previous state of the ghost, used for calculating 
                            the movement delta and ensuring smooth animation.
    ghostImageParts (list): A list of graphical objects representing the current drawing 
                            of the ghost, which will be updated to reflect the new position 
                            and state.

    Returns:
    None

    Example:
    >>> current_ghost_state = ...  # Obtain the current state of the ghost
    >>> previous_ghost_state = ...  # Obtain the previous state of the ghost
    >>> graphics.moveGhost(current_ghost_state, 0, previous_ghost_state, ghost_image_parts)  # Moves the ghost on the screen
"""
        old_x, old_y = self.to_screen(self.getPosition(prevGhost))
        new_x, new_y = self.to_screen(self.getPosition(ghost))
        delta = new_x - old_x, new_y - old_y
        for ghostImagePart in ghostImageParts:
            move_by(ghostImagePart, delta)
        refresh()
        if ghost.scaredTimer > 0:
            color = SCARED_COLOR
        else:
            color = GHOST_COLORS[ghostIndex]
        edit(ghostImageParts[0], ('fill', color), ('outline', color))
        self.moveEyes(self.getPosition(ghost), self.getDirection(ghost),
            ghostImageParts[-4:])
        refresh()

    def getPosition(self, agentState):
        """
    Retrieves the (x, y) position of an agent (Pacman or ghost).

    This method extracts and returns the current position of an agent based on its state. 
    It handles the case where the agent's configuration may be invalid or uninitialized, 
    ensuring that a valid position is returned when possible.

    Parameters:
    agentState (AgentState): The current state of the agent, which contains information 
                             about its configuration and position.

    Returns:
    tuple: A tuple representing the (x, y) coordinates of the agent. If the agent's 
           configuration is None, it returns (-1000, -1000) to indicate an invalid position.

    Example:
    >>> pacman_state = ...  # Obtain the current state of Pacman
    >>> position = graphics.getPosition(pacman_state)  # Gets the current position of Pacman
    >>> print(position)  # Outputs the (x, y) coordinates of Pacman
"""
        if agentState.configuration == None:
            return -1000, -1000
        return agentState.getPosition()

    def getDirection(self, agentState):
        """
    Retrieves the direction in which an agent (Pacman or ghost) is moving.

    This method extracts and returns the current direction of an agent based on its 
    state. It handles cases where the agent's configuration may be invalid, ensuring 
    that a default direction is returned when necessary.

    Parameters:
    agentState (AgentState): The current state of the agent, which contains information 
                             about its configuration.

    Returns:
    str: A string representing the direction in which the agent is moving (e.g., 
         'North', 'South', 'East', 'West'). If the agent's configuration is None, 
         it returns 'Stop' to indicate that the agent is not moving.

    Example:
    >>> pacman_state = ...  # Obtain the current state of Pacman
    >>> direction = graphics.getDirection(pacman_state)  # Gets the current direction of Pacman
    >>> print(direction)  # Outputs the direction in which Pacman is facing
"""
        if agentState.configuration == None:
            return Directions.STOP
        return agentState.configuration.getDirection()

    def finish(self):
        """
    Ends the graphical display session and cleans up resources.

    This method finalizes the graphical display by closing the graphics window and 
    releasing any resources that were allocated during the graphics operation. It 
    should be called when the game is finished to ensure that all graphical 
    elements are properly disposed of.

    Parameters:
    None

    Returns:
    None

    Example:
    >>> graphics = PacmanGraphics()
    >>> graphics.finish()  # Closes the graphics window and ends the session
"""
        end_graphics()

    def to_screen(self, point):
        """
    Converts grid coordinates to screen coordinates.

    This method translates a given point from the game grid (in grid coordinates) 
    to the corresponding position on the screen (in pixel coordinates). It accounts 
    for the dimensions of the game layout and scales the coordinates accordingly 
    for proper rendering.

    Parameters:
    point (tuple): A tuple representing the (x, y) coordinates in the game grid.

    Returns:
    tuple: A tuple representing the (x, y) coordinates on the screen, scaled based on 
           the grid size and layout dimensions.

    Example:
    >>> grid_position = (2, 3)  # Example grid coordinates
    >>> screen_position = graphics.to_screen(grid_position)  # Converts to screen coordinates
    >>> print(screen_position)  # Outputs the (x, y) pixel coordinates for the screen
"""
        x, y = point
        x = (x + 1) * self.gridSize
        y = (self.height - y) * self.gridSize
        return x, y

    def to_screen2(self, point):
        """
    Converts grid coordinates to screen coordinates with specific adjustments.

    This method translates a given point from the game grid (in grid coordinates) 
    to the corresponding position on the screen (in pixel coordinates). It is similar 
    to the `to_screen` method but may accommodate specific adjustments needed for 
    rendering. It ensures the coordinates are properly scaled and positioned on the 
    display.

    Parameters:
    point (tuple): A tuple representing the (x, y) coordinates in the game grid.

    Returns:
    tuple: A tuple representing the (x, y) coordinates on the screen, scaled and 
           adjusted based on the grid size and layout dimensions.

    Example:
    >>> grid_position = (4, 5)  # Example grid coordinates
    >>> screen_position = graphics.to_screen2(grid_position)  # Converts to screen coordinates with adjustments
    >>> print(screen_position)  # Outputs the adjusted (x, y) pixel coordinates for the screen
"""
        x, y = point
        x = (x + 1) * self.gridSize
        y = (self.height - y) * self.gridSize
        return x, y

    def drawWalls(self, wallMatrix):
        """
    Draws the walls of the game layout on the screen.

    This method renders the walls of the game based on the wall matrix provided in 
    the game layout. It considers adjacent wall positions to properly draw the 
    walls, including handling the appearance of corners and edges. The visual 
    representation is created using shapes and lines to accurately depict the 
    game's boundaries.

    Parameters:
    wallMatrix (list of list of bool): A matrix representing the layout of the walls, 
                                         where each boolean indicates the presence 
                                         (True) or absence (False) of a wall at that 
                                         grid location.

    Returns:
    None

    Example:
    >>> wall_matrix = [[True, False, True], [False, True, False], [True, True, True]]
    >>> graphics.drawWalls(wall_matrix)  # Draws the walls based on the provided matrix
"""
        wallColor = WALL_COLOR
        for xNum, x in enumerate(wallMatrix):
            if self.capture and xNum * 2 < wallMatrix.width:
                wallColor = TEAM_COLORS[0]
            if self.capture and xNum * 2 >= wallMatrix.width:
                wallColor = TEAM_COLORS[1]
            for yNum, cell in enumerate(x):
                if cell:
                    pos = xNum, yNum
                    screen = self.to_screen(pos)
                    screen2 = self.to_screen2(pos)
                    wIsWall = self.isWall(xNum - 1, yNum, wallMatrix)
                    eIsWall = self.isWall(xNum + 1, yNum, wallMatrix)
                    nIsWall = self.isWall(xNum, yNum + 1, wallMatrix)
                    sIsWall = self.isWall(xNum, yNum - 1, wallMatrix)
                    nwIsWall = self.isWall(xNum - 1, yNum + 1, wallMatrix)
                    swIsWall = self.isWall(xNum - 1, yNum - 1, wallMatrix)
                    neIsWall = self.isWall(xNum + 1, yNum + 1, wallMatrix)
                    seIsWall = self.isWall(xNum + 1, yNum - 1, wallMatrix)
                    if not nIsWall and not eIsWall:
                        circle(screen2, WALL_RADIUS * self.gridSize,
                            wallColor, wallColor, (0, 91), 'arc')
                    if nIsWall and not eIsWall:
                        line(add(screen, (self.gridSize * WALL_RADIUS, 0)),
                            add(screen, (self.gridSize * WALL_RADIUS, self.
                            gridSize * -0.5 - 1)), wallColor)
                    if not nIsWall and eIsWall:
                        line(add(screen, (0, self.gridSize * -1 *
                            WALL_RADIUS)), add(screen, (self.gridSize * 0.5 +
                            1, self.gridSize * -1 * WALL_RADIUS)), wallColor)
                    if nIsWall and eIsWall and not neIsWall:
                        circle(add(screen2, (self.gridSize * 2 *
                            WALL_RADIUS, self.gridSize * -2 * WALL_RADIUS)),
                            WALL_RADIUS * self.gridSize - 1, wallColor,
                            wallColor, (180, 271), 'arc')
                        line(add(screen, (self.gridSize * 2 * WALL_RADIUS -
                            1, self.gridSize * -1 * WALL_RADIUS)), add(
                            screen, (self.gridSize * 0.5 + 1, self.gridSize *
                            -1 * WALL_RADIUS)), wallColor)
                        line(add(screen, (self.gridSize * WALL_RADIUS, self
                            .gridSize * -2 * WALL_RADIUS + 1)), add(screen,
                            (self.gridSize * WALL_RADIUS, self.gridSize * -
                            0.5)), wallColor)
                    if not nIsWall and not wIsWall:
                        circle(screen2, WALL_RADIUS * self.gridSize,
                            wallColor, wallColor, (90, 181), 'arc')
                    if nIsWall and not wIsWall:
                        line(add(screen, (self.gridSize * -1 * WALL_RADIUS,
                            0)), add(screen, (self.gridSize * -1 *
                            WALL_RADIUS, self.gridSize * -0.5 - 1)), wallColor)
                    if not nIsWall and wIsWall:
                        line(add(screen, (0, self.gridSize * -1 *
                            WALL_RADIUS)), add(screen, (self.gridSize * -
                            0.5 - 1, self.gridSize * -1 * WALL_RADIUS)),
                            wallColor)
                    if nIsWall and wIsWall and not nwIsWall:
                        circle(add(screen2, (self.gridSize * -2 *
                            WALL_RADIUS, self.gridSize * -2 * WALL_RADIUS)),
                            WALL_RADIUS * self.gridSize - 1, wallColor,
                            wallColor, (270, 361), 'arc')
                        line(add(screen, (self.gridSize * -2 * WALL_RADIUS +
                            1, self.gridSize * -1 * WALL_RADIUS)), add(
                            screen, (self.gridSize * -0.5, self.gridSize * 
                            -1 * WALL_RADIUS)), wallColor)
                        line(add(screen, (self.gridSize * -1 * WALL_RADIUS,
                            self.gridSize * -2 * WALL_RADIUS + 1)), add(
                            screen, (self.gridSize * -1 * WALL_RADIUS, self
                            .gridSize * -0.5)), wallColor)
                    if not sIsWall and not eIsWall:
                        circle(screen2, WALL_RADIUS * self.gridSize,
                            wallColor, wallColor, (270, 361), 'arc')
                    if sIsWall and not eIsWall:
                        line(add(screen, (self.gridSize * WALL_RADIUS, 0)),
                            add(screen, (self.gridSize * WALL_RADIUS, self.
                            gridSize * 0.5 + 1)), wallColor)
                    if not sIsWall and eIsWall:
                        line(add(screen, (0, self.gridSize * 1 *
                            WALL_RADIUS)), add(screen, (self.gridSize * 0.5 +
                            1, self.gridSize * 1 * WALL_RADIUS)), wallColor)
                    if sIsWall and eIsWall and not seIsWall:
                        circle(add(screen2, (self.gridSize * 2 *
                            WALL_RADIUS, self.gridSize * 2 * WALL_RADIUS)),
                            WALL_RADIUS * self.gridSize - 1, wallColor,
                            wallColor, (90, 181), 'arc')
                        line(add(screen, (self.gridSize * 2 * WALL_RADIUS -
                            1, self.gridSize * 1 * WALL_RADIUS)), add(
                            screen, (self.gridSize * 0.5, self.gridSize * 1 *
                            WALL_RADIUS)), wallColor)
                        line(add(screen, (self.gridSize * WALL_RADIUS, self
                            .gridSize * 2 * WALL_RADIUS - 1)), add(screen,
                            (self.gridSize * WALL_RADIUS, self.gridSize * 
                            0.5)), wallColor)
                    if not sIsWall and not wIsWall:
                        circle(screen2, WALL_RADIUS * self.gridSize,
                            wallColor, wallColor, (180, 271), 'arc')
                    if sIsWall and not wIsWall:
                        line(add(screen, (self.gridSize * -1 * WALL_RADIUS,
                            0)), add(screen, (self.gridSize * -1 *
                            WALL_RADIUS, self.gridSize * 0.5 + 1)), wallColor)
                    if not sIsWall and wIsWall:
                        line(add(screen, (0, self.gridSize * 1 *
                            WALL_RADIUS)), add(screen, (self.gridSize * -
                            0.5 - 1, self.gridSize * 1 * WALL_RADIUS)),
                            wallColor)
                    if sIsWall and wIsWall and not swIsWall:
                        circle(add(screen2, (self.gridSize * -2 *
                            WALL_RADIUS, self.gridSize * 2 * WALL_RADIUS)),
                            WALL_RADIUS * self.gridSize - 1, wallColor,
                            wallColor, (0, 91), 'arc')
                        line(add(screen, (self.gridSize * -2 * WALL_RADIUS +
                            1, self.gridSize * 1 * WALL_RADIUS)), add(
                            screen, (self.gridSize * -0.5, self.gridSize * 
                            1 * WALL_RADIUS)), wallColor)
                        line(add(screen, (self.gridSize * -1 * WALL_RADIUS,
                            self.gridSize * 2 * WALL_RADIUS - 1)), add(
                            screen, (self.gridSize * -1 * WALL_RADIUS, self
                            .gridSize * 0.5)), wallColor)

    def isWall(self, x, y, walls):
        """
    Checks if a specified grid position contains a wall.

    This method determines whether a cell in the game grid is a wall based on the 
    provided wall matrix. It checks the validity of the grid coordinates to ensure 
    that the query does not exceed the boundaries of the layout.

    Parameters:
    x (int): The x-coordinate of the grid cell to be checked.
    y (int): The y-coordinate of the grid cell to be checked.
    walls (WallMatrix): The matrix representing the game layout, where each entry 
                        indicates the presence or absence of a wall.

    Returns:
    bool: Returns True if there is a wall at the specified grid position, and False 
          otherwise.

    Example:
    >>> wall_matrix = [[True, False, True], [False, True, False], [True, True, True]]
    >>> has_wall = graphics.isWall(0, 1, wall_matrix)  # Checks if there's a wall at (0, 1)
    >>> print(has_wall)  # Outputs: False
"""
        if x < 0 or y < 0:
            return False
        if x >= walls.width or y >= walls.height:
            return False
        return walls[x][y]

    def drawFood(self, foodMatrix):
        """
    Draws the food items on the game layout.

    This method renders the food elements in the game based on the provided food 
    matrix. It visually represents each food item as small circles on the screen, 
    allowing Pacman to see their locations. Each food item is drawn only if it is 
    present in the specified grid position.

    Parameters:
    foodMatrix (list of list of bool): A matrix representing the layout of the food, 
                                         where each boolean indicates the presence 
                                         (True) or absence (False) of food at that 
                                         grid location.

    Returns:
    list: A nested list of graphical objects representing the drawn food items, where 
          each sublist corresponds to a row in the food matrix.

    Example:
    >>> food_matrix = [[True, False, True], [False, True, False], [True, True, True]]
    >>> food_images = graphics.drawFood(food_matrix)  # Draws the food items based on the provided matrix
"""
        foodImages = []
        color = FOOD_COLOR
        for xNum, x in enumerate(foodMatrix):
            if self.capture and xNum * 2 <= foodMatrix.width:
                color = TEAM_COLORS[0]
            if self.capture and xNum * 2 > foodMatrix.width:
                color = TEAM_COLORS[1]
            imageRow = []
            foodImages.append(imageRow)
            for yNum, cell in enumerate(x):
                if cell:
                    screen = self.to_screen((xNum, yNum))
                    dot = circle(screen, FOOD_SIZE * self.gridSize,
                        outlineColor=color, fillColor=color, width=1)
                    imageRow.append(dot)
                else:
                    imageRow.append(None)
        return foodImages

    def drawCapsules(self, capsules):
        """
    Draws the power capsules on the game layout.

    This method renders the capsules that Pacman can collect to gain temporary 
    abilities, such as the ability to eat ghosts. Each capsule is visually represented 
    as a larger circle on the screen, allowing Pacman to see their locations. 

    Parameters:
    capsules (list of tuples): A list of tuples, where each tuple contains the (x, y) 
                               coordinates of a capsule's location on the game grid.

    Returns:
    dict: A dictionary mapping each capsule's coordinates to the corresponding 
          graphical object representing that capsule on the screen.

    Example:
    >>> capsule_positions = [(1, 1), (2, 3)]
    >>> capsule_images = graphics.drawCapsules(capsule_positions)  # Draws the capsules based on the provided positions
"""
        capsuleImages = {}
        for capsule in capsules:
            screen_x, screen_y = self.to_screen(capsule)
            dot = circle((screen_x, screen_y), CAPSULE_SIZE * self.gridSize,
                outlineColor=CAPSULE_COLOR, fillColor=CAPSULE_COLOR, width=1)
            capsuleImages[capsule] = dot
        return capsuleImages

    def removeFood(self, cell, foodImages):
        """
    Removes a food item from the graphical display.

    This method updates the graphical representation by removing a specific food item 
    from the screen when it has been collected by Pacman. It identifies the food item 
    based on its grid coordinates and removes the corresponding graphical object.

    Parameters:
    cell (tuple): A tuple representing the (x, y) coordinates of the food item to be 
                  removed from the display.
    foodImages (list of list): A nested list of graphical objects representing the 
                                food items, where each sublist corresponds to a row 
                                in the food matrix.

    Returns:
    None

    Example:
    >>> food_matrix = [[True, False], [False, True]]
    >>> food_images = graphics.drawFood(food_matrix)  # Initial drawing of food
    >>> graphics.removeFood((1, 0), food_images)  # Removes the food item at (1, 0) from the display
"""
        x, y = cell
        remove_from_screen(foodImages[x][y])

    def removeCapsule(self, cell, capsuleImages):
        """
    Removes a capsule from the graphical display.

    This method updates the graphical representation by removing a specific capsule from 
    the screen when it has been collected by Pacman. It identifies the capsule based on 
    its grid coordinates and removes the corresponding graphical object.

    Parameters:
    cell (tuple): A tuple representing the (x, y) coordinates of the capsule to be 
                  removed from the display.
    capsuleImages (dict): A dictionary mapping capsule coordinates to their 
                          corresponding graphical objects on the screen.

    Returns:
    None

    Example:
    >>> capsule_positions = [(1, 1), (3, 2)]
    >>> capsule_images = graphics.drawCapsules(capsule_positions)  # Initial drawing of capsules
    >>> graphics.removeCapsule((1, 1), capsule_images)  # Removes the capsule at (1, 1) from the display
"""
        x, y = cell
        remove_from_screen(capsuleImages[x, y])

    def drawExpandedCells(self, cells):
        """
        Draws an overlay of expanded grid positions for search agents
        """
        n = float(len(cells))
        baseColor = [1.0, 0.0, 0.0]
        self.clearExpandedCells()
        self.expandedCells = []
        for k, cell in enumerate(cells):
            screenPos = self.to_screen(cell)
            cellColor = formatColor(*[((n - k) * c * 0.5 / n + 0.25) for c in
                baseColor])
            block = square(screenPos, 0.5 * self.gridSize, color=cellColor,
                filled=1, behind=2)
            self.expandedCells.append(block)
            if self.frameTime < 0:
                refresh()

    def clearExpandedCells(self):
        """
    Clears any highlighted expanded cells from the graphical display.

    This method removes the visual representation of expanded cells that were drawn 
    as part of a search or pathfinding algorithm. It ensures that the screen is 
    refreshed and ready for new commands or visuals without any remnants from 
    previous operations.

    Parameters:
    None

    Returns:
    None

    Example:
    >>> graphics.drawExpandedCells([(1, 1), (2, 2)])  # Draws expanded cells
    >>> graphics.clearExpandedCells()  # Clears highlighted expanded cells from the display
"""
        if 'expandedCells' in dir(self) and len(self.expandedCells) > 0:
            for cell in self.expandedCells:
                remove_from_screen(cell)

    def updateDistributions(self, distributions):
        """Draws an agent's belief distributions"""
        distributions = map(lambda x: x.copy(), distributions)
        if self.distributionImages == None:
            self.drawDistributions(self.previousState)
        for x in range(len(self.distributionImages)):
            for y in range(len(self.distributionImages[0])):
                image = self.distributionImages[x][y]
                weights = [dist[x, y] for dist in distributions]
                if sum(weights) != 0:
                    pass
                color = [0.0, 0.0, 0.0]
                colors = GHOST_VEC_COLORS[1:]
                if self.capture:
                    colors = GHOST_VEC_COLORS
                for weight, gcolor in zip(weights, colors):
                    color = [min(1.0, c + 0.95 * g * weight ** 0.3) for c,
                        g in zip(color, gcolor)]
                changeColor(image, formatColor(*color))
        refresh()


class FirstPersonPacmanGraphics(PacmanGraphics):

    def __init__(self, zoom=1.0, showGhosts=True, capture=False, frameTime=0):
        """
    Initializes the PacmanGraphics object for displaying the game.

    This constructor sets up the graphical display environment for the Pacman game, 
    including defining parameters such as zoom level, frame time for animations, 
    and capture mode. It prepares the essential attributes and configurations needed 
    for rendering the game's visual elements.

    Parameters:
    zoom (float): The zoom factor for scaling the graphics. Default is 1.0, which 
                  represents no scaling.
    frameTime (float): The time delay between frames in seconds for animations. 
                       Default is 0.0, indicating immediate updates without delay.
    capture (bool): A flag that indicates if the game is in capture mode, affecting 
                    the appearance of characters. Default is False.

    Returns:
    None

    Example:
    >>> graphics = PacmanGraphics(zoom=1.5, frameTime=0.1, capture=True)  # Creates an instance with custom settings
"""
        PacmanGraphics.__init__(self, zoom, frameTime=frameTime)
        self.showGhosts = showGhosts
        self.capture = capture

    def initialize(self, state, isBlue=False):
        """
    Initializes the graphical display with the current game state.

    This method sets up the graphics environment by starting the graphical window, 
    rendering static elements such as walls and food, and drawing agent objects 
    (Pacman and ghosts). It prepares the environment for visual updates as the game 
    progresses.

    Parameters:
    state (GameState): The current state of the game, which includes information 
                       about the layout, agent states, and other static and dynamic 
                       game elements.
    isBlue (bool): A flag indicating whether the current game session is for the Blue team. 
                   Default is False.

    Returns:
    None

    Example:
    >>> game_state = ...  # Obtain the current state of the game
    >>> graphics = PacmanGraphics()
    >>> graphics.initialize(game_state, isBlue=True)  # Initializes graphics for the Blue team
"""
        self.isBlue = isBlue
        PacmanGraphics.startGraphics(self, state)
        walls = state.layout.walls
        dist = []
        self.layout = state.layout
        self.distributionImages = None
        self.drawStaticObjects(state)
        self.drawAgentObjects(state)
        self.previousState = state

    def lookAhead(self, config, state):
        """
    Prepares and draws the relevant ghosts in the field of view based on the agent's direction.

    This method checks the current direction of the agent and determines which ghosts 
    are visible based on their positions. It draws the visibility of relevant ghosts to 
    enhance the player's understanding of the game dynamics.

    Parameters:
    config (Configuration): The current configuration of the agent, which provides 
                           information about the agent's direction.
    state (GameState): The current state of the game, which includes information about 
                       all ghosts and their visibility status.

    Returns:
    None

    Example:
    >>> agent_config = ...  # Obtain the current configuration of the agent
    >>> game_state = ...  # Obtain the current state of the game
    >>> graphics.lookAhead(agent_config, game_state)  # Prepares and displays visible ghosts
"""
        if config.getDirection() == 'Stop':
            return
        else:
            pass
            allGhosts = state.getGhostStates()
            visibleGhosts = state.getVisibleGhosts()
            for i, ghost in enumerate(allGhosts):
                if ghost in visibleGhosts:
                    self.drawGhost(ghost, i)
                else:
                    self.currentGhostImages[i] = None

    def getGhostColor(self, ghost, ghostIndex):
        """
    Retrieves the color of a ghost character based on its current state.

    This method determines the appropriate color to represent a ghost, taking into account 
    whether the ghost is in a scared state or its unique color based on its index in the 
    list of ghosts. This allows for different visual representations for each ghost 
    depending on their current behavior.

    Parameters:
    ghost (AgentState): The current state of the ghost, which includes information about 
                        its scared timer and position.
    ghostIndex (int): The index of the ghost within the list of agents, used to select 
                      the corresponding ghost color from a predefined set of colors.

    Returns:
    Color: The color representation of the ghost, which can either be a standard ghost 
           color or a scared color if the ghost is frightened.

    Example:
    >>> ghost_state = ...  # Obtain the ghost's current state from the game
    >>> color = graphics.getGhostColor(ghost_state, 1)  # Gets the color for the second ghost
"""
        return GHOST_COLORS[ghostIndex]

    def getPosition(self, ghostState):
        """
    Retrieves the current (x, y) position of an agent (Pacman or ghost).

    This method extracts and returns the position of an agent based on its state. 
    It handles cases where the agent's configuration may be invalid or uninitialized, 
    ensuring that a valid position is returned when possible.

    Parameters:
    agentState (AgentState): The current state of the agent, which contains information 
                             about its configuration and position.

    Returns:
    tuple: A tuple representing the (x, y) coordinates of the agent. If the agent's 
           configuration is None, it returns (-1000, -1000) to indicate an invalid position.

    Example:
    >>> pacman_state = ...  # Obtain the current state of Pacman
    >>> position = graphics.getPosition(pacman_state)  # Gets the current position of Pacman
    >>> print(position)  # Outputs the (x, y) coordinates of Pacman
"""
        if (not self.showGhosts and not ghostState.isPacman and ghostState.
            getPosition()[1] > 1):
            return -1000, -1000
        else:
            return PacmanGraphics.getPosition(self, ghostState)


def add(x, y):
    """
    Adds two tuples representing coordinates.

    This method computes the element-wise sum of two tuples, often used to 
    manipulate (x, y) coordinate pairs in the context of graphical representations 
    or movements within the game.

    Parameters:
    x (tuple): The first tuple representing coordinates (x1, y1).
    y (tuple): The second tuple representing coordinates (x2, y2).

    Returns:
    tuple: A tuple representing the resulting coordinates after addition, 
           computed as (x1 + x2, y1 + y2).

    Example:
    >>> point_a = (1, 2)
    >>> point_b = (3, 4)
    >>> result = add(point_a, point_b)  # Adds the two points
    >>> print(result)  # Outputs: (4, 6)
"""
    return x[0] + y[0], x[1] + y[1]


SAVE_POSTSCRIPT = False
POSTSCRIPT_OUTPUT_DIR = 'frames'
FRAME_NUMBER = 0
import os


def saveFrame():
    """Saves the current graphical output as a postscript file"""
    global SAVE_POSTSCRIPT, FRAME_NUMBER, POSTSCRIPT_OUTPUT_DIR
    if not SAVE_POSTSCRIPT:
        return
    if not os.path.exists(POSTSCRIPT_OUTPUT_DIR):
        os.mkdir(POSTSCRIPT_OUTPUT_DIR)
    name = os.path.join(POSTSCRIPT_OUTPUT_DIR, 'frame_%08d.ps' % FRAME_NUMBER)
    FRAME_NUMBER += 1
    writePostscript(name)
