# """
# searchAgents.py
# ----------------
# 
# This module contains various classes and functions that serve as agents for controlling the Pacman character in a grid-based game. These agents utilize different search algorithms to navigate the game environment effectively, targeting specific objectives such as reaching corners, collecting food, or minimizing movement costs.
# 
# Classes:
# 
# 1. GoWestAgent:
#    An agent that continually moves west until it can no longer do so.
# 
# 2. SearchAgent:
#    A general search agent that employs a specified search algorithm to find a path to a designated goal. It can utilize Depth First Search (DFS) or Breadth First Search (BFS), among others, based on user input.
# 
# 3. PositionSearchProblem:
#    A class that defines a search problem involving the positions in the Pacman game. It outlines the start state, goal state, successors, and costs of reaching those states.
# 
# 4. StayEastSearchAgent:
#    An agent designed to search positions while penalizing western positions in its cost function.
# 
# 5. StayWestSearchAgent:
#    An agent that penalizes eastern positions in its cost function while searching through positions.
# 
# 6. CornersProblem:
#    A search problem that requires the agent to visit all four corners of the grid. It maintains the state of corners (visited/unvisited) and defines methods to evaluate successors and goal states.
# 
# 7. AStarCornersAgent:
#    An agent that employs the A* search algorithm to navigate through a CornersProblem, using a defined heuristic.
# 
# 8. FoodSearchProblem:
#    A search class dedicated to finding paths that collect all food items in the Pacman game state. It defines the initial state, goal state, and potential successors.
# 
# 9. AStarFoodSearchAgent:
#    An agent that utilizes the A* search algorithm to solve the FoodSearchProblem using a specified heuristic.
# 
# 10. ClosestDotSearchAgent:
#     An agent that searches for food by finding a path to the nearest food dot until all food is collected.
# 
# 11. AnyFoodSearchProblem:
#     A specialized search problem that enables agents to find a path to any food dot on the grid.
# 
# Functions:
# 
# 1. manhattanHeuristic:
#    Computes the Manhattan distance heuristic for the PositionSearchProblem, providing a straightforward estimate of distance to the goal.
# 
# 2. euclideanHeuristic:
#    Computes the Euclidean distance heuristic for the PositionSearchProblem, providing a measure of distance based on straight-line distance.
# 
# 3. mazeDistance:
#    Determines the maze distance between two points in the Pacman grid, ignoring walls to provide a clear path length.
# 
# Documentation for Other Functions:
# - The function 'manhattanDistance' is defined outside of this module and calculates the Manhattan distance between two given points in the grid. It is a vital utility for various heuristics and distance calculations throughout the search problem classes.
# 
# Usage:
# To utilize the agents defined in this module, users can invoke specific classes and provide parameters through command line options to control their behavior in the Pacman game environment.
# 
# Note: Users are encouraged to customize agents within the guidelines provided, while preserving the integrity of the educational framework established by UC Berkeley.
# """

"""
This file contains all of the agents that can be selected to control Pacman.  To
select an agent, use the '-p' option when running pacman.py.  Arguments can be
passed to your agent using '-a'.  For example, to load a SearchAgent that uses
depth first search (dfs), run the following command:

> python pacman.py -p SearchAgent -a fn=depthFirstSearch

Commands to invoke other search strategies can be found in the project
description.

Please only change the parts of the file you are asked to.  Look for the lines
that say

"*** YOUR CODE HERE ***"

The parts you fill in start about 3/4 of the way down.  Follow the project
description for details.

Good luck and happy searching!
"""
from game import Directions
from game import Agent
from game import Actions
import util
import time
import search


class GoWestAgent(Agent):
    """An agent that goes West until it can't."""

    def getAction(self, state):
        """The agent receives a GameState (defined in pacman.py)."""
        if Directions.WEST in state.getLegalPacmanActions():
            return Directions.WEST
        else:
            return Directions.STOP


class SearchAgent(Agent):
    """
    This very general search agent finds a path using a supplied search
    algorithm for a supplied search problem, then returns actions to follow that
    path.

    As a default, this agent runs DFS on a PositionSearchProblem to find
    location (1,1)

    Options for fn include:
      depthFirstSearch or dfs
      breadthFirstSearch or bfs


    Note: You should NOT change any code in SearchAgent
    """

    def __init__(self, fn='depthFirstSearch', prob='PositionSearchProblem',
        heuristic='nullHeuristic'):
        """
""\"
Initialize a SearchAgent with a specified search function, problem type, and heuristic.

Parameters:
    fn (str): A string representing the search function to be used. Options include
              'depthFirstSearch' or 'breadthFirstSearch'.
    prob (str): A string denoting the search problem type. Must end with 'Problem'.
    heuristic (str): A string representing the heuristic function name. Default is 'nullHeuristic'.

Returns:
    None

Usage Example:
    agent = SearchAgent(fn='breadthFirstSearch', prob='PositionSearchProblem', heuristic='manhattanHeuristic')
    
    This creates a SearchAgent that uses breadth-first search on a PositionSearchProblem
    with the specified Manhattan distance heuristic.
"""
        if fn not in dir(search):
            raise AttributeError(fn + ' is not a search function in search.py.'
                )
        func = getattr(search, fn)
        if 'heuristic' not in func.__code__.co_varnames:
            print('[SearchAgent] using function ' + fn)
            self.searchFunction = func
        else:
            if heuristic in globals().keys():
                heur = globals()[heuristic]
            elif heuristic in dir(search):
                heur = getattr(search, heuristic)
            else:
                raise AttributeError(heuristic +
                    ' is not a function in searchAgents.py or search.py.')
            print('[SearchAgent] using function %s and heuristic %s' % (fn,
                heuristic))
            self.searchFunction = lambda x: func(x, heuristic=heur)
        if prob not in globals().keys() or not prob.endswith('Problem'):
            raise AttributeError(prob +
                ' is not a search problem type in SearchAgents.py.')
        self.searchType = globals()[prob]
        print('[SearchAgent] using problem type ' + prob)

    def registerInitialState(self, state):
        """
        This is the first time that the agent sees the layout of the game
        board. Here, we choose a path to the goal. In this phase, the agent
        should compute the path to the goal and store it in a local variable.
        All of the work is done in this method!

        state: a GameState object (pacman.py)
        """
        if self.searchFunction == None:
            raise Exception('No search function provided for SearchAgent')
        starttime = time.time()
        problem = self.searchType(state)
        self.actions = self.searchFunction(problem)
        totalCost = problem.getCostOfActions(self.actions)
        print('Path found with total cost of %d in %.1f seconds' % (
            totalCost, time.time() - starttime))
        if '_expanded' in dir(problem):
            print('Search nodes expanded: %d' % problem._expanded)

    def getAction(self, state):
        """
        Returns the next action in the path chosen earlier (in
        registerInitialState).  Return Directions.STOP if there is no further
        action to take.

        state: a GameState object (pacman.py)
        """
        if 'actionIndex' not in dir(self):
            self.actionIndex = 0
        i = self.actionIndex
        self.actionIndex += 1
        if i < len(self.actions):
            return self.actions[i]
        else:
            return Directions.STOP


class PositionSearchProblem(search.SearchProblem):
    """
    A search problem defines the state space, start state, goal test, successor
    function and cost function.  This search problem can be used to find paths
    to a particular point on the pacman board.

    The state space consists of (x,y) positions in a pacman game.

    Note: this search problem is fully specified; you should NOT change it.
    """

    def __init__(self, gameState, costFn=lambda x: 1, goal=(1, 1), start=
        None, warn=True, visualize=True):
        """
        Stores the start and goal.

        gameState: A GameState object (pacman.py)
        costFn: A function from a search state (tuple) to a non-negative number
        goal: A position in the gameState
        """
        self.walls = gameState.getWalls()
        self.startState = gameState.getPacmanPosition()
        if start != None:
            self.startState = start
        self.goal = goal
        self.costFn = costFn
        self.visualize = visualize
        if warn and (gameState.getNumFood() != 1 or not gameState.hasFood(*
            goal)):
            print('Warning: this does not look like a regular search maze')
        self._visited, self._visitedlist, self._expanded = {}, [], 0

    def getStartState(self):
        """
""\"
Returns the start state for the search problem, which includes the starting position of Pacman
and the status of the corners.

Parameters:
    None

Returns:
    tuple: A tuple containing two elements:
        - (tuple): The starting position of Pacman as (x, y).
        - (list): A list indicating the visit status of each corner 
                  ("visited" or "unvisited").

Usage Example:
    problem = CornersProblem(startingGameState)
    start_state = problem.getStartState()
    
    This will retrieve the initial state of the search problem, 
    which includes Pacman's starting position and the status 
    of each corner in the game.
"""
        return self.startState

    def isGoalState(self, state):
        """
""\"
Determines whether the given state is a goal state for the search problem.

Parameters:
    state (tuple): The current search state, which includes the position of Pacman
                   and the status of corners as a list.

Returns:
    bool: True if the state is a goal state (i.e., all corners have been visited),
          False otherwise.

Usage Example:
    problem = CornersProblem(startingGameState)
    state = ((1, 1), ["visited", "visited", "visited", "visited"])
    is_goal = problem.isGoalState(state)
    
    This will return True, indicating that the specified state is a goal state 
    since all corners have been marked as visited.
"""
        isGoal = state == self.goal
        if isGoal and self.visualize:
            self._visitedlist.append(state)
            import __main__
            if '_display' in dir(__main__):
                if 'drawExpandedCells' in dir(__main__._display):
                    __main__._display.drawExpandedCells(self._visitedlist)
        return isGoal

    def getSuccessors(self, state):
        """
        Returns successor states, the actions they require, and a cost of 1.

         As noted in search.py:
             For a given state, this should return a list of triples,
         (successor, action, stepCost), where 'successor' is a
         successor to the current state, 'action' is the action
         required to get there, and 'stepCost' is the incremental
         cost of expanding to that successor
        """
        successors = []
        for action in [Directions.NORTH, Directions.SOUTH, Directions.EAST,
            Directions.WEST]:
            x, y = state
            dx, dy = Actions.directionToVector(action)
            nextx, nexty = int(x + dx), int(y + dy)
            if not self.walls[nextx][nexty]:
                nextState = nextx, nexty
                cost = self.costFn(nextState)
                successors.append((nextState, action, cost))
        self._expanded += 1
        if state not in self._visited:
            self._visited[state] = True
            self._visitedlist.append(state)
        return successors

    def getCostOfActions(self, actions):
        """
        Returns the cost of a particular sequence of actions. If those actions
        include an illegal move, return 999999.
        """
        if actions == None:
            return 999999
        x, y = self.getStartState()
        cost = 0
        for action in actions:
            dx, dy = Actions.directionToVector(action)
            x, y = int(x + dx), int(y + dy)
            if self.walls[x][y]:
                return 999999
            cost += self.costFn((x, y))
        return cost


class StayEastSearchAgent(SearchAgent):
    """
    An agent for position search with a cost function that penalizes being in
    positions on the West side of the board.

    The cost function for stepping into a position (x,y) is 1/2^x.
    """

    def __init__(self):
        """
""\"
Initialize a StayWestSearchAgent, which uses a cost function to penalize moving to eastern positions.

Parameters:
    None

Returns:
    None

Usage Example:
    agent = StayWestSearchAgent()
    
    This creates an instance of StayWestSearchAgent which is configured 
    to minimize movement towards the eastern side of the game grid 
    by using a specific cost function in its search algorithm.
"""
        self.searchFunction = search.uniformCostSearch

        def costFn(pos):
            """
""\"
Calculates the cost of moving to a given position in the search problem, based on the x-coordinate of the position.

Parameters:
    pos (tuple): A tuple representing the coordinates of the position (x, y).

Returns:
    float: The cost of stepping into the given position, calculated as:
           - 1/2^x for the StayEastSearchAgent
           - 2^x for the StayWestSearchAgent

Usage Example:
    cost_fn = lambda pos: .5 ** pos[0]
    cost = cost_fn((2, 3))
    
    This will return 0.25, representing the cost of stepping into the position (2, 3)
    when using the cost function defined for the StayEastSearchAgent.
"""
            return 0.5 ** pos[0]
        self.searchType = lambda state: PositionSearchProblem(state, costFn,
            (1, 1), None, False)


class StayWestSearchAgent(SearchAgent):
    """
    An agent for position search with a cost function that penalizes being in
    positions on the East side of the board.

    The cost function for stepping into a position (x,y) is 2^x.
    """

    def __init__(self):
        """
""\"
Initialize a CornersProblem instance, which requires the agent to navigate to all four corners of a grid layout.

Parameters:
    startingGameState (GameState): The initial game state that includes the walls, 
                                    Pacman's starting position, and the layout of the grid.

Returns:
    None

Usage Example:
    problem = CornersProblem(startingGameState)
    
    This initializes a CornersProblem using the provided game state, setting
    up the necessary attributes like walls, starting position, and corner locations
    for subsequent search operations.
"""
        self.searchFunction = search.uniformCostSearch

        def costFn(pos):
            """
""\"
Calculates the cost associated with stepping into a given position in the search problem, with a penalty based on the x-coordinate.

Parameters:
    pos (tuple): A tuple representing the coordinates of the position (x, y).

Returns:
    float: The cost of moving to the specified position, defined as:
           - 1/2^x for the StayEastSearchAgent, which reduces cost as x increases.
           - 2^x for the StayWestSearchAgent, which increases cost as x increases.

Usage Example:
    cost_fn = lambda pos: 2 ** pos[0]  # Cost function for StayWestSearchAgent
    cost = cost_fn((3, 2))
    
    This will return 8.0, which represents the cost of stepping into the position (3, 2)
    when using the cost function defined for the StayWestSearchAgent.
"""
            return 2 ** pos[0]
        self.searchType = lambda state: PositionSearchProblem(state, costFn)


def manhattanHeuristic(position, problem, info={}):
    """The Manhattan distance heuristic for a PositionSearchProblem"""
    xy1 = position
    xy2 = problem.goal
    return abs(xy1[0] - xy2[0]) + abs(xy1[1] - xy2[1])


def euclideanHeuristic(position, problem, info={}):
    """The Euclidean distance heuristic for a PositionSearchProblem"""
    xy1 = position
    xy2 = problem.goal
    return ((xy1[0] - xy2[0]) ** 2 + (xy1[1] - xy2[1]) ** 2) ** 0.5


class CornersProblem(search.SearchProblem):
    """
    This search problem finds paths through all four corners of a layout.

    You must select a suitable state space and successor function
    """

    def __init__(self, startingGameState):
        """
        Stores the walls, pacman's starting position and corners.
        """
        self.walls = startingGameState.getWalls()
        self.startingPosition = startingGameState.getPacmanPosition()
        top, right = self.walls.height - 2, self.walls.width - 2
        self.corners = (1, 1), (1, top), (right, 1), (right, top)
        for corner in self.corners:
            if not startingGameState.hasFood(*corner):
                print('Warning: no food in corner ' + str(corner))
        self._expanded = 0
        """*** YOUR CODE HERE ***"""
        self.startPoint = self.startingPosition
        self.cornersStatus = ['unvisited', 'unvisited', 'unvisited',
            'unvisited']

    def getStartState(self):
        """
        Returns the start state (in your state space, not the full Pacman state
        space)
        """
        """*** YOUR CODE HERE ***"""
        return self.startPoint, self.cornersStatus
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
        Returns whether this search state is a goal state of the problem.
        """
        """*** YOUR CODE HERE ***"""
        cornersStatus = [item for item in state[1]]
        if cornersStatus[0] == 'unvisited' or cornersStatus[1
            ] == 'unvisited' or cornersStatus[2
            ] == 'unvisited' or cornersStatus[3] == 'unvisited':
            return False
        return True
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
        Returns successor states, the actions they require, and a cost of 1.

         As noted in search.py:
            For a given state, this should return a list of triples, (successor,
            action, stepCost), where 'successor' is a successor to the current
            state, 'action' is the action required to get there, and 'stepCost'
            is the incremental cost of expanding to that successor
        """
        successors = []
        for action in [Directions.NORTH, Directions.SOUTH, Directions.EAST,
            Directions.WEST]:
            """*** YOUR CODE HERE ***"""
            x, y = state[0][:]
            dx, dy = Actions.directionToVector(action)
            cornersStatus = state[1][:]
            nextx, nexty = int(x + dx), int(y + dy)
            if not self.walls[nextx][nexty]:
                nextPosition = nextx, nexty
                if nextPosition in self.corners:
                    cornersStatus[self.corners.index(nextPosition)] = 'visited'
                cost = 1
                nextState = nextPosition, cornersStatus
                successors.append((nextState, action, cost))
        self._expanded += 1
        return successors

    def getCostOfActions(self, actions):
        """
        Returns the cost of a particular sequence of actions.  If those actions
        include an illegal move, return 999999.  This is implemented for you.
        """
        if actions == None:
            return 999999
        x, y = self.startingPosition
        for action in actions:
            dx, dy = Actions.directionToVector(action)
            x, y = int(x + dx), int(y + dy)
            if self.walls[x][y]:
                return 999999
        return len(actions)


def cornersHeuristic(state, problem):
    """
    A heuristic for the CornersProblem that you defined.

      state:   The current search state
               (a data structure you chose in your search problem)

      problem: The CornersProblem instance for this layout.

    This function should always return a number that is a lower bound on the
    shortest path from the state to a goal of the problem; i.e.  it should be
    admissible (as well as consistent).
    """
    corners = problem.corners
    walls = problem.walls
    """*** YOUR CODE HERE ***"""
    from util import manhattanDistance
    current_position = state[0]
    cornersStatus = state[1]
    heuristic = 0
    if problem.isGoalState(state):
        return heuristic
    distancesFromGoals = []
    for index, item in enumerate(cornersStatus):
        if item == 'unvisited':
            distancesFromGoals.append(manhattanDistance(current_position,
                corners[index]))
    heuristic = max(distancesFromGoals)
    return heuristic
    return 0


class AStarCornersAgent(SearchAgent):
    """A SearchAgent for FoodSearchProblem using A* and your foodHeuristic"""

    def __init__(self):
        """
""\"
Initialize a FoodSearchProblem instance, which allows the agent to find a path to collect all food items in the grid.

Parameters:
    startingGameState (GameState): The initial game state that includes information about
                                    walls, Pacman's starting position, and the locations of food.

Returns:
    None

Usage Example:
    problem = FoodSearchProblem(startingGameState)
    
    This creates an instance of FoodSearchProblem using the provided game state, setting up
    the necessary attributes to define the starting position and the layout of food items
    for the agent to navigate and collect.
"""
        self.searchFunction = lambda prob: search.aStarSearch(prob,
            cornersHeuristic)
        self.searchType = CornersProblem


class FoodSearchProblem:
    """
    A search problem associated with finding the a path that collects all of the
    food (dots) in a Pacman game.

    A search state in this problem is a tuple ( pacmanPosition, foodGrid ) where
      pacmanPosition: a tuple (x,y) of integers specifying Pacman's position
      foodGrid:       a Grid (see game.py) of either True or False, specifying remaining food
    """

    def __init__(self, startingGameState):
        """
""\"
Initialize an AStarFoodSearchAgent, which uses the A* search algorithm to find a path to collect all food items.

Parameters:
    None

Returns:
    None

Usage Example:
    agent = AStarFoodSearchAgent()
    
    This creates an instance of AStarFoodSearchAgent, enabling it to use the A* algorithm
    for solving the FoodSearchProblem, utilizing a specified heuristic to optimize the search.
"""
        self.start = startingGameState.getPacmanPosition(
            ), startingGameState.getFood()
        self.walls = startingGameState.getWalls()
        self.startingGameState = startingGameState
        self._expanded = 0
        self.heuristicInfo = {}

    def getStartState(self):
        """
""\"
Returns the starting state for the FoodSearchProblem, which includes Pacman's initial position and the food grid.

Parameters:
    None

Returns:
    tuple: A tuple containing:
        - (tuple): The starting position of Pacman as (x, y).
        - (Grid): A grid representing the remaining food, where True indicates food present and False indicates no food.

Usage Example:
    problem = FoodSearchProblem(startingGameState)
    start_state = problem.getStartState()

    This will retrieve the initial state of the search problem, which includes Pacman's
    starting coordinates and the current status of food on the grid.
"""
        return self.start

    def isGoalState(self, state):
        """
""\"
Determines whether the given state is a goal state for the FoodSearchProblem, which is defined as the condition when all food items have been collected.

Parameters:
    state (tuple): The current search state, represented as a tuple consisting of:
        - (tuple): Pacman's current position (x, y).
        - (Grid): The current food grid, where each cell indicates the presence (True) or absence (False) of food.

Returns:
    bool: True if the state represents a goal state (all food collected), False otherwise.

Usage Example:
    problem = FoodSearchProblem(startingGameState)
    current_state = ((2, 3), foodGrid)  # Example state
    is_goal = problem.isGoalState(current_state)

    This will return True if all food items in the foodGrid have been collected,
    indicating that the current state is indeed a goal state.
"""
        return state[1].count() == 0

    def getSuccessors(self, state):
        """Returns successor states, the actions they require, and a cost of 1."""
        successors = []
        self._expanded += 1
        for direction in [Directions.NORTH, Directions.SOUTH, Directions.
            EAST, Directions.WEST]:
            x, y = state[0]
            dx, dy = Actions.directionToVector(direction)
            nextx, nexty = int(x + dx), int(y + dy)
            if not self.walls[nextx][nexty]:
                nextFood = state[1].copy()
                nextFood[nextx][nexty] = False
                successors.append((((nextx, nexty), nextFood), direction, 1))
        return successors

    def getCostOfActions(self, actions):
        """Returns the cost of a particular sequence of actions.  If those actions
        include an illegal move, return 999999"""
        x, y = self.getStartState()[0]
        cost = 0
        for action in actions:
            dx, dy = Actions.directionToVector(action)
            x, y = int(x + dx), int(y + dy)
            if self.walls[x][y]:
                return 999999
            cost += 1
        return cost


class AStarFoodSearchAgent(SearchAgent):
    """A SearchAgent for FoodSearchProblem using A* and your foodHeuristic"""

    def __init__(self):
        """
""\"
Initialize a SearchAgent with a specified search function, problem type, and heuristic.

Parameters:
    fn (str): A string representing the search function to be used (e.g., 'depthFirstSearch', 'breadthFirstSearch').
    prob (str): A string denoting the type of search problem to solve (must end with 'Problem').
    heuristic (str): A string representing the heuristic function name (default is 'nullHeuristic').

Returns:
    None

Usage Example:
    agent = SearchAgent(fn='depthFirstSearch', prob='PositionSearchProblem', heuristic='manhattanHeuristic')
    
    This creates an instance of SearchAgent that employs depth-first search on a PositionSearchProblem
    using the Manhattan distance as the heuristic for the search.
"""
        self.searchFunction = lambda prob: search.aStarSearch(prob,
            foodHeuristic)
        self.searchType = FoodSearchProblem


def foodHeuristic(state, problem):
    """
    Your heuristic for the FoodSearchProblem goes here.

    This heuristic must be consistent to ensure correctness.  First, try to come
    up with an admissible heuristic; almost all admissible heuristics will be
    consistent as well.

    If using A* ever finds a solution that is worse uniform cost search finds,
    your heuristic is *not* consistent, and probably not admissible!  On the
    other hand, inadmissible or inconsistent heuristics may find optimal
    solutions, so be careful.

    The state is a tuple ( pacmanPosition, foodGrid ) where foodGrid is a Grid
    (see game.py) of either True or False. You can call foodGrid.asList() to get
    a list of food coordinates instead.

    If you want access to info like walls, capsules, etc., you can query the
    problem.  For example, problem.walls gives you a Grid of where the walls
    are.

    If you want to *store* information to be reused in other calls to the
    heuristic, there is a dictionary called problem.heuristicInfo that you can
    use. For example, if you only want to count the walls once and store that
    value, try: problem.heuristicInfo['wallCount'] = problem.walls.count()
    Subsequent calls to this heuristic can access
    problem.heuristicInfo['wallCount']
    """
    position, foodGrid = state
    """*** YOUR CODE HERE ***"""
    start_position = problem.startingGameState
    food_list = foodGrid.asList()
    heuristic = 0
    if len(food_list) == 0:
        return 0
    for item in food_list:
        foodDistance = mazeDistance(position, item, start_position)
        if foodDistance > heuristic:
            heuristic = foodDistance
    return heuristic
    return 0


class ClosestDotSearchAgent(SearchAgent):
    """Search for all food using a sequence of searches"""

    def registerInitialState(self, state):
        """
""\"
Register the initial state of the search problem, compute the path to the goal, and store it for later use.

Parameters:
    state (GameState): The initial game state provided to the agent, which contains information about the layout of the game, including Pacman's position.

Returns:
    None

Usage Example:
    agent = SearchAgent(fn='breadthFirstSearch', prob='PositionSearchProblem')
    agent.registerInitialState(initialGameState)

    This will compute the path from Pacman's starting position to the specified goal in the initial game state,
    storing the resultant actions for the agent to execute in subsequent moves.
"""
        self.actions = []
        currentState = state
        while currentState.getFood().count() > 0:
            nextPathSegment = self.findPathToClosestDot(currentState)
            self.actions += nextPathSegment
            for action in nextPathSegment:
                legal = currentState.getLegalActions()
                if action not in legal:
                    t = str(action), str(currentState)
                    raise Exception(
                        'findPathToClosestDot returned an illegal move: %s!\n%s'
                         % t)
                currentState = currentState.generateSuccessor(0, action)
        self.actionIndex = 0
        print('Path found with cost %d.' % len(self.actions))

    def findPathToClosestDot(self, gameState):
        """
        Returns a path (a list of actions) to the closest dot, starting from
        gameState.
        """
        startPosition = gameState.getPacmanPosition()
        food = gameState.getFood()
        walls = gameState.getWalls()
        problem = AnyFoodSearchProblem(gameState)
        """*** YOUR CODE HERE ***"""
        return search.breadthFirstSearch(problem)
        util.raiseNotDefined()


class AnyFoodSearchProblem(PositionSearchProblem):
    """
    A search problem for finding a path to any food.

    This search problem is just like the PositionSearchProblem, but has a
    different goal test, which you need to fill in below.  The state space and
    successor function do not need to be changed.

    The class definition above, AnyFoodSearchProblem(PositionSearchProblem),
    inherits the methods of the PositionSearchProblem.

    You can use this search problem to help you fill in the findPathToClosestDot
    method.
    """

    def __init__(self, gameState):
        """Stores information from the gameState.  You don't need to change this."""
        self.food = gameState.getFood()
        self.walls = gameState.getWalls()
        self.startState = gameState.getPacmanPosition()
        self.costFn = lambda x: 1
        self._visited, self._visitedlist, self._expanded = {}, [], 0

    def isGoalState(self, state):
        """
        The state is Pacman's position. Fill this in with a goal test that will
        complete the problem definition.
        """
        x, y = state
        """*** YOUR CODE HERE ***"""
        food_list = self.food.asList()
        flag = True if (x, y) in food_list else False
        return flag
        util.raiseNotDefined()


def mazeDistance(point1, point2, gameState):
    """
    Returns the maze distance between any two points, using the search functions
    you have already built. The gameState can be any game state -- Pacman's
    position in that state is ignored.

    Example usage: mazeDistance( (2,4), (5,6), gameState)

    This might be a useful helper function for your ApproximateSearchAgent.
    """
    x1, y1 = point1
    x2, y2 = point2
    walls = gameState.getWalls()
    assert not walls[x1][y1], 'point1 is a wall: ' + str(point1)
    assert not walls[x2][y2], 'point2 is a wall: ' + str(point2)
    prob = PositionSearchProblem(gameState, start=point1, goal=point2, warn
        =False, visualize=False)
    return len(search.bfs(prob))
