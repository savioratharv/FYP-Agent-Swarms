# File Name: testParser.py
# 
# Description:
# This module implements a class `TestParser` which is responsible for parsing test case files. It removes comments and extracts key-value pairs in the specified format from the test files.
# 
# Class: TestParser
# 
# Attributes:
# - path (str): The path to the test file being parsed.
# 
# Methods:
# - __init__(self, path): Initializes the `TestParser` instance with the test file path.
# 
# - removeComments(self, rawlines): 
#   - Purpose: This method processes the raw lines of the test file to remove any comments that start with the '#' symbol.
#   - Parameters: 
#     - rawlines (list of str): The lines raw from the test file.
#   - Returns: 
#     - str: The processed lines joined into a single string without comments.
# 
# - parse(self): 
#   - Purpose: Reads the test case from the specified file path, processes it to remove comments, and organizes the data into a dictionary format.
#   - Returns: 
#     - dict: A dictionary containing the parsed test case data. The keys represent property names from the test file, and the values contain associated data. Also includes a raw representation of the lines and emit types for output formatting.
# 
# Function: emitTestDict(testDict, handle)
# 
# - Purpose: This function is responsible for emitting the test dictionary content to the specified output handle.
# - Parameters:
#   - testDict (dict): A dictionary containing the parsed test data including the emit types.
#   - handle (file object): The output handle where the test data will be written.
# - Behavior: Iterates over the emission list within the test dictionary and writes each entry to the output handle according to its type (raw, oneline, or multiline). Raises an exception if an unexpected emit type is encountered.
# 
# Usage:
# The `TestParser` class can be used to facilitate the reading and interpretation of test files structured with specific format requirements. By utilizing the `parse` method, users can extract properties and comments for further analysis or testing. The `emitTestDict` function can be employed to write the organized data back to a file or another output medium. 
# 
# Error Handling:
# The `parse` method provides basic error handling by printing an error message and terminating the program if the file content does not match the expected format.
# 
# Licensing Information:
# This module is free to use and extend for educational purposes, with the stipulation that solutions are not distributed or published. Users must retain the licensing notice and provide appropriate attribution to UC Berkeley and associated contributors.

import re
import sys


class TestParser(object):

    def __init__(self, path):
        """
Initializes a TestParser instance with the given test file path.

Parameters:
    path (str): The file path to the test case file that will be parsed.

Returns:
    None

Usage Example:
    parser = TestParser('path/to/test_file.txt')
"""
        self.path = path

    def removeComments(self, rawlines):
        """
Removes comments from the given lines of text.

This method processes each line and removes any content following a '#' symbol, effectively
stripping out comments while preserving the rest of the line.

Parameters:
    rawlines (list of str): The raw lines from the test file, which may contain comments.

Returns:
    str: A single string containing the lines without comments, joined by newline characters.

Usage Example:
    raw_lines = ['param1: "value1"  # this is a comment', 'param2: "value2"\\n']
    cleaned_text = removeComments(raw_lines)
    # cleaned_text will be 'param1: "value1"\\nparam2: "value2"\\n'
"""
        fixed_lines = []
        for l in rawlines:
            idx = l.find('#')
            if idx == -1:
                fixed_lines.append(l)
            else:
                fixed_lines.append(l[0:idx])
        return '\n'.join(fixed_lines)

    def parse(self):
        """
Parses the test case file specified by the instance's path.

This method reads the test case file, removes comments, and extracts key-value pairs
following a specific format. It organizes the extracted data into a dictionary that can
be easily accessed and used.

Parameters:
    None

Returns:
    dict: A dictionary containing the parsed test case data, including:
          - The keys represent property names from the test file,
          - The values are associated data,
          - Additionally includes a raw representation of the lines and emit types for output formatting.

Usage Example:
    parser = TestParser('path/to/test_file.txt')
    test_data = parser.parse()
    # test_data will be a dictionary containing the extracted information from the test file.
"""
        test = {}
        with open(self.path) as handle:
            raw_lines = handle.read().split('\n')
        test_text = self.removeComments(raw_lines)
        test['__raw_lines__'] = raw_lines
        test['path'] = self.path
        test['__emit__'] = []
        lines = test_text.split('\n')
        i = 0
        while i < len(lines):
            if re.match('\\A\\s*\\Z', lines[i]):
                test['__emit__'].append(('raw', raw_lines[i]))
                i += 1
                continue
            m = re.match('\\A([^"]*?):\\s*"([^"]*)"\\s*\\Z', lines[i])
            if m:
                test[m.group(1)] = m.group(2)
                test['__emit__'].append(('oneline', m.group(1)))
                i += 1
                continue
            m = re.match('\\A([^"]*?):\\s*"""\\s*\\Z', lines[i])
            if m:
                msg = []
                i += 1
                while not re.match('\\A\\s*"""\\s*\\Z', lines[i]):
                    msg.append(raw_lines[i])
                    i += 1
                test[m.group(1)] = '\n'.join(msg)
                test['__emit__'].append(('multiline', m.group(1)))
                i += 1
                continue
            print('error parsing test file: %s' % self.path)
            sys.exit(1)
        return test


def emitTestDict(testDict, handle):
    """
Emits the contents of a test dictionary to a specified output handle.

This function formats and writes the entries in the provided test dictionary to the given 
output handle according to their respective types (raw, oneline, or multiline). It is used 
to save or display the structured test data.

Parameters:
    testDict (dict): A dictionary containing the parsed test data, including emit types 
                     for the formatting.
    handle (file object): The output handle where the test data will be written. This 
                          could be a file object or any object supporting the write() method.

Returns:
    None

Usage Example:
    test_data = {
        '__emit__': [('oneline', 'param1'), ('multiline', 'param2')],
        'param1': 'value1',
        'param2': 'value2\\nanother line'
    }
    with open('output.txt', 'w') as out_file:
        emitTestDict(test_data, out_file)
    # The content of output.txt will contain the formatted test data.
"""
    for kind, data in testDict['__emit__']:
        if kind == 'raw':
            handle.write(data + '\n')
        elif kind == 'oneline':
            handle.write('%s: "%s"\n' % (data, testDict[data]))
        elif kind == 'multiline':
            handle.write('%s: """\n%s\n"""\n' % (data, testDict[data]))
        else:
            raise Exception('Bad __emit__')
