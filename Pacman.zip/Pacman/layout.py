# """
# layout.py
# ----------
# This module provides the Layout class which manages the static information about
# the game board for a Pacman-like game. The Layout class is responsible for the 
# initialization and management of various elements present in the game, such as 
# walls, food, capsules, agent positions (Pacman and ghosts), and visibility 
# between entities.
# 
# Classes:
# --------
# Layout
#     A class that manages the game board, including walls, food, capsules, and 
#     agent positions. It processes layout text to initialize the game environment 
#     and provides methods for interacting with the game state.
# 
# Functions:
# ----------
# getLayout(name, back=2)
#     Retrieves a layout from file based on the given name. It attempts to locate 
#     the layout file in different default directories. 
#     
#     Parameters:
#     name : str
#         The name of the layout file, either with or without a .lay extension.
#     back : int, optional
#         The number of directory levels to search (default is 2).
# 
#     Returns:
#     Layout or None
#         A Layout object if the file is found successfully; otherwise, None.
# 
# tryToLoad(fullname)
#     Attempts to load a layout from a specified file. 
# 
#     Parameters:
#     fullname : str
#         The full path of the layout file.
# 
#     Returns:
#     Layout or None
#         A Layout object if the file exists and is loaded successfully; otherwise, None.
#     
# Overview of Methods within Layout Class:
# ------------------------------------------
# __init__(layoutText)
#     Initializes a Layout object with the provided layout text. It sets up 
#     the game board dimensions, walls, food locations, capsules, agent positions, 
#     and counts the number of ghosts.
# 
# getNumGhosts()
#     Returns the number of ghosts present in the layout.
# 
# initializeVisibilityMatrix()
#     Initializes a visibility matrix that tracks which positions on the board 
#     are visible from each agent's position and direction.
# 
# isWall(pos)
#     Checks if a given position is a wall on the game board.
# 
# getRandomLegalPosition()
#     Returns a random position on the game board that is not a wall.
# 
# getRandomCorner()
#     Returns a random corner position on the game board.
# 
# getFurthestCorner(pacPos)
#     Calculates and returns the corner that is furthest away from the provided 
#     Pacman's position using Manhattan distance.
# 
# isVisibleFrom(ghostPos, pacPos, pacDirection)
#     Determines if a given ghost position is visible from the Pacman's position 
#     and direction.
# 
# __str__()
#     Returns a string representation of the layout, suitable for display or debugging.
# 
# deepCopy()
#     Creates and returns a deep copy of the current Layout object.
# 
# processLayoutText(layoutText)
#     Processes the layout text to properly initialize walls, food, capsules, 
#     and agent positions. The coordinate system is adjusted during this process.
# 
# processLayoutChar(x, y, layoutChar)
#     Processes a single character from the layout text and updates the game board 
#     structures accordingly.
# 
# This module is intended for educational purposes only and is part of a larger 
# Pacman AI project developed at UC Berkeley. Users are encouraged to use and 
# extend the provided functionality while adhering to the specified licensing 
# requirements.
# """

from util import manhattanDistance
from game import Grid
import os
import random
from functools import reduce
VISIBILITY_MATRIX_CACHE = {}


class Layout:
    """
    A Layout manages the static information about the game board.
    """

    def __init__(self, layoutText):
        """
Initialize a Layout object with the provided layout text.

This constructor sets up the game board's dimensions, initializes various 
attributes such as walls, food locations, capsules, and agent positions. 
It also counts the number of ghosts present in the layout.

Parameters:
-----------
layoutText : list of str
    A list of strings representing the layout of the game board. Each 
    character in the strings corresponds to different elements:
    - '%' represents a wall
    - '.' represents food
    - 'o' represents a capsule
    - 'G' represents a ghost
    - 'P' represents Pacman
    Other characters are ignored.

Returns:
--------
None
    This function does not return a value.

Usage Example:
--------------
layout_text = [
    "%%%%%%%%%%",
    "%..o.....%",
    "%.G.%....%",
    "%........%",
    "%%%%%%%%%%"
]
layout = Layout(layout_text)
"""
        self.width = len(layoutText[0])
        self.height = len(layoutText)
        self.walls = Grid(self.width, self.height, False)
        self.food = Grid(self.width, self.height, False)
        self.capsules = []
        self.agentPositions = []
        self.numGhosts = 0
        self.processLayoutText(layoutText)
        self.layoutText = layoutText
        self.totalFood = len(self.food.asList())

    def getNumGhosts(self):
        """
Return the number of ghosts present in the layout.

This method provides the current count of ghost entities in the game 
layout, which is initialized during the loading of the layout text.

Parameters:
-----------
None

Returns:
--------
int
    The number of ghosts in the layout.

Usage Example:
--------------
layout_text = [
    "%%%%%%%%%%",
    "%..o.....%",
    "%.G.%....%",
    "%G......%",
    "%%%%%%%%%%"
]
layout = Layout(layout_text)
num_ghosts = layout.getNumGhosts()  # Output: 2
"""
        return self.numGhosts

    def initializeVisibilityMatrix(self):
        """
Initialize the visibility matrix for the game board.

This method constructs a visibility matrix that tracks the positions on 
the game board that can be seen from each agent's position in relation 
to their current direction. The visibility matrix is stored in a global 
cache to optimize performance for repeated layout retrievals.

Parameters:
-----------
None

Returns:
--------
None
    This function does not return a value.

Usage Example:
--------------
layout_text = [
    "%%%%%%%%%%",
    "%..o.....%",
    "%.G.%....%",
    "%........%",
    "%%%%%%%%%%"
]
layout = Layout(layout_text)
layout.initializeVisibilityMatrix()  # Constructs the visibility matrix for the layout
"""
        global VISIBILITY_MATRIX_CACHE
        if reduce(str.__add__, self.layoutText) not in VISIBILITY_MATRIX_CACHE:
            from game import Directions
            vecs = [(-0.5, 0), (0.5, 0), (0, -0.5), (0, 0.5)]
            dirs = [Directions.NORTH, Directions.SOUTH, Directions.WEST,
                Directions.EAST]
            vis = Grid(self.width, self.height, {Directions.NORTH: set(),
                Directions.SOUTH: set(), Directions.EAST: set(), Directions
                .WEST: set(), Directions.STOP: set()})
            for x in range(self.width):
                for y in range(self.height):
                    if self.walls[x][y] == False:
                        for vec, direction in zip(vecs, dirs):
                            dx, dy = vec
                            nextx, nexty = x + dx, y + dy
                            while nextx + nexty != int(nextx) + int(nexty
                                ) or not self.walls[int(nextx)][int(nexty)]:
                                vis[x][y][direction].add((nextx, nexty))
                                nextx, nexty = x + dx, y + dy
            self.visibility = vis
            VISIBILITY_MATRIX_CACHE[reduce(str.__add__, self.layoutText)] = vis
        else:
            self.visibility = VISIBILITY_MATRIX_CACHE[reduce(str.__add__,
                self.layoutText)]

    def isWall(self, pos):
        """
Check if a given position is a wall on the game board.

This method determines whether the specified position (coordinates) 
corresponds to a wall in the layout. It checks the wall structure 
of the game board to return the appropriate boolean value.

Parameters:
-----------
pos : tuple of (int, int)
    A tuple representing the (x, y) coordinates of the position 
    to be checked for wall presence.

Returns:
--------
bool
    True if the position is a wall; otherwise, False.

Usage Example:
--------------
layout_text = [
    "%%%%%%%%%%",
    "%..o.....%",
    "%.G.%....%",
    "%........%",
    "%%%%%%%%%%"
]
layout = Layout(layout_text)
is_wall = layout.isWall((0, 0))  # Output: True
is_wall = layout.isWall((1, 1))  # Output: False
"""
        x, col = pos
        return self.walls[x][col]

    def getRandomLegalPosition(self):
        """
Return a random legal position on the game board.

This method generates a random position within the dimensions of the 
game board that is not a wall. It ensures that the returned position 
is valid for gameplay, allowing agents to occupy the space.

Parameters:
-----------
None

Returns:
--------
tuple of (int, int)
    A tuple representing the (x, y) coordinates of a random legal 
    position on the game board.

Usage Example:
--------------
layout_text = [
    "%%%%%%%%%%",
    "%..o.....%",
    "%.G.%....%",
    "%........%",
    "%%%%%%%%%%"
]
layout = Layout(layout_text)
random_position = layout.getRandomLegalPosition()  # E.g., Output: (1, 1) or (2, 1)
"""
        x = random.choice(range(self.width))
        y = random.choice(range(self.height))
        while self.isWall((x, y)):
            x = random.choice(range(self.width))
            y = random.choice(range(self.height))
        return x, y

    def getRandomCorner(self):
        """
Return a random corner position on the game board.

This method selects and returns one of the predefined corner positions 
on the game board. The corners are defined as specific coordinates 
that typically exist in the layout of the game.

Parameters:
-----------
None

Returns:
--------
tuple of (int, int)
    A tuple representing the (x, y) coordinates of a randomly chosen 
    corner position on the game board.

Usage Example:
--------------
layout_text = [
    "%%%%%%%%%%",
    "%........%",
    "%.G.%....%",
    "%........%",
    "%%%%%%%%%%"
]
layout = Layout(layout_text)
random_corner = layout.getRandomCorner()  # Possible Output: (1, 1) or (1, 3) etc.
"""
        poses = [(1, 1), (1, self.height - 2), (self.width - 2, 1), (self.
            width - 2, self.height - 2)]
        return random.choice(poses)

    def getFurthestCorner(self, pacPos):
        """
Return the corner position that is furthest from the given Pacman's position.

This method calculates and identifies the corner of the game board that 
is the farthest away (in terms of Manhattan distance) from a specified 
Pacman position. The function aids in strategic gameplay by determining 
corner positions that could provide safe escape routes.

Parameters:
-----------
pacPos : tuple of (int, int)
    A tuple representing the (x, y) coordinates of the Pacman's current 
    position on the game board.

Returns:
--------
tuple of (int, int)
    A tuple representing the (x, y) coordinates of the corner position 
    that is the furthest away from the given Pacman's position.

Usage Example:
--------------
layout_text = [
    "%%%%%%%%%%",
    "%..o.....%",
    "%.G.%....%",
    "%........%",
    "%%%%%%%%%%"
]
layout = Layout(layout_text)
furthest_corner = layout.getFurthestCorner((3, 2))  # Output: (1, 1) or another corner depending on layout
"""
        poses = [(1, 1), (1, self.height - 2), (self.width - 2, 1), (self.
            width - 2, self.height - 2)]
        dist, pos = max([(manhattanDistance(p, pacPos), p) for p in poses])
        return pos

    def isVisibleFrom(self, ghostPos, pacPos, pacDirection):
        """
Determine if a ghost position is visible from the Pacman's position and direction.

This method checks whether a ghost at a specific position can be observed 
from the Pacman's current position while facing a specified direction. 
Visibility is based on the precomputed visibility matrix for the layout.

Parameters:
-----------
ghostPos : tuple of (int, int)
    A tuple representing the (x, y) coordinates of the ghost's position 
    on the game board.

pacPos : tuple of (int, int)
    A tuple representing the (x, y) coordinates of Pacman's current position 
    on the game board.

pacDirection : str
    A string representing the direction in which Pacman is facing. The 
    possible values are 'NORTH', 'SOUTH', 'EAST', 'WEST', and 'STOP'.

Returns:
--------
bool
    True if the ghost is visible from Pacman's position and direction; 
    otherwise, False.

Usage Example:
--------------
layout_text = [
    "%%%%%%%%%%",
    "%..o.....%",
    "%.G.%....%",
    "%........%",
    "%%%%%%%%%%"
]
layout = Layout(layout_text)
is_visible = layout.isVisibleFrom((2, 1), (3, 1), 'NORTH')  # Output: True or False based on visibility
"""
        row, col = [int(x) for x in pacPos]
        return ghostPos in self.visibility[row][col][pacDirection]

    def __str__(self):
        """
Return a string representation of the layout.

This method constructs and returns a formatted string that visualizes 
the current layout of the game board. The representation includes wall, 
food, capsule, ghost, and Pacman positions, making it useful for debugging 
and display purposes.

Parameters:
-----------
None

Returns:
--------
str
    A string that represents the layout of the game board, where each 
    character represents a distinct element of the layout.

Usage Example:
--------------
layout_text = [
    "%%%%%%%%%%",
    "%..o.....%",
    "%.G.%....%",
    "%........%",
    "%%%%%%%%%%"
]
layout = Layout(layout_text)
layout_string = str(layout)
print(layout_string)  # Output: The string representation of the layout
"""
        return '\n'.join(self.layoutText)

    def deepCopy(self):
        """
Create and return a deep copy of the current Layout object.

This method generates a new Layout instance that is a deep copy of the 
current layout, including all walls, food, capsules, agent positions, 
and other attributes. This is useful for preserving the state of the 
layout while making modifications in separate instances.

Parameters:
-----------
None

Returns:
--------
Layout
    A new instance of the Layout class that is a deep copy of the 
    current layout.

Usage Example:
--------------
layout_text = [
    "%%%%%%%%%%",
    "%..o.....%",
    "%.G.%....%",
    "%........%",
    "%%%%%%%%%%"
]
layout = Layout(layout_text)
layout_copy = layout.deepCopy()  # Creates a new Layout object that is a copy of the current one
"""
        return Layout(self.layoutText[:])

    def processLayoutText(self, layoutText):
        """
        Coordinates are flipped from the input format to the (x,y) convention here

        The shape of the maze.  Each character
        represents a different type of object.
         % - Wall
         . - Food
         o - Capsule
         G - Ghost
         P - Pacman
        Other characters are ignored.
        """
        maxY = self.height - 1
        for y in range(self.height):
            for x in range(self.width):
                layoutChar = layoutText[maxY - y][x]
                self.processLayoutChar(x, y, layoutChar)
        self.agentPositions.sort()
        self.agentPositions = [(i == 0, pos) for i, pos in self.agentPositions]

    def processLayoutChar(self, x, y, layoutChar):
        """
Process a single character from the layout text and update the game board structures.

This method interprets a specific character representing an element of 
the game layout, such as walls, food, capsules, ghosts, or Pacman. 
It updates the corresponding attributes of the Layout object based on 
the character's type.

Parameters:
-----------
x : int
    The x-coordinate of the position in the layout where the character 
    is located.

y : int
    The y-coordinate of the position in the layout where the character 
    is located.

layoutChar : str
    A character representing an element of the game layout. The possible 
    values include:
    - '%' for walls
    - '.' for food
    - 'o' for capsules
    - 'G' for ghosts
    - 'P' for Pacman
    Other characters are ignored.

Returns:
--------
None
    This function does not return a value.

Usage Example:
--------------
layout_text = [
    "%%%%%%%%%%",
    "%..o.....%",
    "%.G.%....%",
    "%........%",
    "%%%%%%%%%%"
]
layout = Layout(layout_text)
layout.processLayoutChar(2, 1, 'G')  # Updates the Layout object to reflect a ghost at (2, 1)
"""
        if layoutChar == '%':
            self.walls[x][y] = True
        elif layoutChar == '.':
            self.food[x][y] = True
        elif layoutChar == 'o':
            self.capsules.append((x, y))
        elif layoutChar == 'P':
            self.agentPositions.append((0, (x, y)))
        elif layoutChar in ['G']:
            self.agentPositions.append((1, (x, y)))
            self.numGhosts += 1
        elif layoutChar in ['1', '2', '3', '4']:
            self.agentPositions.append((int(layoutChar), (x, y)))
            self.numGhosts += 1


def getLayout(name, back=2):
    """
Retrieve a layout from a file based on the given name.

This function attempts to load a game layout from a specified file, 
searching in predetermined directories if necessary. It supports layout 
files with both '.lay' extensions and without. In case the layout file 
is not found in the initial directories, it will search up to a specified 
number of parent directory levels.

Parameters:
-----------
name : str
    The name of the layout file to be loaded, either with or without 
    the '.lay' extension.

back : int, optional
    The number of directory levels to search upwards in case the layout 
    file is not found in the original directory. The default value is 2.

Returns:
--------
Layout or None
    A Layout object if the layout file is found and loaded successfully; 
    otherwise, None.

Usage Example:
--------------
layout = getLayout('example_layout')  # Attempts to load 'example_layout.lay' or 'example_layout' layout
if layout:
    print("Layout loaded successfully!")
else:
    print("Layout not found.")
"""
    if name.endswith('.lay'):
        layout = tryToLoad('layouts/' + name)
        if layout == None:
            layout = tryToLoad(name)
    else:
        layout = tryToLoad('layouts/' + name + '.lay')
        if layout == None:
            layout = tryToLoad(name + '.lay')
    if layout == None and back >= 0:
        curdir = os.path.abspath('.')
        os.chdir('..')
        layout = getLayout(name, back - 1)
        os.chdir(curdir)
    return layout


def tryToLoad(fullname):
    """
Attempt to load a layout from a specified file.

This function checks if the given file path exists and, if it does, 
creates and returns a Layout object initialized with the contents 
of the file. If the file does not exist, it returns None.

Parameters:
-----------
fullname : str
    The full path of the layout file to be loaded.

Returns:
--------
Layout or None
    A Layout object if the file exists and is loaded successfully; 
    otherwise, None.

Usage Example:
--------------
layout = tryToLoad('layouts/example_layout.lay')  # Attempts to load the specified layout file
if layout:
    print("Layout loaded successfully!")
else:
    print("Layout file not found.")
"""
    if not os.path.exists(fullname):
        return None
    f = open(fullname)
    try:
        return Layout([line.strip() for line in f])
    finally:
        f.close()
