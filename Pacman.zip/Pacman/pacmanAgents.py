# # Pacman Agent Module Documentation
# 
# This module defines various agents that control the behavior of Pacman in a grid-based environment. The agents implement different strategies for navigating the game board.
# 
# ## Classes
# 
# ### LeftTurnAgent
# 
# The `LeftTurnAgent` class inherits from the `game.Agent` class. This agent is designed to turn left at every opportunity available to it while navigating the game board.
# 
# #### Methods
# 
# - **getAction(state)**: 
#   - **Parameters**: 
#     - `state`: The current game state, which provides access to the legal actions available to the agent.
#   - **Returns**: A direction that the agent chooses based on its left-turning strategy. If a left turn is not available, it will attempt to continue in its current direction, try to turn right, or stop if no other actions are possible. 
# 
# ### GreedyAgent
# 
# The `GreedyAgent` class also inherits from the `Agent` class and implements a greedy strategy in gameplay. It selects actions based on an evaluation function which assesses the desirability of game states.
# 
# #### Methods
# 
# - **__init__(self, evalFn="scoreEvaluation")**: 
#   - **Parameters**: 
#     - `evalFn`: An optional parameter specifying the evaluation function to use for scoring game states. Defaults to "scoreEvaluation".
#   - **Functionality**: Initializes the agent and sets the evaluation function used to determine action desirability. The evaluation function must be valid and exists in the global context.
# 
# - **getAction(state)**: 
#   - **Parameters**: 
#     - `state`: The current game state, including the position of Pacman and the available actions.
#   - **Returns**: A direction representing the best action based on the evaluation of possible successor states. The agent generates all legal successor states, evaluates them using the specified function, and selects the action that leads to the state with the highest score. If there are multiple actions producing the same score, one is selected randomly.
# 
# ## Functions
# 
# ### scoreEvaluation(state)
# 
# - **Parameters**: 
#   - `state`: The current game state to be evaluated.
# - **Returns**: An integer score representing the score of the given game state. This score reflects how favorable the state is for Pacman in the context of the game, based on the current score of Pacman.
# 
# ## Usage
# 
# This file should be used as part of a broader Pacman game implementation where agents interact with a game environment. The defined classes can be utilized to create agents with different strategies for navigating the game board, enhancing gameplay dynamics. 
# 
# In order to ensure the proper functionality of the agents, the game state must provide appropriate methods to retrieve legal actions and generate successor states. The evaluation function selected by `GreedyAgent` can be extended or modified to implement different scoring strategies based on the project's objectives.

from pacman import Directions
from game import Agent
import random
import game
import util


class LeftTurnAgent(game.Agent):
    """An agent that turns left at every opportunity"""

    def getAction(self, state):
        """
        Get the action for the agent based on the current game state.

        This method evaluates all legal actions available to the agent in the 
        current game state and selects the most favorable action based on the
        agent's strategy. The decision-making process varies between agent types, 
        such as a standard left-turning behavior for the LeftTurnAgent or 
        score-based optimization for the GreedyAgent.

        Parameters:
            state (GameState): The current state of the game, providing access to
            the Pacman's position, the legal actions available, and other relevant
            game information.

        Returns:
            Directions: The action that the agent chooses to take, which can be
            one of the valid directions (e.g., NORTH, SOUTH, EAST, WEST) or 
            STOP if no appropriate action is available.

        Example usage:
            agent = GreedyAgent()
            action = agent.getAction(current_game_state)
            print(f"The chosen action is: {action}")
"""
        legal = state.getLegalPacmanActions()
        current = state.getPacmanState().configuration.direction
        if current == Directions.STOP:
            current = Directions.NORTH
        left = Directions.LEFT[current]
        if left in legal:
            return left
        if current in legal:
            return current
        if Directions.RIGHT[current] in legal:
            return Directions.RIGHT[current]
        if Directions.LEFT[left] in legal:
            return Directions.LEFT[left]
        return Directions.STOP


class GreedyAgent(Agent):

    def __init__(self, evalFn='scoreEvaluation'):
        """
        Initialize the GreedyAgent with a specified evaluation function.

        This constructor sets up the agent to evaluate actions based on a scoring
        mechanism determined by the provided evaluation function. The default
        behavior is to use the scoreEvaluation function, which returns the current
        score of the game state. The evaluation function must be valid and should
        be available in the global context.

        Parameters:
            evalFn (str): The name of the evaluation function to use for scoring 
            game states. Defaults to "scoreEvaluation".

        Returns:
            None: This constructor does not return a value but initializes the
            agent's properties.

        Example usage:
            agent = GreedyAgent(evalFn="customEvaluationFunction")
            print("GreedyAgent initialized with custom evaluation function.")
"""
        self.evaluationFunction = util.lookup(evalFn, globals())
        assert self.evaluationFunction != None

    def getAction(self, state):
        """
        Determine the next action for the agent based on the current game state.

        This method computes available actions in the game state and selects 
        the most favorable one according to the agent's strategy. For the 
        LeftTurnAgent, the action will prioritize turning left when possible. 
        For the GreedyAgent, it evaluates the potential successor states and 
        selects the action leading to the highest score.

        Parameters:
            state (GameState): The current state of the game, which includes the 
            positions and legal actions available to the Pacman agent.

        Returns:
            Directions: The action chosen by the agent, which will be one of the
            valid movement directions (e.g., NORTH, SOUTH, EAST, WEST) or 
            STOP if no other action is possible.

        Example usage:
            agent = LeftTurnAgent()
            action = agent.getAction(current_game_state)
            print(f"The selected action is: {action}")
"""
        legal = state.getLegalPacmanActions()
        if Directions.STOP in legal:
            legal.remove(Directions.STOP)
        successors = [(state.generateSuccessor(0, action), action) for
            action in legal]
        scored = [(self.evaluationFunction(state), action) for state,
            action in successors]
        bestScore = max(scored)[0]
        bestActions = [pair[1] for pair in scored if pair[0] == bestScore]
        return random.choice(bestActions)


def scoreEvaluation(state):
    """
        Evaluate the game state and return its score.

        This function computes the score of the current game state as determined 
        by the game's scoring rules. It serves as a standard evaluation function 
        for agents, providing a quantitative measure of how favorable the state 
        is for Pacman.

        Parameters:
            state (GameState): The current state of the game to be evaluated.

        Returns:
            int: The score of the specified game state, reflecting the current 
            conditions and points accumulated by Pacman.

        Example usage:
            score = scoreEvaluation(current_game_state)
            print(f"The current score is: {score}")
"""
    return state.getScore()
