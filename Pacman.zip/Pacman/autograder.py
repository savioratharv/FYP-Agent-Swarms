# This file, `autograder.py`, is designed to facilitate the automated grading of student code in the context of the UC Berkeley Pacman AI project. It provides a command-line interface for running test cases on student implementations, verifying correctness with predefined solutions. The script supports various options, including generating solution files, controlling output verbosity, and managing graphics display during tests.
# 
# Key functionalities include:
# 
# 1. **Command-Line Argument Parsing**: Uses `optparse` to handle user inputs for test directory, student code paths, output settings, and specific test execution requests.
# 
# 2. **Module Loading**: Functions to dynamically load student and test class modules, enabling the script to execute student-written code in a controlled environment.
# 
# 3. **Test Execution**: Defined procedures to read test cases and their corresponding solutions from files, executing the tests while capturing results or generating outputs based on user specifications.
# 
# 4. **Dependency Management**: A method for tracing interdependencies between questions, ensuring prerequisite tests are run before dependent tests.
# 
# 5. **Results Handling**: Facilitates grading by accumulating points from successful test cases, with optional output formats for platforms such as edX and Gradescope.
# 
# 6. **Graphics Support**: Optional visual output for simulations, with fallbacks to text-based interfaces if graphical displays are not available.
# 
# By organizing code in a structured manner and providing detailed usage options, this autograder aims to streamline the assessment process for student submissions in a collaborative educational setting. It leverages existing grading frameworks while allowing for customizable interactions and reports tailored to individual needs.

import grading
import imp
import optparse
import os
import re
import sys
import projectParams
import random
random.seed(0)
try:
    from pacman import GameState
except:
    pass


def readCommand(argv):
    """```python
def readCommand(argv):
    ""\"
    Parse command-line arguments for running public tests on student code.

    This function uses the `optparse` module to define and read command-line
    options that control the behavior of the grading system, such as specifying 
    directories for test cases and student code, generating solution files, 
    and controlling output verbosity.

    Parameters:
    argv (List[str]): A list of command-line arguments, typically `sys.argv`, 
                      that may include options for custom configurations.

    Returns:
    Option: An object containing the parsed command-line options.

    Example:
    >>> options = readCommand(['--test-directory', 'test_cases', '--student-code', 'my_code.py'])
    >>> print(options.testRoot)
    test_cases
    >>> print(options.studentCode)
    my_code.py
    ""\"
```"""
    parser = optparse.OptionParser(description=
        'Run public tests on student code')
    parser.set_defaults(generateSolutions=False, edxOutput=False, gsOutput=
        False, muteOutput=False, printTestCase=False, noGraphics=False)
    parser.add_option('--test-directory', dest='testRoot', default=
        'test_cases', help=
        'Root test directory which contains subdirectories corresponding to each question'
        )
    parser.add_option('--student-code', dest='studentCode', default=
        projectParams.STUDENT_CODE_DEFAULT, help=
        'comma separated list of student code files')
    parser.add_option('--code-directory', dest='codeRoot', default='', help
        ='Root directory containing the student and testClass code')
    parser.add_option('--test-case-code', dest='testCaseCode', default=
        projectParams.PROJECT_TEST_CLASSES, help=
        'class containing testClass classes for this project')
    parser.add_option('--generate-solutions', dest='generateSolutions',
        action='store_true', help='Write solutions generated to .solution file'
        )
    parser.add_option('--edx-output', dest='edxOutput', action='store_true',
        help='Generate edX output files')
    parser.add_option('--gradescope-output', dest='gsOutput', action=
        'store_true', help='Generate GradeScope output files')
    parser.add_option('--mute', dest='muteOutput', action='store_true',
        help='Mute output from executing tests')
    parser.add_option('--print-tests', '-p', dest='printTestCase', action=
        'store_true', help='Print each test case before running them.')
    parser.add_option('--test', '-t', dest='runTest', default=None, help=
        'Run one particular test.  Relative to test root.')
    parser.add_option('--question', '-q', dest='gradeQuestion', default=
        None, help='Grade one particular question.')
    parser.add_option('--no-graphics', dest='noGraphics', action=
        'store_true', help='No graphics display for pacman games.')
    options, args = parser.parse_args(argv)
    return options


def confirmGenerate():
    """```python
def confirmGenerate():
    ""\"
    Prompt the user for confirmation to overwrite existing solution files.

    This function warns the user that proceeding will overwrite any existing 
    solution files and waits for the user's input to either confirm or 
    cancel the action.

    Parameters:
    None

    Returns:
    None

    Example:
    >>> confirmGenerate()  # User is prompted to input "yes" or "no"
    WARNING: this action will overwrite any solution files.
    Are you sure you want to proceed? (yes/no)
    ""\"
```"""
    print('WARNING: this action will overwrite any solution files.')
    print('Are you sure you want to proceed? (yes/no)')
    while True:
        ans = sys.stdin.readline().strip()
        if ans == 'yes':
            break
        elif ans == 'no':
            sys.exit(0)
        else:
            print('please answer either "yes" or "no"')


def setModuleName(module, filename):
    """```python
def setModuleName(module, filename):
    ""\"
    Set the __file__ attribute for functions and classes in a module.

    This function assigns the provided filename to the __file__ attribute 
    of functions and classes within the given module. This is useful for 
    enhancing traceback information in error messages, making it clear 
    from which file a function or class originated.

    Parameters:
    module (ModuleType): The module whose functions and classes will have 
                         their __file__ attribute set.
    filename (str): The filename to assign to the __file__ attribute.

    Returns:
    None

    Example:
    >>> import some_module  # Assume this module contains functions defined in a file
    >>> setModuleName(some_module, 'some_module.py')
    >>> print(some_module.some_function.__file__)
    some_module.py
    ""\"
```"""
    functionType = type(confirmGenerate)
    classType = type(optparse.Option)
    for i in dir(module):
        o = getattr(module, i)
        if hasattr(o, '__file__'):
            continue
        if type(o) == functionType:
            setattr(o, '__file__', filename)
        elif type(o) == classType:
            setattr(o, '__file__', filename)


def loadModuleString(moduleSource):
    """```python
def loadModuleString(moduleSource):
    ""\"
    Load a Python module from a string containing its source code.

    This function creates a new module and executes the provided Python 
    source code string within the module's namespace. It also sets the 
    __file__ attribute for the newly created module to reflect its name.

    Parameters:
    moduleSource (str): The source code of the module as a string.

    Returns:
    ModuleType: The newly created module with the executed source code.

    Example:
    >>> source_code = "def hello(): return 'Hello, World!'"
    >>> my_module = loadModuleString(source_code)
    >>> print(my_module.hello())
    Hello, World!
    ""\"
```"""
    tmp = imp.new_module(k)
    exec(moduleCodeDict[k] in tmp.__dict__)
    setModuleName(tmp, k)
    return tmp


import py_compile


def loadModuleFile(moduleName, filePath):
    """```python
def loadModuleFile(moduleName, filePath):
    ""\"
    Load a Python module from a specified file path.

    This function reads the contents of the file at the given path and 
    loads it as a Python module. The module is imported and made available 
    for use in the current namespace.

    Parameters:
    moduleName (str): The name of the module to be loaded.
    filePath (str): The path to the Python file containing the module's source code.

    Returns:
    ModuleType: The loaded module, making its contents accessible in the namespace.

    Example:
    >>> my_module = loadModuleFile('my_module', 'path/to/my_module.py')
    >>> print(my_module.some_function())
    Result of some_function in my_module
    ""\"
```"""
    with open(filePath, 'r') as f:
        return imp.load_module(moduleName, f, '%s.py' % moduleName, ('.py',
            'r', imp.PY_SOURCE))


def readFile(path, root=''):
    """Read file from disk at specified path and return as string"""
    with open(os.path.join(root, path), 'r') as handle:
        return handle.read()


ERROR_HINT_MAP = {'q1': {"<type 'exceptions.IndexError'>":
    """
      We noticed that your project threw an IndexError on q1.
      While many things may cause this, it may have been from
      assuming a certain number of successors from a state space
      or assuming a certain number of actions available from a given
      state. Try making your code more general (no hardcoded indices)
      and submit again!
    """
    }, 'q3': {"<type 'exceptions.AttributeError'>":
    """
        We noticed that your project threw an AttributeError on q3.
        While many things may cause this, it may have been from assuming
        a certain size or structure to the state space. For example, if you have
        a line of code assuming that the state is (x, y) and we run your code
        on a state space with (x, y, z), this error could be thrown. Try
        making your code more general and submit again!

    """
    }}
import pprint


def splitStrings(d):
    """```python
def splitStrings(d):
    ""\"
    Split string values in a dictionary into lists.

    This function takes a dictionary as input and scans for any string 
    values that contain newline characters. If a value contains newline 
    characters, it is split into a list of strings at those points. 
    The function also removes any keys that start with two underscores.

    Parameters:
    d (dict): The input dictionary with potential string values.

    Returns:
    dict: A new dictionary with string values split into lists and 
          without any keys that start with '__'.

    Example:
    >>> input_dict = {'key1': 'value1\\nvalue2', '__hidden': 'hidden_value', 'key2': 'value3'}
    >>> result = splitStrings(input_dict)
    >>> print(result)
    {'key1': ['value1', 'value2'], 'key2': 'value3'}
    ""\"
```"""
    d2 = dict(d)
    for k in d:
        if k[0:2] == '__':
            del d2[k]
            continue
        if d2[k].find('\n') >= 0:
            d2[k] = d2[k].split('\n')
    return d2


def printTest(testDict, solutionDict):
    """```python
def printTest(testDict, solutionDict):
    ""\"
    Print the details of a test case and its corresponding solution.

    This function takes the dictionaries representing a test case and its 
    expected solution, printing them in a formatted manner. It includes 
    the raw lines from both the test case and the solution, facilitating 
    a clear comparison between the two.

    Parameters:
    testDict (dict): A dictionary containing details about the test case,
                     including the raw lines for display.
    solutionDict (dict): A dictionary containing the expected solution
                         details, also with raw lines.

    Returns:
    None

    Example:
    >>> test_case = {'__raw_lines__': ['input: data', 'expected: output']}
    >>> solution = {'__raw_lines__': ['expected: output']}
    >>> printTest(test_case, solution)
    Test case:
        | input: data
        | expected: output
    Solution:
        | expected: output
    ""\"
```"""
    pp = pprint.PrettyPrinter(indent=4)
    print('Test case:')
    for line in testDict['__raw_lines__']:
        print('   |', line)
    print('Solution:')
    for line in solutionDict['__raw_lines__']:
        print('   |', line)


def runTest(testName, moduleDict, printTestCase=False, display=None):
    """```python
def runTest(testName, moduleDict, printTestCase=False, display=None):
    ""\"
    Execute a specified test case and compare the results with the expected solution.

    This function loads the test case and its expected solution from their 
    respective files, executes the test using the given student modules, 
    and optionally prints the test case details before running the test.

    Parameters:
    testName (str): The name of the test case to run, which corresponds to the 
                    file names for the test and solution.
    moduleDict (dict): A dictionary containing the imported student modules 
                       that will be tested.
    printTestCase (bool, optional): If True, prints the details of the test 
                                     case before execution. Defaults to False.
    display (Graphics, optional): An optional display object for graphical output. 
                                   Defaults to None.

    Returns:
    None

    Example:
    >>> student_modules = {'myCode': loadModuleFile('myCode', 'path/to/myCode.py')}
    >>> runTest('test_case_name', student_modules, printTestCase=True)
    Test case:
        | input: data
        | expected: output
    Solution:
        | expected: output
    ""\"
```"""
    import testParser
    import testClasses
    for module in moduleDict:
        setattr(sys.modules[__name__], module, moduleDict[module])
    testDict = testParser.TestParser(testName + '.test').parse()
    solutionDict = testParser.TestParser(testName + '.solution').parse()
    test_out_file = os.path.join('%s.test_output' % testName)
    testDict['test_out_file'] = test_out_file
    testClass = getattr(projectTestClasses, testDict['class'])
    questionClass = getattr(testClasses, 'Question')
    question = questionClass({'max_points': 0}, display)
    testCase = testClass(question, testDict)
    if printTestCase:
        printTest(testDict, solutionDict)
    grades = grading.Grades(projectParams.PROJECT_NAME, [(None, 0)])
    testCase.execute(grades, moduleDict, solutionDict)


def getDepends(testParser, testRoot, question):
    """```python
def getDepends(testParser, testRoot, question):
    ""\"
    Retrieve a list of dependent questions for a specified question.

    This function checks the configuration file of a given question to 
    determine if there are any prerequisites that must be run before 
    executing the specified question. It recursively collects all 
    dependencies.

    Parameters:
    testParser (TestParser): An instance of the TestParser class used to 
                             parse configuration files for questions.
    testRoot (str): The root directory where test cases are located.
    question (str): The name of the question for which to find dependencies.

    Returns:
    List[str]: A list of question names, including the specified question 
               and all its dependencies.

    Example:
    >>> dependencies = getDepends(testParser, 'test_cases', 'q1')
    >>> print(dependencies)
    ['q2', 'q1']  # Assuming q2 is a prerequisite for q1
    ""\"
```"""
    allDeps = [question]
    questionDict = testParser.TestParser(os.path.join(testRoot, question,
        'CONFIG')).parse()
    if 'depends' in questionDict:
        depends = questionDict['depends'].split()
        for d in depends:
            allDeps = getDepends(testParser, testRoot, d) + allDeps
    return allDeps


def getTestSubdirs(testParser, testRoot, questionToGrade):
    """```python
def getTestSubdirs(testParser, testRoot, questionToGrade):
    ""\"
    Retrieve a list of subdirectories containing test cases for grading.

    This function scans the specified test root directory to find subdirectories 
    that correspond to individual questions. If a specific question is to be graded, 
    it collects any dependencies that need to be addressed first.

    Parameters:
    testParser (TestParser): An instance of the TestParser class used to 
                             read configuration files for the questions.
    testRoot (str): The root directory containing subdirectories for each question.
    questionToGrade (str, optional): The specific question to grade; if provided, 
                                      all dependent questions will also be included.

    Returns:
    List[str]: A list of question names (subdirectory names) to be graded.

    Example:
    >>> test_subdirs = getTestSubdirs(testParser, 'test_cases', 'q1')
    >>> print(test_subdirs)
    ['q2', 'q1']  # Assuming q2 depends on q1
    ""\"
```"""
    problemDict = testParser.TestParser(os.path.join(testRoot, 'CONFIG')
        ).parse()
    if questionToGrade != None:
        questions = getDepends(testParser, testRoot, questionToGrade)
        if len(questions) > 1:
            print(
                'Note: due to dependencies, the following tests will be run: %s'
                 % ' '.join(questions))
        return questions
    if 'order' in problemDict:
        return problemDict['order'].split()
    return sorted(os.listdir(testRoot))


def evaluate(generateSolutions, testRoot, moduleDict, exceptionMap=
    ERROR_HINT_MAP, edxOutput=False, muteOutput=False, gsOutput=False,
    printTestCase=False, questionToGrade=None, display=None):
    """```python
def evaluate(generateSolutions, testRoot, moduleDict, exceptionMap=ERROR_HINT_MAP,
             edxOutput=False, muteOutput=False, gsOutput=False,
             printTestCase=False, questionToGrade=None, display=None):
    ""\"
    Evaluate student code by running test cases and calculating grades.

    This function handles the evaluation of student submissions by loading the 
    necessary test cases, executing them against the student code, and scoring 
    the results. It allows for options such as generating solution files, 
    controlling output verbosity, and handling graphics display.

    Parameters:
    generateSolutions (bool): Whether to generate solution files for the test cases.
    testRoot (str): The root directory containing the test cases to evaluate.
    moduleDict (dict): A dictionary of imported student modules that are being tested.
    exceptionMap (dict, optional): A mapping of exceptions to error messages for 
                                    specific questions. Defaults to a predefined map.
    edxOutput (bool, optional): Whether to generate output in a format compatible 
                                 with edX. Defaults to False.
    muteOutput (bool, optional): If True, suppresses output from executing tests. 
                                  Defaults to False.
    gsOutput (bool, optional): If True, generates output compatible with Gradescope. 
                                Defaults to False.
    printTestCase (bool, optional): If True, prints the details of each test case 
                                     before execution. Defaults to False.
    questionToGrade (str, optional): If specified, only evaluates the provided 
                                      question and its dependencies. Defaults to None.
    display (Graphics, optional): An optional display object for graphical output; 
                                   defaults to None.

    Returns:
    int: The total points scored by the student based on the executed test cases.

    Example:
    >>> module_dict = {'my_module': loadModuleFile('my_module', 'path/to/my_module.py')}
    >>> score = evaluate(False, 'test_cases', module_dict)
    >>> print(score)
    75  # Example score based on the test results
    ""\"
```"""
    import testParser
    import testClasses
    for module in moduleDict:
        setattr(sys.modules[__name__], module, moduleDict[module])
    questions = []
    questionDicts = {}
    test_subdirs = getTestSubdirs(testParser, testRoot, questionToGrade)
    for q in test_subdirs:
        subdir_path = os.path.join(testRoot, q)
        if not os.path.isdir(subdir_path) or q[0] == '.':
            continue
        questionDict = testParser.TestParser(os.path.join(subdir_path,
            'CONFIG')).parse()
        questionClass = getattr(testClasses, questionDict['class'])
        question = questionClass(questionDict, display)
        questionDicts[q] = questionDict
        tests = filter(lambda t: re.match('[^#~.].*\\.test\\Z', t), os.
            listdir(subdir_path))
        tests = map(lambda t: re.match('(.*)\\.test\\Z', t).group(1), tests)
        for t in sorted(tests):
            test_file = os.path.join(subdir_path, '%s.test' % t)
            solution_file = os.path.join(subdir_path, '%s.solution' % t)
            test_out_file = os.path.join(subdir_path, '%s.test_output' % t)
            testDict = testParser.TestParser(test_file).parse()
            if testDict.get('disabled', 'false').lower() == 'true':
                continue
            testDict['test_out_file'] = test_out_file
            testClass = getattr(projectTestClasses, testDict['class'])
            testCase = testClass(question, testDict)

            def makefun(testCase, solution_file):
                """```python
def makefun(testCase, solution_file):
    ""\"
    Create a closure that executes a test case or writes the solution to a file.

    This function returns a lambda function that either executes the provided 
    test case against the student modules and compares results with the expected 
    solution from a specified file, or writes the solution to that file if 
    the `generateSolutions` flag is set to True.

    Parameters:
    testCase (TestCase): An instance of the test case to be executed or 
                         evaluated.
    solution_file (str): The path to the file where the solution should be 
                         written if generating solutions.

    Returns:
    function: A lambda function that, when called, either executes the 
              test case or writes the solution.

    Example:
    >>> test_case_instance = TestCase(...)  # Assume test case is properly instantiated
    >>> solution_path = 'path/to/solution.file'
    >>> test_function = makefun(test_case_instance, solution_path)
    >>> test_function(grades)  # Executes the test or writes the solution based on context
    ""\"
```"""
                if generateSolutions:
                    return lambda grades: testCase.writeSolution(moduleDict,
                        solution_file)
                else:
                    testDict = testParser.TestParser(test_file).parse()
                    solutionDict = testParser.TestParser(solution_file).parse()
                    if printTestCase:
                        return lambda grades: printTest(testDict, solutionDict
                            ) or testCase.execute(grades, moduleDict,
                            solutionDict)
                    else:
                        return lambda grades: testCase.execute(grades,
                            moduleDict, solutionDict)
            question.addTestCase(testCase, makefun(testCase, solution_file))

        def makefun(question):
            """```python
def makefun(testCase, solution_file):
    ""\"
    Create a callable function that executes a test case or writes its solution.

    This function generates and returns a lambda function that, when called, 
    either executes the provided test case using the student modules and compares 
    the results with the expected solution from a specified file or, if 
    generating solutions, writes the solution to that file.

    Parameters:
    testCase (TestCase): An instance of the test case that contains the logic 
                         for executing the test.
    solution_file (str): The path to the file where the solution will be 
                         written if the solution generation is enabled.

    Returns:
    function: A lambda function that executes the test case or writes the 
              solution when invoked.

    Example:
    >>> test_case_instance = TestCase(...)  # Example instantiation of a test case
    >>> solution_path = 'path/to/solution.file'
    >>> execute_test = makefun(test_case_instance, solution_path)
    >>> execute_test(grades)  # Calls the function to execute the test or write the solution
    ""\"
```"""
            return lambda grades: question.execute(grades)
        setattr(sys.modules[__name__], q, makefun(question))
        questions.append((q, question.getMaxPoints()))
    grades = grading.Grades(projectParams.PROJECT_NAME, questions, gsOutput
        =gsOutput, edxOutput=edxOutput, muteOutput=muteOutput)
    if questionToGrade == None:
        for q in questionDicts:
            for prereq in questionDicts[q].get('depends', '').split():
                grades.addPrereq(q, prereq)
    grades.grade(sys.modules[__name__], bonusPic=projectParams.BONUS_PIC)
    return grades.points


def getDisplay(graphicsByDefault, options=None):
    """```python
def getDisplay(graphicsByDefault, options=None):
    ""\"
    Determine and return the appropriate display object based on options.

    This function checks the provided options to determine whether to use 
    graphical or text-based output for the evaluation process. If graphics 
    are enabled by default and not specifically disabled in the options, 
    it attempts to create a graphical display object. If graphical display 
    is not available or has been disabled, it defaults to a text-based 
    display.

    Parameters:
    graphicsByDefault (bool): Indicates whether graphics should be used by default.
    options (Option, optional): An object containing command-line options; 
                                used to check for graphics settings. Defaults to None.

    Returns:
    Graphics: An instance of a graphics display object for visual output, or 
              a text-based display object.

    Example:
    >>> display = getDisplay(True)  # Assuming graphics are available
    >>> type(display)
    <class 'graphicsDisplay.PacmanGraphics'>  # Example output type if graphics are used
    ""\"
```"""
    graphics = graphicsByDefault
    if options is not None and options.noGraphics:
        graphics = False
    if graphics:
        try:
            import graphicsDisplay
            return graphicsDisplay.PacmanGraphics(1, frameTime=0.05)
        except ImportError:
            pass
    import textDisplay
    return textDisplay.NullGraphics()


if __name__ == '__main__':
    options = readCommand(sys.argv)
    if options.generateSolutions:
        confirmGenerate()
    codePaths = options.studentCode.split(',')
    moduleDict = {}
    for cp in codePaths:
        moduleName = re.match('.*?([^/]*)\\.py', cp).group(1)
        moduleDict[moduleName] = loadModuleFile(moduleName, os.path.join(
            options.codeRoot, cp))
    moduleName = re.match('.*?([^/]*)\\.py', options.testCaseCode).group(1)
    moduleDict['projectTestClasses'] = loadModuleFile(moduleName, os.path.
        join(options.codeRoot, options.testCaseCode))
    if options.runTest != None:
        runTest(options.runTest, moduleDict, printTestCase=options.
            printTestCase, display=getDisplay(True, options))
    else:
        evaluate(options.generateSolutions, options.testRoot, moduleDict,
            gsOutput=options.gsOutput, edxOutput=options.edxOutput,
            muteOutput=options.muteOutput, printTestCase=options.
            printTestCase, questionToGrade=options.gradeQuestion, display=
            getDisplay(options.gradeQuestion != None, options))
