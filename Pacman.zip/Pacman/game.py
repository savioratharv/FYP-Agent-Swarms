# /**********************************************************************************
#  *                              IEEE 1016 Documentation                            *
#  **********************************************************************************
#  * File Name: game.py                                                             *
#  * Description: This file contains the implementation of the game environment for *
#  *              a Pacman game simulation. It includes the definitions for agents,  *
#  *              game states, and various utilities for game management and rules.  *
#  *                                                                                  *
#  **********************************************************************************
#  *                              Module Overview                                      *
#  **********************************************************************************
#  * 1. Class Agent                                                                  *
#  *    The base class for all game agents, including Pacman and ghosts. Defines a    *
#  *    method for obtaining actions based on the current game state.                 *
#  *                                                                                  *
#  * 2. Class Directions                                                              *
#  *    Holds direction constants and utility methods for directional manipulation.    *
#  *                                                                                  *
#  * 3. Class Configuration                                                           *
#  *    Represents the position and direction of a character in the game. Provides    *
#  *    methods for generating new configurations based on movement.                  *
#  *                                                                                  *
#  * 4. Class AgentState                                                             *
#  *    Maintains the state of an agent, including position, direction, and scores.   *
#  *                                                                                  *
#  * 5. Class Grid                                                                   *
#  *    Manages a 2D grid layout for game representation and logic. Supports grid     *
#  *    operations such as copying, counting cells, and manipulating cell states.     *
#  *                                                                                  *
#  * 6. Class Actions                                                                *
#  *    Contains static methods for performing actions such as finding possible moves, *
#  *    determining neighbors, and converting between directions and vectors.          *
#  *                                                                                  *
#  * 7. Class GameStateData                                                          *
#  *    Implements the mechanics of maintaining game state information, including     *
#  *    food, capsules, and agent states. Supports copying and comparing game states.  *
#  *                                                                                  *
#  * 8. Class Game                                                                    *
#  *    Orchestrates the control flow of the game, managing agent interactions,      *
#  *    processing game rules, and updating displays.                                 *
#  **********************************************************************************
#  *                             Function Overview                                      *
#  **********************************************************************************
#  *      - Agent.__init__(self, index=0): Initializes the agent with a given index.  *
#  *      - Agent.getAction(self, state): Must be implemented by derived classes;    *
#  *        should return an action based on the game state.                          *
#  *      - Directions class constants: NORTH, SOUTH, EAST, WEST, STOP, LEFT, RIGHT,  *
#  *        REVERSE.                                                                  *
#  *      - Configuration methods for handling agent movement and representing state. *
#  *      - AgentState methods for managing agent-specific information.               *
#  *      - Grid operations for managing the game board structure.                    *
#  *      - Actions class methods for calculating possible actions and directions.     *
#  *      - GameStateData handles initialization and deep copy of game state data.    *
#  *      - The Game class manages the entire game loop and agent interactions.       *
#  **********************************************************************************
#  *                              Usage Note                                          *
#  **********************************************************************************
#  * The user is expected to define their own agent logic by extending the Agent class  *
#  * and implementing the getAction method. Running the game involves creating an      *
#  * instance of the Game class with the desired agents, layout, and rules. The game   *
#  * logic will handle all interactions and updates in accordance with the defined      *
#  * rules and agent behaviors.                                                        *
#  **********************************************************************************
#  *                                   Licensing                                        *
#  **********************************************************************************
#  * This file is provided for educational use. Modification is permitted, but        *
#  * distribution or publishing of solutions is prohibited. Attribution to UC Berkeley, *
#  * including the link http://ai.berkeley.edu, must be retained.                     *
#  **********************************************************************************/

from util import *
import time, os
import traceback
import sys


class Agent:
    """
    An agent must define a getAction method, but may also define the
    following methods which will be called if they exist:

    def registerInitialState(self, state): # inspects the starting state
    """

    def __init__(self, index=0):
        """
Initialize the Agent with the specified index.

Parameters:
    index (int): The index of the agent. This uniquely identifies the agent in a multiparty environment,
                  allowing it to interact with the game state and receive its respective actions.

Returns:
    None

Usage Example:
    >>> agent = Agent(index=1)
    >>> print(agent.index)
    1
"""
        self.index = index

    def getAction(self, state):
        """
        The Agent will receive a GameState (from either {pacman, capture, sonar}.py) and
        must return an action from Directions.{North, South, East, West, Stop}
        """
        raiseNotDefined()


class Directions:
    NORTH = 'North'
    SOUTH = 'South'
    EAST = 'East'
    WEST = 'West'
    STOP = 'Stop'
    LEFT = {NORTH: WEST, SOUTH: EAST, EAST: NORTH, WEST: SOUTH, STOP: STOP}
    RIGHT = dict([(y, x) for x, y in LEFT.items()])
    REVERSE = {NORTH: SOUTH, SOUTH: NORTH, EAST: WEST, WEST: EAST, STOP: STOP}


class Configuration:
    """
    A Configuration holds the (x,y) coordinate of a character, along with its
    traveling direction.

    The convention for positions, like a graph, is that (0,0) is the lower left corner, x increases
    horizontally and y increases vertically.  Therefore, north is the direction of increasing y, or (0,1).
    """

    def __init__(self, pos, direction):
        """
Initialize a new Game instance.

Parameters:
    agents (list): A list of agent instances that will participate in the game.
    display (Display): An instance of a display class responsible for rendering the game state.
    rules (Rules): An instance of a rules class that dictates the game mechanics and flow.
    startingIndex (int, optional): The index of the agent to start the game with. Defaults to 0.
    muteAgents (bool, optional): If True, suppresses output from agents. Defaults to False.
    catchExceptions (bool, optional): If True, catches exceptions that may occur during game execution. Defaults to False.

Returns:
    None

Usage Example:
    >>> game = Game(agents=[agent1, agent2], display=myDisplay, rules=myRules)
    >>> game.run()
"""
        self.pos = pos
        self.direction = direction

    def getPosition(self):
        """
Get the current position of the agent.

This method retrieves the (x, y) coordinates of the agent's current position in the game.

Parameters:
    self: An instance of the AgentState class.

Returns:
    tuple: A tuple containing the (x, y) coordinates of the agent's current position,
           or None if the configuration is not set.

Usage Example:
    >>> agent_state = AgentState(startConfiguration)
    >>> position = agent_state.getPosition()
    >>> print(position)  # Output: (x, y) coordinates, e.g., (5, 3) or None if not set
"""
        return self.pos

    def getDirection(self):
        """
Get the current direction of the agent.

This method retrieves the current direction in which the agent is facing.

Parameters:
    self: An instance of the Configuration class.

Returns:
    str: A string representing the current direction of the agent, which can be one of
         the following values: 'North', 'South', 'East', 'West', or 'Stop'.

Usage Example:
    >>> config = Configuration(pos=(5, 3), direction=Directions.NORTH)
    >>> direction = config.getDirection()
    >>> print(direction)  # Output: 'North'
"""
        return self.direction

    def isInteger(self):
        """
Check if the current position coordinates are integers.

This method determines whether both the x and y coordinates of the agent's position
are integers, which indicates that the agent is positioned on a grid point.

Parameters:
    self: An instance of the Configuration class.

Returns:
    bool: True if both the x and y coordinates are integers, False otherwise.

Usage Example:
    >>> config = Configuration(pos=(2, 3), direction=Directions.NORTH)
    >>> is_integer = config.isInteger()
    >>> print(is_integer)  # Output: True

    >>> config = Configuration(pos=(2.5, 3), direction=Directions.NORTH)
    >>> is_integer = config.isInteger()
    >>> print(is_integer)  # Output: False
"""
        x, y = self.pos
        return x == int(x) and y == int(y)

    def __eq__(self, other):
        """
Determine if this configuration is equal to another configuration.

This method checks if two configurations are equivalent by comparing their position
coordinates and direction.

Parameters:
    self: An instance of the Configuration class.
    other (Configuration or None): The configuration to compare against. If None, the result is False.

Returns:
    bool: True if the position and direction of both configurations are the same, False otherwise.

Usage Example:
    >>> config1 = Configuration(pos=(2, 3), direction=Directions.NORTH)
    >>> config2 = Configuration(pos=(2, 3), direction=Directions.NORTH)
    >>> is_equal = config1 == config2
    >>> print(is_equal)  # Output: True

    >>> config3 = Configuration(pos=(3, 4), direction=Directions.SOUTH)
    >>> is_equal = config1 == config3
    >>> print(is_equal)  # Output: False
"""
        if other == None:
            return False
        return self.pos == other.pos and self.direction == other.direction

    def __hash__(self):
        """
Compute the hash value for a configuration.

This method generates a hash value based on the position coordinates and direction
of the configuration. It allows instances of this class to be used as keys in hash-based
collections such as dictionaries and sets.

Parameters:
    self: An instance of the Configuration class.

Returns:
    int: A hash integer representing the unique state of the configuration based on its
         position and direction.

Usage Example:
    >>> config = Configuration(pos=(2, 3), direction=Directions.NORTH)
    >>> config_hash = hash(config)
    >>> print(config_hash)  # Output: An integer that represents the hash value of the configuration
"""
        x = hash(self.pos)
        y = hash(self.direction)
        return hash(x + 13 * y)

    def __str__(self):
        """
Return a string representation of the configuration.

This method provides a human-readable representation of the configuration, including
the agent's position and direction. It is useful for debugging and logging purposes.

Parameters:
    self: An instance of the Configuration class.

Returns:
    str: A string formatted to display the agent's (x, y) coordinates and its current direction.

Usage Example:
    >>> config = Configuration(pos=(2, 3), direction=Directions.NORTH)
    >>> config_str = str(config)
    >>> print(config_str)  # Output: "(x,y)=(2, 3), North\"
"""
        return '(x,y)=' + str(self.pos) + ', ' + str(self.direction)

    def generateSuccessor(self, vector):
        """
        Generates a new configuration reached by translating the current
        configuration by the action vector.  This is a low-level call and does
        not attempt to respect the legality of the movement.

        Actions are movement vectors.
        """
        x, y = self.pos
        dx, dy = vector
        direction = Actions.vectorToDirection(vector)
        if direction == Directions.STOP:
            direction = self.direction
        return Configuration((x + dx, y + dy), direction)


class AgentState:
    """
    AgentStates hold the state of an agent (configuration, speed, scared, etc).
    """

    def __init__(self, startConfiguration, isPacman):
        """
Initialize a new AgentState instance.

This constructor initializes the state of an agent, including its starting configuration,
whether it is Pacman or a ghost, and includes attributes for the scared timer, number
of items carried, and number of items returned.

Parameters:
    startConfiguration (Configuration): The initial configuration that includes position and direction of the agent.
    isPacman (bool): A boolean indicating if the agent is Pacman (True) or a ghost (False).

Returns:
    None

Usage Example:
    >>> initial_config = Configuration(pos=(1, 1), direction=Directions.NORTH)
    >>> agent_state = AgentState(startConfiguration=initial_config, isPacman=True)
    >>> print(agent_state.isPacman)  # Output: True
"""
        self.start = startConfiguration
        self.configuration = startConfiguration
        self.isPacman = isPacman
        self.scaredTimer = 0
        self.numCarrying = 0
        self.numReturned = 0

    def __str__(self):
        """
Return a string representation of the agent's state.

This method provides a human-readable format for the agent's state, including its
configuration (position and direction) and indicates whether the agent is Pacman
or a ghost. This representation is useful for debugging and logging purposes.

Parameters:
    self: An instance of the AgentState class.

Returns:
    str: A string that describes the agent's type (Pacman or Ghost) and its current state.

Usage Example:
    >>> initial_config = Configuration(pos=(1, 1), direction=Directions.NORTH)
    >>> agent_state = AgentState(startConfiguration=initial_config, isPacman=True)
    >>> print(agent_state)  # Output: "Pacman: (x,y)=(1, 1), North\"
"""
        if self.isPacman:
            return 'Pacman: ' + str(self.configuration)
        else:
            return 'Ghost: ' + str(self.configuration)

    def __eq__(self, other):
        """
Determine if this agent state is equal to another agent state.

This method checks for equality between two instances of AgentState by comparing their
configuration, direction, and scared timer values. It helps to verify if two agents
are in the same state.

Parameters:
    self: An instance of the AgentState class.
    other (AgentState or None): The agent state to compare against. If None, the result is False.

Returns:
    bool: True if the agent states are equal (same configuration and scared timer),
          False otherwise.

Usage Example:
    >>> config1 = Configuration(pos=(2, 3), direction=Directions.NORTH)
    >>> state1 = AgentState(startConfiguration=config1, isPacman=True)
    >>> config2 = Configuration(pos=(2, 3), direction=Directions.NORTH)
    >>> state2 = AgentState(startConfiguration=config2, isPacman=True)
    >>> is_equal = state1 == state2
    >>> print(is_equal)  # Output: True

    >>> state3 = AgentState(startConfiguration=config1, isPacman=False)
    >>> is_equal = state1 == state3
    >>> print(is_equal)  # Output: False
"""
        if other == None:
            return False
        return (self.configuration == other.configuration and self.
            scaredTimer == other.scaredTimer)

    def __hash__(self):
        """
Compute the hash value for the agent's state.

This method generates a unique hash value based on the agent's configuration and
scared timer, allowing instances of AgentState to be used as keys in hash-based
collections such as dictionaries and sets.

Parameters:
    self: An instance of the AgentState class.

Returns:
    int: A hash integer representing the unique state of the agent based on its
         configuration and scared timer.

Usage Example:
    >>> config = Configuration(pos=(2, 3), direction=Directions.NORTH)
    >>> agent_state = AgentState(startConfiguration=config, isPacman=True)
    >>> agent_hash = hash(agent_state)
    >>> print(agent_hash)  # Output: An integer that represents the hash value of the agent state
"""
        return hash(hash(self.configuration) + 13 * hash(self.scaredTimer))

    def copy(self):
        """
Create a copy of the agent's state.

This method generates a new instance of AgentState that is a deep copy of the
current agent state. It includes the same configuration, scared timer, number
of items carried, and number of items returned, ensuring that the new instance
can be modified independently of the original.

Parameters:
    self: An instance of the AgentState class.

Returns:
    AgentState: A new instance of AgentState that is a deep copy of the current instance.

Usage Example:
    >>> initial_config = Configuration(pos=(1, 1), direction=Directions.NORTH)
    >>> agent_state = AgentState(startConfiguration=initial_config, isPacman=True)
    >>> copied_state = agent_state.copy()
    >>> print(copied_state == agent_state)  # Output: True
    >>> copied_state.numCarrying += 1
    >>> print(agent_state.numCarrying)  # Output: 0 (original state remains unchanged)
"""
        state = AgentState(self.start, self.isPacman)
        state.configuration = self.configuration
        state.scaredTimer = self.scaredTimer
        state.numCarrying = self.numCarrying
        state.numReturned = self.numReturned
        return state

    def getPosition(self):
        """
Get the current position of the agent.

This method retrieves the (x, y) coordinates of the agent's current position
from its configuration. If the configuration is not set, it returns None.

Parameters:
    self: An instance of the AgentState class.

Returns:
    tuple or None: A tuple containing the (x, y) coordinates of the agent's current position,
                   or None if the configuration is not set.

Usage Example:
    >>> initial_config = Configuration(pos=(3, 4), direction=Directions.SOUTH)
    >>> agent_state = AgentState(startConfiguration=initial_config, isPacman=True)
    >>> position = agent_state.getPosition()
    >>> print(position)  # Output: (3, 4)

    >>> empty_state = AgentState(startConfiguration=None, isPacman=False)
    >>> position = empty_state.getPosition()
    >>> print(position)  # Output: None
"""
        if self.configuration == None:
            return None
        return self.configuration.getPosition()

    def getDirection(self):
        """
Get the current direction of the agent.

This method retrieves the direction in which the agent is currently facing,
represented as a string. The possible values include 'North', 'South', 'East',
'West', or 'Stop'.

Parameters:
    self: An instance of the Configuration class.

Returns:
    str: A string indicating the current direction of the agent.

Usage Example:
    >>> initial_config = Configuration(pos=(2, 3), direction=Directions.EAST)
    >>> direction = initial_config.getDirection()
    >>> print(direction)  # Output: 'East'

    >>> stopped_config = Configuration(pos=(1, 1), direction=Directions.STOP)
    >>> direction = stopped_config.getDirection()
    >>> print(direction)  # Output: 'Stop'
"""
        return self.configuration.getDirection()


class Grid:
    """
    A 2-dimensional array of objects backed by a list of lists.  Data is accessed
    via grid[x][y] where (x,y) are positions on a Pacman map with x horizontal,
    y vertical and the origin (0,0) in the bottom left corner.

    The __str__ method constructs an output that is oriented like a pacman board.
    """

    def __init__(self, width, height, initialValue=False, bitRepresentation
        =None):
        """
Initialize a new Configuration instance.

This constructor initializes the position and direction of a character in the
game. The position is represented as a tuple of (x, y) coordinates, and
the direction indicates the current facing direction of the character.

Parameters:
    pos (tuple): A tuple representing the (x, y) coordinates of the character's current position.
                 Both values should be numeric (int or float).
    direction (str): A string indicating the direction in which the character is facing.
                     Must be one of the following values: 'North', 'South', 'East', 'West', or 'Stop'.

Returns:
    None

Usage Example:
    >>> config = Configuration(pos=(1, 2), direction=Directions.NORTH)
    >>> print(config.getPosition())  # Output: (1, 2)
    >>> print(config.getDirection())  # Output: 'North'
"""
        if initialValue not in [False, True]:
            raise Exception('Grids can only contain booleans')
        self.CELLS_PER_INT = 30
        self.width = width
        self.height = height
        self.data = [[initialValue for y in range(height)] for x in range(
            width)]
        if bitRepresentation:
            self._unpackBits(bitRepresentation)

    def __getitem__(self, i):
        """
Retrieve the data at a specific index within the grid.

This method allows for indexed access to the grid's data, enabling users to
retrieve the value at the specified x and y coordinates.

Parameters:
    self: An instance of the Grid class.
    i (int): The x-coordinate index of the grid from which data is to be retrieved.

Returns:
    bool: The value at the specified (x, y) coordinates in the grid. This is typically
          a boolean indicating whether a grid cell is occupied (True) or empty (False).

Usage Example:
    >>> grid = Grid(width=5, height=5, initialValue=False)
    >>> grid[2][3] = True  # Setting a cell value to True
    >>> value = grid[2][3]  # Retrieving the value at (2, 3)
    >>> print(value)  # Output: True

    >>> value = grid[0][0]  # Retrieving the initial value
    >>> print(value)  # Output: False
"""
        return self.data[i]

    def __setitem__(self, key, item):
        """
Set the data at a specific index within the grid.

This method allows users to update the value at the specified x-coordinate index in the grid,
enabling modification of the grid's contents.

Parameters:
    self: An instance of the Grid class.
    key (int): The x-coordinate index of the grid cell to be updated.
    item (bool): The new value to be assigned to the specified (x, y) coordinates in the grid.
                 This must be a boolean indicating whether a grid cell is occupied (True) or empty (False).

Returns:
    None

Usage Example:
    >>> grid = Grid(width=5, height=5, initialValue=False)  # Create a 5x5 grid with all values set to False
    >>> grid[2][3] = True  # Set the cell at (2, 3) to True
    >>> print(grid[2][3])  # Output: True

    >>> grid[4][4] = False  # Set the cell at (4, 4) to False
    >>> print(grid[4][4])  # Output: False
"""
        self.data[key] = item

    def __str__(self):
        """
Return a string representation of the grid.

This method constructs a human-readable string that visually represents the contents
of the grid, showing how cells are occupied (with '1' or 'True') or empty (with '0' or 'False').
The output is oriented like a typical game board.

Parameters:
    self: An instance of the Grid class.

Returns:
    str: A string representation of the grid, where each row is displayed on a new line.

Usage Example:
    >>> grid = Grid(width=3, height=3, initialValue=False)
    >>> grid[1][1] = True  # Occupying the center cell
    >>> print(str(grid))
    000
    010
    000

    >>> grid[0][0] = True  # Occupying the top-left cell
    >>> print(str(grid))
    100
    010
    000
"""
        out = [[str(self.data[x][y])[0] for x in range(self.width)] for y in
            range(self.height)]
        out.reverse()
        return '\n'.join([''.join(x) for x in out])

    def __eq__(self, other):
        """
Determine if two grid instances are equal.

This method checks if two grids have the same dimensions and identical contents
by comparing each cell's value in both grids. It is used to verify if two grid
objects represent the same state.

Parameters:
    self: An instance of the Grid class.
    other (Grid or None): The grid to compare against. If None, the result is False.

Returns:
    bool: True if both grids have the same dimensions and contents; False otherwise.

Usage Example:
    >>> grid1 = Grid(width=2, height=2, initialValue=True)
    >>> grid2 = Grid(width=2, height=2, initialValue=True)
    >>> is_equal = grid1 == grid2
    >>> print(is_equal)  # Output: True

    >>> grid3 = Grid(width=2, height=2, initialValue=False)
    >>> is_equal = grid1 == grid3
    >>> print(is_equal)  # Output: False
"""
        if other == None:
            return False
        return self.data == other.data

    def __hash__(self):
        """
Compute the hash value for the grid.

This method generates a unique hash value based on the contents of the grid,
allowing instances of the Grid class to be used as keys in hash-based collections
such as dictionaries and sets.

Parameters:
    self: An instance of the Grid class.

Returns:
    int: A hash integer representing the unique state of the grid based on its
         dimensions and cell values.

Usage Example:
    >>> grid = Grid(width=3, height=3, initialValue=False)
    >>> grid[0][0] = True  # Update some cell values
    >>> grid[1][1] = True
    >>> grid_hash = hash(grid)
    >>> print(grid_hash)  # Output: An integer representing the hash value of the grid
"""
        base = 1
        h = 0
        for l in self.data:
            for i in l:
                if i:
                    h += base
                base *= 2
        return hash(h)

    def copy(self):
        """
Create a deep copy of the grid.

This method generates and returns a new instance of the Grid class that has the same
dimensions and contents as the current grid. The new instance can be modified independently,
ensuring that changes to the copied grid do not affect the original grid.

Parameters:
    self: An instance of the Grid class.

Returns:
    Grid: A new Grid instance that is a deep copy of the current grid.

Usage Example:
    >>> original_grid = Grid(width=3, height=3, initialValue=False)
    >>> original_grid[1][1] = True  # Modify the original grid
    >>> copied_grid = original_grid.copy()
    >>> print(copied_grid[1][1])  # Output: True
    >>> copied_grid[1][1] = False  # Modify the copied grid
    >>> print(original_grid[1][1])  # Output: True (original grid remains unchanged)
"""
        g = Grid(self.width, self.height)
        g.data = [x[:] for x in self.data]
        return g

    def deepCopy(self):
        """
Create a deep copy of the grid.

This method generates and returns a new instance of the Grid class that is a deep copy
of the current grid. The new grid instance contains the same dimensions and cell values
as the original, allowing for independent modification without affecting the original grid.

Parameters:
    self: An instance of the Grid class.

Returns:
    Grid: A new Grid instance that is a deep copy of the current grid.

Usage Example:
    >>> original_grid = Grid(width=4, height=4, initialValue=True)
    >>> original_grid[2][2] = False  # Modify the original grid
    >>> copied_grid = original_grid.deepCopy()
    >>> print(copied_grid[2][2])  # Output: False
    >>> copied_grid[2][2] = True  # Modify the copied grid
    >>> print(original_grid[2][2])  # Output: False (original grid remains unchanged)
"""
        return self.copy()

    def shallowCopy(self):
        """
Create a shallow copy of the grid.

This method generates and returns a new instance of the Grid class that points to the same
data as the current grid. Modifications to the cell values of the copied grid will affect
the original grid as they share the same underlying data structure.

Parameters:
    self: An instance of the Grid class.

Returns:
    Grid: A new Grid instance that is a shallow copy of the current grid.

Usage Example:
    >>> original_grid = Grid(width=3, height=3, initialValue=False)
    >>> original_grid[1][1] = True  # Modify the original grid
    >>> shallow_copied_grid = original_grid.shallowCopy()
    >>> print(shallow_copied_grid[1][1])  # Output: True
    >>> shallow_copied_grid[1][1] = False  # Modify the shallow copy
    >>> print(original_grid[1][1])  # Output: False (original grid is affected)
"""
        g = Grid(self.width, self.height)
        g.data = self.data
        return g

    def count(self, item=True):
        """
Count the number of cells in the grid that match a specified value.

This method counts the total number of cells in the grid that either contain a specified
item (True by default) or are empty (False) by summing up the occurrences in the grid.

Parameters:
    self: An instance of the Grid class.
    item (bool, optional): The value to count in the grid. Defaults to True.

Returns:
    int: The total count of cells in the grid matching the specified item value.

Usage Example:
    >>> grid = Grid(width=4, height=4, initialValue=False)
    >>> grid[0][0] = True  # Occupying a cell
    >>> grid[2][2] = True  # Occupying another cell
    >>> count_true = grid.count(item=True)
    >>> print(count_true)  # Output: 2
    >>> count_false = grid.count(item=False)
    >>> print(count_false)  # Output: 14 (remaining cells)
"""
        return sum([x.count(item) for x in self.data])

    def asList(self, key=True):
        """
Convert the grid into a list of coordinates that match a specified value.

This method iterates through the grid and collects the coordinates of all cells that
contain the specified item value (True by default). It returns a list of tuples, with
each tuple representing the (x, y) coordinates of a matching cell.

Parameters:
    self: An instance of the Grid class.
    key (bool, optional): The value to look for in the grid. Defaults to True.

Returns:
    list: A list of tuples representing the (x, y) coordinates of cells that match
          the specified value.

Usage Example:
    >>> grid = Grid(width=3, height=3, initialValue=False)
    >>> grid[0][1] = True  # Occupying a cell
    >>> grid[1][1] = True  # Occupying another cell
    >>> occupied_cells = grid.asList(key=True)
    >>> print(occupied_cells)  # Output: [(0, 1), (1, 1)]
    
    >>> empty_cells = grid.asList(key=False)
    >>> print(empty_cells)  # Output: [(0, 0), (0, 2), (1, 0), (1, 2), (2, 0), (2, 1), (2, 2)]
"""
        list = []
        for x in range(self.width):
            for y in range(self.height):
                if self[x][y] == key:
                    list.append((x, y))
        return list

    def packBits(self):
        """
        Returns an efficient int list representation

        (width, height, bitPackedInts...)
        """
        bits = [self.width, self.height]
        currentInt = 0
        for i in range(self.height * self.width):
            bit = self.CELLS_PER_INT - i % self.CELLS_PER_INT - 1
            x, y = self._cellIndexToPosition(i)
            if self[x][y]:
                currentInt += 2 ** bit
            if (i + 1) % self.CELLS_PER_INT == 0:
                bits.append(currentInt)
                currentInt = 0
        bits.append(currentInt)
        return tuple(bits)

    def _cellIndexToPosition(self, index):
        """
Convert a cell index to its corresponding (x, y) position in the grid.

This method takes a linear index and calculates the (x, y) coordinates based on the width
of the grid. This is useful for mapping a single index to its position in a two-dimensional
array structure.

Parameters:
    self: An instance of the Grid class.
    index (int): The linear index of the cell in the grid, which should be within the range
                  defined by the grid's width and height.

Returns:
    tuple: A tuple containing the (x, y) coordinates corresponding to the specified index.

Usage Example:
    >>> grid = Grid(width=4, height=3)
    >>> position = grid._cellIndexToPosition(5)
    >>> print(position)  # Output: (1, 1), since cell index 5 corresponds to (1, 1)

    >>> position = grid._cellIndexToPosition(0)
    >>> print(position)  # Output: (0, 0), since cell index 0 corresponds to the top-left corner
"""
        x = index // self.height
        y = index % self.height
        return x, y

    def _unpackBits(self, bits):
        """
        Fills in data from a bit-level representation
        """
        cell = 0
        for packed in bits:
            for bit in self._unpackInt(packed, self.CELLS_PER_INT):
                if cell == self.width * self.height:
                    break
                x, y = self._cellIndexToPosition(cell)
                self[x][y] = bit
                cell += 1

    def _unpackInt(self, packed, size):
        """
Unpack an integer into a list of boolean values.

This method converts a positive integer into a list of boolean values, each representing
a bit in the integer. The size of the returned list is determined by the specified size,
with the most significant bit corresponding to the first element in the list.

Parameters:
    self: An instance of the Grid class.
    packed (int): A positive integer to unpack into boolean values.
    size (int): The number of bits to unpack, which determines the length of the resulting
                boolean list.

Returns:
    list: A list of boolean values where each element corresponds to a bit in the packed
          integer, with True indicating a set bit and False indicating an unset bit.

Usage Example:
    >>> grid = Grid(width=3, height=3)
    >>> bit_list = grid._unpackInt(5, 3)
    >>> print(bit_list)  # Output: [True, False, True], representing binary 101

    >>> bit_list = grid._unpackInt(0, 4)
    >>> print(bit_list)  # Output: [False, False, False, False], representing binary 0000
"""
        bools = []
        if packed < 0:
            raise ValueError('must be a positive integer')
        for i in range(size):
            n = 2 ** (self.CELLS_PER_INT - i - 1)
            if packed >= n:
                bools.append(True)
                packed -= n
            else:
                bools.append(False)
        return bools


def reconstituteGrid(bitRep):
    """
Reconstruct a grid from its bit representation.

This function takes a bit representation of a grid, which may consist of a tuple of width,
height, and packed integers, and reconstructs the corresponding Grid object. If the provided
representation is not in the expected format, it is returned as is.

Parameters:
    bitRep: A bit representation of a grid, expected to be a tuple containing the width,
            height, and packed integers that define the grid layout. If the format is not
            a tuple, it is returned unchanged.

Returns:
    Grid or the original input: A Grid instance constructed from the bit representation,
                                or the original input if the format was not recognized.

Usage Example:
    >>> bit_representation = (3, 3, 5)  # Represents a 3x3 grid
    >>> grid = reconstituteGrid(bit_representation)
    >>> print(grid)  # Output: a Grid instance reflecting the unpacked values

    >>> non_grid_input = [[True, False], [False, True]]
    >>> result = reconstituteGrid(non_grid_input)
    >>> print(result)  # Output: [[True, False], [False, True]] (original input unchanged)
"""
    if type(bitRep) is not type((1, 2)):
        return bitRep
    width, height = bitRep[:2]
    return Grid(width, height, bitRepresentation=bitRep[2:])


class Actions:
    """
    A collection of static methods for manipulating move actions.
    """
    _directions = {Directions.NORTH: (0, 1), Directions.SOUTH: (0, -1),
        Directions.EAST: (1, 0), Directions.WEST: (-1, 0), Directions.STOP:
        (0, 0)}
    _directionsAsList = _directions.items()
    TOLERANCE = 0.001

    def reverseDirection(action):
        """
Reverse the given direction.

This static method takes a direction (North, South, East, or West) and returns its opposite
direction. It is useful for determining the action that would be taken when moving in the 
opposite direction.

Parameters:
    action (str): The direction to reverse. Must be one of the following values:
                   'North', 'South', 'East', 'West', or 'Stop'.

Returns:
    str: The opposite direction to the specified action. If the input is 'Stop', it returns 'Stop'.

Usage Example:
    >>> reversed_direction = Actions.reverseDirection(Directions.NORTH)
    >>> print(reversed_direction)  # Output: 'South'

    >>> reversed_direction = Actions.reverseDirection(Directions.EAST)
    >>> print(reversed_direction)  # Output: 'West'

    >>> reversed_direction = Actions.reverseDirection(Directions.STOP)
    >>> print(reversed_direction)  # Output: 'Stop'
"""
        if action == Directions.NORTH:
            return Directions.SOUTH
        if action == Directions.SOUTH:
            return Directions.NORTH
        if action == Directions.EAST:
            return Directions.WEST
        if action == Directions.WEST:
            return Directions.EAST
        return action
    reverseDirection = staticmethod(reverseDirection)

    def vectorToDirection(vector):
        """
Convert a movement vector to its corresponding direction.

This static method takes a movement vector (dx, dy) and determines the direction it represents.
The output is one of the predefined direction constants, which indicates the direction of movement.

Parameters:
    vector (tuple): A tuple representing a movement vector, where the first element
                    (dx) is the change in the x-coordinate and the second element (dy)
                    is the change in the y-coordinate. Both values should be numeric.

Returns:
    str: The direction corresponding to the input vector. The output will be one of
         the following values: 'North', 'South', 'East', 'West', or 'Stop'.

Usage Example:
    >>> direction = Actions.vectorToDirection((0, 1))
    >>> print(direction)  # Output: 'North'

    >>> direction = Actions.vectorToDirection((1, 0))
    >>> print(direction)  # Output: 'East'

    >>> direction = Actions.vectorToDirection((0, 0))
    >>> print(direction)  # Output: 'Stop'
"""
        dx, dy = vector
        if dy > 0:
            return Directions.NORTH
        if dy < 0:
            return Directions.SOUTH
        if dx < 0:
            return Directions.WEST
        if dx > 0:
            return Directions.EAST
        return Directions.STOP
    vectorToDirection = staticmethod(vectorToDirection)

    def directionToVector(direction, speed=1.0):
        """
Convert a direction to its corresponding movement vector.

This static method takes a direction (North, South, East, or West) and returns the
associated movement vector. The movement vector consists of changes in the x (dx) and
y (dy) coordinates based on the specified direction.

Parameters:
    direction (str): The direction to convert, which must be one of the following values:
                     'North', 'South', 'East', 'West', or 'Stop'.
    speed (float, optional): The speed of the movement. This value modifies the magnitude
                             of the movement vector. Defaults to 1.0.

Returns:
    tuple: A tuple containing the (dx, dy) coordinates that represent the movement vector
           corresponding to the specified direction. If the direction is 'Stop', the output
           will be (0, 0).

Usage Example:
    >>> vector = Actions.directionToVector(Directions.NORTH)
    >>> print(vector)  # Output: (0, 1)

    >>> vector = Actions.directionToVector(Directions.EAST, speed=2.0)
    >>> print(vector)  # Output: (2.0, 0)

    >>> vector = Actions.directionToVector(Directions.STOP)
    >>> print(vector)  # Output: (0, 0)
"""
        dx, dy = Actions._directions[direction]
        return dx * speed, dy * speed
    directionToVector = staticmethod(directionToVector)

    def getPossibleActions(config, walls):
        """
Get a list of possible actions that can be taken from the current configuration.

This static method evaluates the current position and direction of the agent, along with
the walls in the environment, to determine which movements are legal. It returns a list of
directions that the agent can move without colliding with walls.

Parameters:
    config (Configuration): An instance of the Configuration class representing the
                            current position and direction of the agent.
    walls (Grid): An instance of the Grid class that indicates the layout of walls
                  in the environment. Cells that are walls should contain True.

Returns:
    list: A list of strings representing the possible actions the agent can take,
          which may include 'North', 'South', 'East', 'West', or 'Stop'.

Usage Example:
    >>> walls = Grid(width=5, height=5, initialValue=False)
    >>> walls[2][1] = True  # Set a wall
    >>> walls[2][2] = True  # Set another wall
    >>> config = Configuration(pos=(2.5, 2), direction=Directions.NORTH)
    >>> possible_actions = Actions.getPossibleActions(config, walls)
    >>> print(possible_actions)  # Output: ['South', 'Stop', 'East'] since North is blocked

    >>> config = Configuration(pos=(1, 1), direction=Directions.NORTH)
    >>> possible_actions = Actions.getPossibleActions(config, walls)
    >>> print(possible_actions)  # Output could include ['North', 'South', 'East', 'West']
"""
        possible = []
        x, y = config.pos
        x_int, y_int = int(x + 0.5), int(y + 0.5)
        if abs(x - x_int) + abs(y - y_int) > Actions.TOLERANCE:
            return [config.getDirection()]
        for dir, vec in Actions._directionsAsList:
            dx, dy = vec
            next_y = y_int + dy
            next_x = x_int + dx
            if not walls[next_x][next_y]:
                possible.append(dir)
        return possible
    getPossibleActions = staticmethod(getPossibleActions)

    def getLegalNeighbors(position, walls):
        """
Get the legal neighboring positions of a given position in the grid.

This static method retrieves all valid neighboring coordinates that can be reached from
the current position, considering the walls in the environment. It examines the four
cardinal directions (North, South, East, West) to determine which neighboring positions
are not blocked by walls.

Parameters:
    position (tuple): A tuple representing the current (x, y) coordinates of the agent in the grid.
    walls (Grid): An instance of the Grid class indicating the layout of walls in the environment.
                  Cells that are walls should contain True.

Returns:
    list: A list of tuples representing the (x, y) coordinates of the legal neighboring positions.

Usage Example:
    >>> walls = Grid(width=5, height=5, initialValue=False)
    >>> walls[1][2] = True  # Set a wall
    >>> walls[2][1] = True  # Set another wall
    >>> position = (2, 2)
    >>> legal_neighbors = Actions.getLegalNeighbors(position, walls)
    >>> print(legal_neighbors)  # Output: [(2, 3), (2, 1), (3, 2)] depending on wall placements

    >>> position = (1, 1)
    >>> legal_neighbors = Actions.getLegalNeighbors(position, walls)
    >>> print(legal_neighbors)  # Output could include [(0, 1), (1, 2), (2, 1)]
"""
        x, y = position
        x_int, y_int = int(x + 0.5), int(y + 0.5)
        neighbors = []
        for dir, vec in Actions._directionsAsList:
            dx, dy = vec
            next_x = x_int + dx
            if next_x < 0 or next_x == walls.width:
                continue
            next_y = y_int + dy
            if next_y < 0 or next_y == walls.height:
                continue
            if not walls[next_x][next_y]:
                neighbors.append((next_x, next_y))
        return neighbors
    getLegalNeighbors = staticmethod(getLegalNeighbors)

    def getSuccessor(position, action):
        """
Calculate the successor position based on a direction action.

This static method takes the current position and a specified action (direction),
and computes the new position that would result from applying that action. This
is useful for simulating the movement of an agent within the game environment.

Parameters:
    position (tuple): A tuple representing the current (x, y) coordinates of the agent.
    action (str): A string indicating the direction of movement. Must be one of the following values:
                   'North', 'South', 'East', 'West', or 'Stop'.

Returns:
    tuple: A tuple representing the new (x, y) coordinates of the agent after applying the given action.

Usage Example:
    >>> current_position = (2, 3)
    >>> new_position = Actions.getSuccessor(current_position, Directions.NORTH)
    >>> print(new_position)  # Output: (2, 4), moving north increases the y-coordinate

    >>> new_position = Actions.getSuccessor(current_position, Directions.WEST)
    >>> print(new_position)  # Output: (1, 3), moving west decreases the x-coordinate

    >>> new_position = Actions.getSuccessor(current_position, Directions.STOP)
    >>> print(new_position)  # Output: (2, 3), position remains unchanged
"""
        dx, dy = Actions.directionToVector(action)
        x, y = position
        return x + dx, y + dy
    getSuccessor = staticmethod(getSuccessor)


class GameStateData:
    """

    """

    def __init__(self, prevState=None):
        """
        Generates a new data packet by copying information from its predecessor.
        """
        if prevState != None:
            self.food = prevState.food.shallowCopy()
            self.capsules = prevState.capsules[:]
            self.agentStates = self.copyAgentStates(prevState.agentStates)
            self.layout = prevState.layout
            self._eaten = prevState._eaten
            self.score = prevState.score
        self._foodEaten = None
        self._foodAdded = None
        self._capsuleEaten = None
        self._agentMoved = None
        self._lose = False
        self._win = False
        self.scoreChange = 0

    def deepCopy(self):
        """
Create a deep copy of the game state data.

This method generates and returns a new instance of the GameStateData class that is a deep copy
of the current game state. This includes duplicating all relevant attributes such as food, capsules,
agent states, and the score, ensuring that modifications to the copied instance do not affect the
original game state.

Parameters:
    self: An instance of the GameStateData class.

Returns:
    GameStateData: A new instance of GameStateData that is a deep copy of the current instance.

Usage Example:
    >>> original_state = GameStateData()
    >>> original_state.food = Grid(width=5, height=5, initialValue=True)  # Initialize food grid
    >>> original_state.score = 10
    >>> copied_state = original_state.deepCopy()
    >>> print(copied_state.score)  # Output: 10
    >>> copied_state.score = 20  # Modify the copy
    >>> print(original_state.score)  # Output: 10 (original state remains unchanged)
"""
        state = GameStateData(self)
        state.food = self.food.deepCopy()
        state.layout = self.layout.deepCopy()
        state._agentMoved = self._agentMoved
        state._foodEaten = self._foodEaten
        state._foodAdded = self._foodAdded
        state._capsuleEaten = self._capsuleEaten
        return state

    def copyAgentStates(self, agentStates):
        """
Create a copy of the agent states.

This method takes a list of agent states and returns a new list containing copies
of each agent state. The new list maintains the same order as the original, ensuring
that all relevant attributes for each agent are duplicated while remaining isolated from the original list.

Parameters:
    self: An instance of the GameStateData class.
    agentStates (list): A list of AgentState instances to be copied.

Returns:
    list: A list of new AgentState instances that are deep copies of the provided agent states.

Usage Example:
    >>> agent_states = [AgentState(Configuration((1, 1), Directions.NORTH), isPacman=True),
    ...                 AgentState(Configuration((2, 2), Directions.SOUTH), isPacman=False)]
    >>> game_state = GameStateData()
    >>> copied_states = game_state.copyAgentStates(agent_states)
    >>> print(copied_states[0] == agent_states[0])  # Output: True
    >>> copied_states[0].numCarrying += 1  # Modify the copy
    >>> print(agent_states[0].numCarrying)  # Output: 0 (original state remains unchanged)
"""
        copiedStates = []
        for agentState in agentStates:
            copiedStates.append(agentState.copy())
        return copiedStates

    def __eq__(self, other):
        """
        Allows two states to be compared.
        """
        if other == None:
            return False
        if not self.agentStates == other.agentStates:
            return False
        if not self.food == other.food:
            return False
        if not self.capsules == other.capsules:
            return False
        if not self.score == other.score:
            return False
        return True

    def __hash__(self):
        """
        Allows states to be keys of dictionaries.
        """
        for i, state in enumerate(self.agentStates):
            try:
                int(hash(state))
            except TypeError as e:
                print(e)
        return int((hash(tuple(self.agentStates)) + 13 * hash(self.food) + 
            113 * hash(tuple(self.capsules)) + 7 * hash(self.score)) % 1048575)

    def __str__(self):
        """
Return a string representation of the game state.

This method constructs a human-readable representation of the current game state,
including the layout of the grid, the position and direction of each agent, and the
current score. It provides a visual summary of the game state for debugging and
display purposes.

Parameters:
    self: An instance of the GameStateData class.

Returns:
    str: A string that visually represents the game state, formatted to display the
         grid layout and agent positions.

Usage Example:
    >>> game_state = GameStateData()
    >>> game_state.food = Grid(width=3, height=3, initialValue=False)
    >>> game_state.food[1][1] = True  # Set a food cell
    >>> game_state.agentStates = [
    ...     AgentState(Configuration((1, 1), Directions.NORTH), isPacman=True),
    ...     AgentState(Configuration((2, 2), Directions.SOUTH), isPacman=False)
    ... ]
    >>> print(str(game_state))
    000
    010
    000
    Score: 0
"""
        width, height = self.layout.width, self.layout.height
        map = Grid(width, height)
        if type(self.food) == type((1, 2)):
            self.food = reconstituteGrid(self.food)
        for x in range(width):
            for y in range(height):
                food, walls = self.food, self.layout.walls
                map[x][y] = self._foodWallStr(food[x][y], walls[x][y])
        for agentState in self.agentStates:
            if agentState == None:
                continue
            if agentState.configuration == None:
                continue
            x, y = [int(i) for i in nearestPoint(agentState.configuration.pos)]
            agent_dir = agentState.configuration.direction
            if agentState.isPacman:
                map[x][y] = self._pacStr(agent_dir)
            else:
                map[x][y] = self._ghostStr(agent_dir)
        for x, y in self.capsules:
            map[x][y] = 'o'
        return str(map) + '\nScore: %d\n' % self.score

    def _foodWallStr(self, hasFood, hasWall):
        """
Generate a character representation for a food cell and its corresponding wall.

This private method determines the appropriate character to represent a cell in the
game's grid based on whether it contains food and whether there is a wall in that cell.
It is used to format the visual output of the game state.

Parameters:
    self: An instance of the GameStateData class.
    hasFood (bool): A boolean indicating whether the cell contains food (True) or not (False).
    hasWall (bool): A boolean indicating whether there is a wall in the cell (True) or not (False).

Returns:
    str: A single character representation of the cell. This will be:
         - '.' if the cell contains food and no wall,
         - '%' if the cell contains a wall and no food,
         - ' ' (a space) if the cell is empty and has no wall.

Usage Example:
    >>> food_wall_str = GameStateData._foodWallStr(None, hasFood=True, hasWall=False)
    >>> print(food_wall_str)  # Output: '.'
    
    >>> food_wall_str = GameStateData._foodWallStr(None, hasFood=False, hasWall=True)
    >>> print(food_wall_str)  # Output: '%'
    
    >>> food_wall_str = GameStateData._foodWallStr(None, hasFood=False, hasWall=False)
    >>> print(food_wall_str)  # Output: ' '
"""
        if hasFood:
            return '.'
        elif hasWall:
            return '%'
        else:
            return ' '

    def _pacStr(self, dir):
        """
Generate a character representation for the Pacman agent.

This private method returns a specific character representation based on the direction
in which Pacman is currently facing. It is used to visually depict Pacman in the game's
grid layout.

Parameters:
    self: An instance of the GameStateData class.
    dir (str): A string representing the direction Pacman is facing. This should be one
                of the following values: 'North', 'South', 'East', or 'West'.

Returns:
    str: A character representing Pacman facing the specified direction. The output will
         be:
         - 'v' if facing 'North',
         - '^' if facing 'South',
         - '>' if facing 'East',
         - '<' if facing 'West'.

Usage Example:
    >>> pacman_str = GameStateData._pacStr(Directions.NORTH)
    >>> print(pacman_str)  # Output: 'v'

    >>> pacman_str = GameStateData._pacStr(Directions.SOUTH)
    >>> print(pacman_str)  # Output: '^'

    >>> pacman_str = GameStateData._pacStr(Directions.EAST)
    >>> print(pacman_str)  # Output: '>'

    >>> pacman_str = GameStateData._pacStr(Directions.WEST)
    >>> print(pacman_str)  # Output: '<'
"""
        if dir == Directions.NORTH:
            return 'v'
        if dir == Directions.SOUTH:
            return '^'
        if dir == Directions.WEST:
            return '>'
        return '<'

    def _ghostStr(self, dir):
        """
Generate a character representation for the ghost agent.

This private method returns a specific character representation based on the direction
in which the ghost is currently facing. It is utilized to visually depict the ghost in
the game's grid layout.

Parameters:
    self: An instance of the GameStateData class.
    dir (str): A string representing the direction the ghost is facing. This should be
                one of the following values: 'North', 'South', 'East', or 'West'.

Returns:
    str: A character representing the ghost facing the specified direction. The output
         will be:
         - 'M' if facing 'North',
         - 'W' if facing 'South',
         - '3' if facing 'West',
         - 'E' if facing 'East'.

Usage Example:
    >>> ghost_str = GameStateData._ghostStr(Directions.NORTH)
    >>> print(ghost_str)  # Output: 'M'

    >>> ghost_str = GameStateData._ghostStr(Directions.SOUTH)
    >>> print(ghost_str)  # Output: 'W'

    >>> ghost_str = GameStateData._ghostStr(Directions.EAST)
    >>> print(ghost_str)  # Output: 'E'

    >>> ghost_str = GameStateData._ghostStr(Directions.WEST)
    >>> print(ghost_str)  # Output: '3'
"""
        return 'G'
        if dir == Directions.NORTH:
            return 'M'
        if dir == Directions.SOUTH:
            return 'W'
        if dir == Directions.WEST:
            return '3'
        return 'E'

    def initialize(self, layout, numGhostAgents):
        """
        Creates an initial game state from a layout array (see layout.py).
        """
        self.food = layout.food.copy()
        self.capsules = layout.capsules[:]
        self.layout = layout
        self.score = 0
        self.scoreChange = 0
        self.agentStates = []
        numGhosts = 0
        for isPacman, pos in layout.agentPositions:
            if not isPacman:
                if numGhosts == numGhostAgents:
                    continue
                else:
                    numGhosts += 1
            self.agentStates.append(AgentState(Configuration(pos,
                Directions.STOP), isPacman))
        self._eaten = [(False) for a in self.agentStates]


try:
    import boinc
    _BOINC_ENABLED = True
except:
    _BOINC_ENABLED = False


class Game:
    """
    The Game manages the control flow, soliciting actions from agents.
    """

    def __init__(self, agents, display, rules, startingIndex=0, muteAgents=
        False, catchExceptions=False):
        """
Initialize a new GameStateData instance.

This constructor initializes the game state, including setting up the food grid,
agent states, capsules, and score. If a previous state is provided, it copies the
relevant information to the new instance.

Parameters:
    prevState (GameStateData or None): An optional previous state from which to copy
                                        attributes. If None, a new game state is initialized.

Returns:
    None

Usage Example:
    >>> initial_state = GameStateData()
    >>> initial_state.food = Grid(width=5, height=5, initialValue=True)  # Create a food grid
    >>> initial_state.score = 0  # Initialize score
    >>> agent_state = AgentState(Configuration((1, 1), Directions.NORTH), isPacman=True)
    >>> initial_state.agentStates.append(agent_state)  # Add an agent state
    >>> print(initial_state.score)  # Output: 0
"""
        self.agentCrashed = False
        self.agents = agents
        self.display = display
        self.rules = rules
        self.startingIndex = startingIndex
        self.gameOver = False
        self.muteAgents = muteAgents
        self.catchExceptions = catchExceptions
        self.moveHistory = []
        self.totalAgentTimes = [(0) for agent in agents]
        self.totalAgentTimeWarnings = [(0) for agent in agents]
        self.agentTimeout = False
        import io
        self.agentOutput = [io.StringIO() for agent in agents]

    def getProgress(self):
        """
Calculate the progress of the game.

This method computes the current progress of the game as a float value between 0.0 and 1.0,
where 0.0 represents the beginning of the game and 1.0 represents the end of the game. 
The calculation is based on the current state of the game, such as the number of food items eaten.

Parameters:
    self: An instance of the Game class.

Returns:
    float: A float value indicating the game's progress, ranging from 0.0 to 1.0.

Usage Example:
    >>> game = Game(agents=[agent1, agent2], display=myDisplay, rules=myRules)
    >>> progress = game.getProgress()
    >>> print(progress)  # Output: A float value between 0.0 and 1.0 representing the game's progress
"""
        if self.gameOver:
            return 1.0
        else:
            return self.rules.getProgress(self)

    def _agentCrash(self, agentIndex, quiet=False):
        """Helper method for handling agent crashes"""
        if not quiet:
            traceback.print_exc()
        self.gameOver = True
        self.agentCrashed = True
        self.rules.agentCrash(self, agentIndex)
    OLD_STDOUT = None
    OLD_STDERR = None

    def mute(self, agentIndex):
        """
Suppress output from a specified agent.

This method temporarily redirects the standard output (stdout) and standard error (stderr) 
streams for a specific agent to prevent any printed messages during their execution. This is 
useful for handling agents that may generate unwanted output, especially during automated 
testing or evaluation.

Parameters:
    self: An instance of the Game class.
    agentIndex (int): The index of the agent whose output is to be muted. This should correspond 
                      to the position of the agent in the agents list.

Returns:
    None

Usage Example:
    >>> game = Game(agents=[agent1, agent2], display=myDisplay, rules=myRules)
    >>> game.mute(0)  # Mute output for the first agent
    >>> # Agent 0's print statements will not be displayed during execution
"""
        if not self.muteAgents:
            return
        global OLD_STDOUT, OLD_STDERR
        import io
        OLD_STDOUT = sys.stdout
        OLD_STDERR = sys.stderr
        sys.stdout = self.agentOutput[agentIndex]
        sys.stderr = self.agentOutput[agentIndex]

    def unmute(self):
        """
Restore output for a previously muted agent.

This method reverts the standard output (stdout) and standard error (stderr) streams back
to their original state for a specific agent. It allows the agent to print messages again
after being muted, enabling visibility of output during their execution.

Parameters:
    self: An instance of the Game class.

Returns:
    None

Usage Example:
    >>> game = Game(agents=[agent1, agent2], display=myDisplay, rules=myRules)
    >>> game.mute(0)  # Mute output for the first agent
    >>> # Agent 0's print statements will not be displayed during execution
    >>> game.unmute()  # Restore output for all muted agents
    >>> # Agent 0 can now print messages again
"""
        if not self.muteAgents:
            return
        global OLD_STDOUT, OLD_STDERR
        sys.stdout = OLD_STDOUT
        sys.stderr = OLD_STDERR

    def run(self):
        """
        Main control loop for game play.
        """
        self.display.initialize(self.state.data)
        self.numMoves = 0
        for i in range(len(self.agents)):
            agent = self.agents[i]
            if not agent:
                self.mute(i)
                print('Agent %d failed to load' % i, file=sys.stderr)
                self.unmute()
                self._agentCrash(i, quiet=True)
                return
            if 'registerInitialState' in dir(agent):
                self.mute(i)
                if self.catchExceptions:
                    try:
                        timed_func = TimeoutFunction(agent.
                            registerInitialState, int(self.rules.
                            getMaxStartupTime(i)))
                        try:
                            start_time = time.time()
                            timed_func(self.state.deepCopy())
                            time_taken = time.time() - start_time
                            self.totalAgentTimes[i] += time_taken
                        except TimeoutFunctionException:
                            print('Agent %d ran out of time on startup!' %
                                i, file=sys.stderr)
                            self.unmute()
                            self.agentTimeout = True
                            self._agentCrash(i, quiet=True)
                            return
                    except Exception as data:
                        self._agentCrash(i, quiet=False)
                        self.unmute()
                        return
                else:
                    agent.registerInitialState(self.state.deepCopy())
                self.unmute()
        agentIndex = self.startingIndex
        numAgents = len(self.agents)
        while not self.gameOver:
            agent = self.agents[agentIndex]
            move_time = 0
            skip_action = False
            if 'observationFunction' in dir(agent):
                self.mute(agentIndex)
                if self.catchExceptions:
                    try:
                        timed_func = TimeoutFunction(agent.
                            observationFunction, int(self.rules.
                            getMoveTimeout(agentIndex)))
                        try:
                            start_time = time.time()
                            observation = timed_func(self.state.deepCopy())
                        except TimeoutFunctionException:
                            skip_action = True
                        move_time += time.time() - start_time
                        self.unmute()
                    except Exception as data:
                        self._agentCrash(agentIndex, quiet=False)
                        self.unmute()
                        return
                else:
                    observation = agent.observationFunction(self.state.
                        deepCopy())
                self.unmute()
            else:
                observation = self.state.deepCopy()
            action = None
            self.mute(agentIndex)
            if self.catchExceptions:
                try:
                    timed_func = TimeoutFunction(agent.getAction, int(self.
                        rules.getMoveTimeout(agentIndex)) - int(move_time))
                    try:
                        start_time = time.time()
                        if skip_action:
                            raise TimeoutFunctionException()
                        action = timed_func(observation)
                    except TimeoutFunctionException:
                        print('Agent %d timed out on a single move!' %
                            agentIndex, file=sys.stderr)
                        self.agentTimeout = True
                        self._agentCrash(agentIndex, quiet=True)
                        self.unmute()
                        return
                    move_time += time.time() - start_time
                    if move_time > self.rules.getMoveWarningTime(agentIndex):
                        self.totalAgentTimeWarnings[agentIndex] += 1
                        print(
                            'Agent %d took too long to make a move! This is warning %d'
                             % (agentIndex, self.totalAgentTimeWarnings[
                            agentIndex]), file=sys.stderr)
                        if self.totalAgentTimeWarnings[agentIndex
                            ] > self.rules.getMaxTimeWarnings(agentIndex):
                            print(
                                'Agent %d exceeded the maximum number of warnings: %d'
                                 % (agentIndex, self.totalAgentTimeWarnings
                                [agentIndex]), file=sys.stderr)
                            self.agentTimeout = True
                            self._agentCrash(agentIndex, quiet=True)
                            self.unmute()
                            return
                    self.totalAgentTimes[agentIndex] += move_time
                    if self.totalAgentTimes[agentIndex
                        ] > self.rules.getMaxTotalTime(agentIndex):
                        print('Agent %d ran out of time! (time: %1.2f)' % (
                            agentIndex, self.totalAgentTimes[agentIndex]),
                            file=sys.stderr)
                        self.agentTimeout = True
                        self._agentCrash(agentIndex, quiet=True)
                        self.unmute()
                        return
                    self.unmute()
                except Exception as data:
                    self._agentCrash(agentIndex)
                    self.unmute()
                    return
            else:
                action = agent.getAction(observation)
            self.unmute()
            self.moveHistory.append((agentIndex, action))
            if self.catchExceptions:
                try:
                    self.state = self.state.generateSuccessor(agentIndex,
                        action)
                except Exception as data:
                    self.mute(agentIndex)
                    self._agentCrash(agentIndex)
                    self.unmute()
                    return
            else:
                self.state = self.state.generateSuccessor(agentIndex, action)
            self.display.update(self.state.data)
            self.rules.process(self.state, self)
            if agentIndex == numAgents + 1:
                self.numMoves += 1
            agentIndex = (agentIndex + 1) % numAgents
            if _BOINC_ENABLED:
                boinc.set_fraction_done(self.getProgress())
        for agentIndex, agent in enumerate(self.agents):
            if 'final' in dir(agent):
                try:
                    self.mute(agentIndex)
                    agent.final(self.state)
                    self.unmute()
                except Exception as data:
                    if not self.catchExceptions:
                        raise data
                    self._agentCrash(agentIndex)
                    self.unmute()
                    return
        self.display.finish()
