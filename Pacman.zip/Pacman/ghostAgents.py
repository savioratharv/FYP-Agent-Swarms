# /******************************************************************************\
#  * File Name: ghostAgents.py                                                  *
#  * Purpose: This file contains the implementation of ghost agents for the     *
#  * Pacman AI project. The ghosts behave differently based on their strategies, *
#  * including random movement and directional movement towards or away from    *
#  * Pacman.                                                                      *
#  *                                                                              *
#  * Licensing Information:                                                      *
#  * You are free to use or extend these projects for educational purposes       *
#  * provided that (1) you do not distribute or publish solutions, (2) you      *
#  * retain this notice, and (3) you provide clear attribution to UC Berkeley,   *
#  * including a link to http://ai.berkeley.edu.                                 *
#  *                                                                              *
#  * Attribution Information:                                                    *
#  * The Pacman AI projects were developed at UC Berkeley. The core projects and  *
#  * autograders were primarily created by John DeNero (denero@cs.berkeley.edu)  *
#  * and Dan Klein (klein@cs.berkeley.edu). Student side autograding was added   *
#  * by Brad Miller, Nick Hay, and Pieter Abbeel (pabbeel@cs.berkeley.edu).     *
#  *                                                                              *
#  * Functions defined externally:                                               *
#  * - manhattanDistance                                                          *
#  *   This function calculates the Manhattan distance between two points in a   *
#  *   2D grid, defined as the sum of the absolute differences of their          *
#  *   Cartesian coordinates.                                                    *
#  *                                                                              *
#  * Class: GhostAgent                                                            *
#  * Description: An abstract class representing a ghost agent. It provides the  *
#  * basic structure for individual ghost behaviors.                             *
#  *                                                                              *
#  * Methods:                                                                    *
#  * - __init__(self, index): Initializes the ghost agent with its index.       *
#  * - getAction(self, state): Returns the action the ghost will take given the  *
#  *   current state of the game.                                               *
#  * - getDistribution(self, state): Should be overridden to provide a specific  *
#  *   action distribution for the ghost.                                       *
#  *                                                                              *
#  * Class: RandomGhost                                                          *
#  * Description: A ghost agent that chooses its actions uniformly at random     *
#  * from the set of legal actions available to it.                             *
#  *                                                                              *
#  * Methods:                                                                    *
#  * - __init__(self, index): Initializes the random ghost with its index.       *
#  * - getDistribution(self, state): Returns a uniform distribution over the      *
#  *   legal actions available to the ghost.                                     *
#  *                                                                              *
#  * Class: DirectionalGhost                                                     *
#  * Description: A ghost agent that decides its actions based on its proximity   *
#  * to Pacman, preferring to rush towards Pacman if unscared, and flee from     *
#  * Pacman if scared.                                                            *
#  *                                                                              *
#  * Attributes:                                                                *
#  * - index: The index of the ghost.                                             *
#  * - prob_attack: The probability the ghost will attack Pacman.                *
#  * - prob_scaredFlee: The probability the ghost will flee when scared.        *
#  *                                                                              *
#  * Methods:                                                                    *
#  * - __init__(self, index, prob_attack=0.8, prob_scaredFlee=0.8):           *
#  *   Initializes the directional ghost with its index and probabilities for     *
#  *   attacking and fleeing.                                                     *
#  * - getDistribution(self, state): Returns a distribution over actions based     *
#  *   on the ghost's behavior toward Pacman, considering whether the ghost is    *
#  *   scared or not.                                                             *
# \*******************************************************************************/

from game import Agent
from game import Actions
from game import Directions
import random
from util import manhattanDistance
import util


class GhostAgent(Agent):

    def __init__(self, index):
        """def __init__(self, index):
    ""\"
    Initializes the ghost agent with its index.

    This constructor sets the unique identifier for the ghost agent, 
    which is essential for distinguishing between multiple ghost agents 
    in the game.

    Parameters:
    index (int): The unique index of the ghost agent. This index is used 
                 to identify and manage the ghost within the game's state 
                 and behavior.

    Returns:
    None: This method does not return a value.

    Usage Example:
    >>> ghost_agent = GhostAgent(index=1)
    >>> print(ghost_agent.index)  # Output: 1
    """
        self.index = index

    def getAction(self, state):
        """def getAction(self, state):
    ""\"
    Returns the action that the ghost agent will take based on the current game state.

    The action is selected by retrieving a distribution of possible actions 
    and then choosing one action according to that distribution. If no legal 
    actions are available, the ghost will stop.

    Parameters:
    state (GameState): The current state of the game, which includes information 
                       about the positions of Pacman, ghosts, and other game elements.

    Returns:
    str: A string representing the action the ghost agent will take. This action 
         is one of the legal directions defined in the game (e.g., 'North', 
         'South', 'East', 'West', 'Stop').

    Usage Example:
    >>> ghost_agent = GhostAgent(index=1)
    >>> action = ghost_agent.getAction(current_game_state)
    >>> print(action)  # Output: 'West' (or another direction based on the state)
    """
        dist = self.getDistribution(state)
        if len(dist) == 0:
            return Directions.STOP
        else:
            return util.chooseFromDistribution(dist)

    def getDistribution(self, state):
        """Returns a Counter encoding a distribution over actions from the provided state."""
        util.raiseNotDefined()


class RandomGhost(GhostAgent):
    """A ghost that chooses a legal action uniformly at random."""

    def getDistribution(self, state):
        """def getDistribution(self, state):
    ""\"
    Returns a distribution over possible actions for the ghost agent based on the current game state.

    This method calculates the probabilities of taking each legal action based 
    on the ghost's behavior strategy. The distribution reflects the ghost's 
    intent to either chase or flee from Pacman, depending on whether the ghost 
    is scared or not.

    Parameters:
    state (GameState): The current state of the game, which includes the 
                       positions of Pacman, the ghost, and the legal actions 
                       available to the ghost.

    Returns:
    Counter: A Counter object that represents the distribution over actions, 
             where the keys are the legal actions and the values are the 
             corresponding probabilities of selecting each action.

    Usage Example:
    >>> ghost_agent = DirectionalGhost(index=1)
    >>> distribution = ghost_agent.getDistribution(current_game_state)
    >>> print(distribution)  # Output: Counter({'North': 0.4, 'South': 0.4, 'Stop': 0.2})
    """
        dist = util.Counter()
        for a in state.getLegalActions(self.index):
            dist[a] = 1.0
        dist.normalize()
        return dist


class DirectionalGhost(GhostAgent):
    """A ghost that prefers to rush Pacman, or flee when scared."""

    def __init__(self, index, prob_attack=0.8, prob_scaredFlee=0.8):
        """def __init__(self, index, prob_attack=0.8, prob_scaredFlee=0.8):
    ""\"
    Initializes the directional ghost agent with its index and behavior probabilities.

    This constructor sets the unique identifier for the ghost agent and 
    defines the probabilities for the ghost's actions when attacking or 
    fleeing. These probabilities influence the ghost's decision-making 
    process in pursuit of Pacman or when attempting to evade him.

    Parameters:
    index (int): The unique index of the ghost agent. This index is used 
                 to identify and manage the ghost within the game's state.

    prob_attack (float, optional): The probability of the ghost attacking 
                                    Pacman when unscared. Default is 0.8.

    prob_scaredFlee (float, optional): The probability of the ghost fleeing 
                                        from Pacman when scared. Default is 0.8.

    Returns:
    None: This method does not return a value.

    Usage Example:
    >>> directional_ghost = DirectionalGhost(index=1, prob_attack=0.9, prob_scaredFlee=0.7)
    >>> print(directional_ghost.index)  # Output: 1
    >>> print(directional_ghost.prob_attack)  # Output: 0.9
    >>> print(directional_ghost.prob_scaredFlee)  # Output: 0.7
    """
        self.index = index
        self.prob_attack = prob_attack
        self.prob_scaredFlee = prob_scaredFlee

    def getDistribution(self, state):
        """def getDistribution(self, state):
    ""\"
    Returns a distribution over possible actions for the directional ghost agent 
    based on the current game state.

    This method computes probabilities for each legal action the ghost can take 
    depending on its state (scared or not) and its proximity to Pacman. The 
    distribution reflects the ghost's tendency to either chase Pacman when it is 
    not scared or flee when it is scared.

    Parameters:
    state (GameState): The current state of the game, which includes the 
                       positions of Pacman, the ghost, and the legal actions 
                       available to the ghost.

    Returns:
    Counter: A Counter object that maps each legal action to a probability, 
             reflecting the likelihood of the ghost taking that action based on 
             its behavior strategy.

    Usage Example:
    >>> ghost_agent = DirectionalGhost(index=1)
    >>> distribution = ghost_agent.getDistribution(current_game_state)
    >>> print(distribution)  # Output: Counter({'North': 0.5, 'South': 0.3, 'Stop': 0.2})
    """
        ghostState = state.getGhostState(self.index)
        legalActions = state.getLegalActions(self.index)
        pos = state.getGhostPosition(self.index)
        isScared = ghostState.scaredTimer > 0
        speed = 1
        if isScared:
            speed = 0.5
        actionVectors = [Actions.directionToVector(a, speed) for a in
            legalActions]
        newPositions = [(pos[0] + a[0], pos[1] + a[1]) for a in actionVectors]
        pacmanPosition = state.getPacmanPosition()
        distancesToPacman = [manhattanDistance(pos, pacmanPosition) for pos in
            newPositions]
        if isScared:
            bestScore = max(distancesToPacman)
            bestProb = self.prob_scaredFlee
        else:
            bestScore = min(distancesToPacman)
            bestProb = self.prob_attack
        bestActions = [action for action, distance in zip(legalActions,
            distancesToPacman) if distance == bestScore]
        dist = util.Counter()
        for a in bestActions:
            dist[a] = bestProb / len(bestActions)
        for a in legalActions:
            dist[a] += (1 - bestProb) / len(legalActions)
        dist.normalize()
        return dist
