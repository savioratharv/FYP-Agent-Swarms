# # keyboardAgents.py Documentation
# 
# ## Overview
# This module contains implementations of keyboard agents for controlling the movements of characters within a game environment. The agents respond to keyboard inputs to navigate through the game in a manner defined by their respective movement keys. The functionality allows users to interact with the game in real-time using specified keys for movement and action.
# 
# ## Classes
# 
# ### KeyboardAgent
# The `KeyboardAgent` class is an agent controlled by keyboard inputs. It enables a player to maneuver a character within the game environment using specific keys for movement and a designated key for stopping.
# 
# #### Attributes
# - `lastMove`: A string representing the last move made by the agent. It defaults to `Directions.STOP`.
# - `index`: An integer that identifies the agent's index within the game. Default value is 0.
# - `keys`: A list that holds the current keys being pressed.
# 
# #### Methods
# - `__init__(self, index=0)`: Initializes the `KeyboardAgent` with an optional index parameter.
#   
# - `getAction(self, state)`: Retrieves the next action to be taken by the agent based on the current game state.
#   - **Parameters**: 
#     - `state`: The current state of the game.
#   - **Returns**: A string representing the agent's next move.
#   
# - `getMove(self, legal)`: Determines the movement direction based on currently pressed keys and legal actions available.
#   - **Parameters**: 
#     - `legal`: A list of legal actions that the agent can perform.
#   - **Returns**: A string indicating the direction of movement.
# 
# ### KeyboardAgent2
# The `KeyboardAgent2` class extends the functionality of `KeyboardAgent` and provides a second agent controlled by different keys. It allows for a second player to participate in the game using alternative keyboard inputs.
# 
# #### Attributes
# Inherits all attributes from `KeyboardAgent`. The specific keys for movement are redefined.
# 
# #### Methods
# - `getMove(self, legal)`: Determines the movement direction for the second agent based on currently pressed keys.
#   - **Parameters**: 
#     - `legal`: A list of legal actions available to the agent.
#   - **Returns**: A string indicating the direction of movement.
# 
# ## Key Constants
# - `WEST_KEY`, `EAST_KEY`, `NORTH_KEY`, `SOUTH_KEY`, `STOP_KEY`: Strings representing the keyboard keys designated for movement and stopping.
#   
# ## External Functions
# This module relies on several external functions for handling keyboard inputs:
# - `keys_waiting`: Retrieves and clears the list of keys that have been pressed but not yet processed.
#   
# - `keys_pressed`: Retrieves a list of keys that are currently pressed in the graphics window.
# 
# ## Usage
# This module is primarily designed for educational purposes within the context of game development and artificial intelligence. It allows users to utilize keyboard inputs to control agents in a simple game setting, specifically one modeled after classic arcade-style gameplay such as that found in Pacman.
# 
# ### Licensing Information
# Users are permitted to utilize or extend this module for educational objectives provided the following conditions are met:
# 1. Solutions are not distributed or published.
# 2. This notice is retained in any derivative works.
# 3. Clear attribution is given to UC Berkeley, including a link to http://ai.berkeley.edu.

from game import Agent
from game import Directions
import random


class KeyboardAgent(Agent):
    """
    An agent controlled by the keyboard.
    """
    WEST_KEY = 'a'
    EAST_KEY = 'd'
    NORTH_KEY = 'w'
    SOUTH_KEY = 's'
    STOP_KEY = 'q'

    def __init__(self, index=0):
        """
Initialize a KeyboardAgent instance with a specified index.

This constructor method sets the initial state of the KeyboardAgent, including 
the last move made by the agent, the agent's index, and the list of keys currently pressed.

Parameters:
    index (int, optional): An integer representing the index of the agent 
    within the game. The default value is 0.

Returns:
    None

Example:
    >>> agent = KeyboardAgent(index=1)
    >>> print(agent.index)  # Output: 1
    >>> print(agent.lastMove)  # Output: "STOP\"
"""
        self.lastMove = Directions.STOP
        self.index = index
        self.keys = []

    def getAction(self, state):
        """
Retrieve the next action to be taken by the agent based on the current game state.

This method checks for currently pressed keys and determines a legal move for the agent. 
If the stop key is pressed, the agent will stop; otherwise, it will attempt to move 
in the direction indicated by previous movements or a new direction based on the 
current key inputs.

Parameters:
    state (State): The current state of the game, which provides information 
    about the agent's position and available legal actions.

Returns:
    str: A string representing the agent's next move, which can be one of the 
    direction constants (e.g., "NORTH", "SOUTH", "EAST", "WEST", "STOP").

Example:
    >>> state = game.getCurrentState()  # Assuming this retrieves the current game state
    >>> action = agent.getAction(state)
    >>> print(action)  # Output could be "NORTH", "SOUTH", "EAST", "WEST", or "STOP\"
"""
        from graphicsUtils import keys_waiting
        from graphicsUtils import keys_pressed
        keys = list(keys_waiting()) + list(keys_pressed())
        if keys != []:
            self.keys = keys
        legal = state.getLegalActions(self.index)
        move = self.getMove(legal)
        if move == Directions.STOP:
            if self.lastMove in legal:
                move = self.lastMove
        if self.STOP_KEY in self.keys and Directions.STOP in legal:
            move = Directions.STOP
        if move not in legal:
            move = random.choice(legal)
        self.lastMove = move
        return move

    def getMove(self, legal):
        """
Determine the movement direction based on currently pressed keys and legal actions available.

This method evaluates the keys currently being pressed and checks them against the
list of legal moves for the agent. It returns the corresponding direction if a legal 
movement key is pressed; otherwise, it defaults to "STOP".

Parameters:
    legal (list of str): A list of legal actions that the agent can perform, 
    represented as direction constants (e.g., "NORTH", "SOUTH", "EAST", "WEST").

Returns:
    str: A string indicating the direction of movement, which can be one of the 
    direction constants (e.g., "NORTH", "SOUTH", "EAST", "WEST", "STOP").

Example:
    >>> legal_moves = [Directions.NORTH, Directions.SOUTH, Directions.WEST]
    >>> move = agent.getMove(legal_moves)
    >>> print(move)  # Output could be "NORTH", "SOUTH", "WEST", or "STOP" based on input.
"""
        move = Directions.STOP
        if (self.WEST_KEY in self.keys or 'Left' in self.keys
            ) and Directions.WEST in legal:
            move = Directions.WEST
        if (self.EAST_KEY in self.keys or 'Right' in self.keys
            ) and Directions.EAST in legal:
            move = Directions.EAST
        if (self.NORTH_KEY in self.keys or 'Up' in self.keys
            ) and Directions.NORTH in legal:
            move = Directions.NORTH
        if (self.SOUTH_KEY in self.keys or 'Down' in self.keys
            ) and Directions.SOUTH in legal:
            move = Directions.SOUTH
        return move


class KeyboardAgent2(KeyboardAgent):
    """
    A second agent controlled by the keyboard.
    """
    WEST_KEY = 'j'
    EAST_KEY = 'l'
    NORTH_KEY = 'i'
    SOUTH_KEY = 'k'
    STOP_KEY = 'u'

    def getMove(self, legal):
        """
Determine the movement direction based on currently pressed keys and available legal actions.

This method evaluates the current keys being pressed by the player and checks them 
against the list of legal moves for the agent. It returns the corresponding direction 
if a valid movement key is pressed; otherwise, it defaults to "STOP".

Parameters:
    legal (list of str): A list of legal actions that the agent can perform, 
    represented as direction constants (e.g., "NORTH", "SOUTH", "EAST", "WEST").

Returns:
    str: A string representing the direction of movement, which can be one of the 
    direction constants (e.g., "NORTH", "SOUTH", "EAST", "WEST", or "STOP").

Example:
    >>> legal_moves = [Directions.NORTH, Directions.EAST]
    >>> move = agent.getMove(legal_moves)
    >>> print(move)  # Output could be "NORTH" or "EAST" based on the pressed keys.
"""
        move = Directions.STOP
        if self.WEST_KEY in self.keys and Directions.WEST in legal:
            move = Directions.WEST
        if self.EAST_KEY in self.keys and Directions.EAST in legal:
            move = Directions.EAST
        if self.NORTH_KEY in self.keys and Directions.NORTH in legal:
            move = Directions.NORTH
        if self.SOUTH_KEY in self.keys and Directions.SOUTH in legal:
            move = Directions.SOUTH
        return move
