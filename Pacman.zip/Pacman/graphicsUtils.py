# # Pacman Graphics Utilities Documentation
# 
# ## Overview
# This module, `graphicsUtils.py`, provides a set of graphics utility functions designed for educational purposes, specifically within the context of the Pacman AI projects developed at UC Berkeley. It provides functionalities for creating a graphical user interface, handling user input, and drawing various shapes and images on a canvas.
# 
# ## Licensing
# You are free to use or extend this project for educational purposes under the following conditions:
# 1. Do not distribute or publish solutions.
# 2. Retain this notice.
# 3. Provide clear attribution to UC Berkeley, with a link to http://ai.berkeley.edu.
# 
# ## Attribution Information
# The Pacman AI projects were developed at UC Berkeley. The core projects and autograders were primarily created by John DeNero and Dan Klein. Student-side autograding was added by Brad Miller, Nick Hay, and Pieter Abbeel.
# 
# ## Functions
# 
# ### formatColor
# ```python
# def formatColor(r, g, b):
# ```
# Converts RGB values in the range [0, 1] to a hexadecimal color string.
# 
# **Parameters**
# - `r`: Red component (float).
# - `g`: Green component (float).
# - `b`: Blue component (float).
# 
# **Returns**
# - A string representing the color in hexadecimal format.
# 
# ### colorToVector
# ```python
# def colorToVector(color):
# ```
# Converts a hexadecimal color string to a normalized RGB vector.
# 
# **Parameters**
# - `color`: A string representing a color in hexadecimal format.
# 
# **Returns**
# - A list of floats representing the RGB components normalized to [0, 1].
# 
# ### sleep
# ```python
# def sleep(secs):
# ```
# Pauses execution for a specified number of seconds. If a graphical window is open, it uses the Tkinter event loop to wait.
# 
# **Parameters**
# - `secs`: Number of seconds to pause (float).
# 
# ### begin_graphics
# ```python
# def begin_graphics(width=640, height=480, color=formatColor(0, 0, 0), title=None):
# ```
# Initializes the graphics window and sets up the drawing canvas.
# 
# **Parameters**
# - `width`: Width of the canvas (integer).
# - `height`: Height of the canvas (integer).
# - `color`: Background color of the canvas (string).
# - `title`: Title of the window (string).
# 
# ### end_graphics
# ```python
# def end_graphics():
# ```
# Closes the graphics window and cleans up resources.
# 
# ### clear_screen
# ```python
# def clear_screen(background=None):
# ```
# Clears all drawn elements from the canvas and redraws the background.
# 
# **Parameters**
# - `background`: Optional background color (string).
# 
# ### polygon
# ```python
# def polygon(coords, outlineColor, fillColor=None, filled=1, smoothed=1, behind=0, width=1):
# ```
# Draws a polygon on the canvas.
# 
# **Parameters**
# - `coords`: List of coordinates for the polygon (list of tuples).
# - `outlineColor`: Color of the polygon's outline (string).
# - `fillColor`: Color to fill the polygon (string).
# - `filled`: Boolean indicating if the polygon should be filled.
# - `smoothed`: Boolean indicating if the polygon edges are smoothed.
# - `behind`: Layer indicator for drawing order.
# - `width`: Width of the polygon outline (integer).
# 
# **Returns**
# - An identifier for the drawn polygon.
# 
# ### square
# ```python
# def square(pos, r, color, filled=1, behind=0):
# ```
# Draws a square on the canvas.
# 
# **Parameters**
# - `pos`: Center position of the square (tuple).
# - `r`: Half the side length of the square (float).
# - `color`: Color of the square (string).
# - `filled`: Boolean indicating if the square should be filled.
# - `behind`: Layer indicator.
# 
# **Returns**
# - An identifier for the drawn square.
# 
# ### circle
# ```python
# def circle(pos, r, outlineColor, fillColor=None, endpoints=None, style='pieslice', width=2):
# ```
# Draws a circle or arc on the canvas.
# 
# **Parameters**
# - `pos`: Center position of the circle (tuple).
# - `r`: Radius of the circle (float).
# - `outlineColor`: Color of the outline (string).
# - `fillColor`: Color to fill the circle (string).
# - `endpoints`: Angles defining the arc (list).
# - `style`: Style of the arc (string).
# - `width`: Width of the outline (integer).
# 
# **Returns**
# - An identifier for the drawn circle.
# 
# ### image
# ```python
# def image(pos, file="../../blueghost.gif"):
# ```
# Draws an image on the canvas.
# 
# **Parameters**
# - `pos`: Position to draw the image (tuple).
# - `file`: Path to the image file (string).
# 
# **Returns**
# - An identifier for the drawn image.
# 
# ### text
# ```python
# def text(pos, color, contents, font='Helvetica', size=12, style='normal', anchor="nw"):
# ```
# Draws text on the canvas.
# 
# **Parameters**
# - `pos`: Position to draw the text (tuple).
# - `color`: Color of the text (string).
# - `contents`: The text content to draw (string).
# - `font`: Font type (string).
# - `size`: Font size (integer).
# - `style`: Font style (string).
# - `anchor`: Text anchor position (string).
# 
# **Returns**
# - An identifier for the drawn text.
# 
# ### move_to
# ```python
# def move_to(object, x, y=None, d_o_e=lambda arg: _root_window.dooneevent(arg), d_w=tkinter._tkinter.DONT_WAIT):
# ```
# Moves a graphical object to a new position.
# 
# **Parameters**
# - `object`: Identifier of the object.
# - `x`: New x-coordinate (float).
# - `y`: New y-coordinate (float, optional).
# - `d_o_e`: Function for managing events (callable).
# - `d_w`: Wait type (integer).
# 
# ### move_by
# ```python
# def move_by(object, x, y=None, d_o_e=lambda arg: _root_window.dooneevent(arg), d_w=tkinter._tkinter.DONT_WAIT, lift=False):
# ```
# Moves a graphical object by a specified offset.
# 
# **Parameters**
# - `object`: Identifier of the object.
# - `x`: Offset in the x-direction (float).
# - `y`: Offset in the y-direction (float, optional).
# - `d_o_e`: Function for managing events (callable).
# - `d_w`: Wait type (integer).
# - `lift`: Boolean indicating if the object should be lifted above others.
# 
# ### writePostscript
# ```python
# def writePostscript(filename):
# ```
# Writes the current canvas content to a PostScript file.
# 
# **Parameters**
# - `filename`: Name of the file to save the PostScript output (string).
# 
# ## Key Handling
# 
# ### keys_pressed
# ```python
# def keys_pressed(d_o_e=lambda arg: _root_window.dooneevent(arg), d_w=tkinter._tkinter.DONT_WAIT):
# ```
# Returns the currently pressed keys.
# 
# **Parameters**
# - `d_o_e`: Function for managing events (callable).
# - `d_w`: Wait type (integer).
# 
# **Returns**
# - A list of currently pressed key symbols.
# 
# ### wait_for_keys
# ```python
# def wait_for_keys():
# ```
# Blocks execution until at least one key is pressed. Returns the pressed keys.
# 
# **Returns**
# - A list of pressed key symbols.
# 
# ### remove_from_screen
# ```python
# def remove_from_screen(x, d_o_e=lambda arg: _root_window.dooneevent(arg), d_w=tkinter._tkinter.DONT_WAIT):
# ```
# Removes a graphical object from the canvas.
# 
# **Parameters**
# - `x`: Identifier of the object to remove.
# - `d_o_e`: Function for managing events (callable).
# - `d_w`: Wait type (integer).
# 
# ## Miscellaneous
# 
# ### draw_background
# ```python
# def draw_background():
# ```
# Draws the background of the canvas based on the chosen background color.
# 
# ### refresh
# ```python
# def refresh():
# ```
# Updates the canvas to reflect any changes made.
# 
# ## Main Execution Block
# If the script is run as a standalone program, it initializes the graphics system, creates a ghost shape using the `polygon` function, draws a circle, and pauses for two seconds before exiting.
# 
# ### Example Usage
# ```python
# if __name__ == '__main__':
#     begin_graphics()
#     clear_screen()
#     ghost_shape = [(x * 10 + 20, y * 10 + 20) for x, y in ghost_shape]
#     g = polygon(ghost_shape, formatColor(1, 1, 1))
#     move_to(g, (50, 50))
#     circle((150, 150), 20, formatColor(0.7, 0.3, 0.0), endpoints=[15, -15])
#     sleep(2)
# ```
# 
# This example demonstrates initializing graphics, clearing the screen, drawing a ghost shape and a circle, and pausing before terminating the program.
# 
# ## Conclusion
# The `graphicsUtils.py` module simplifies the process of creating and managing a graphical interface in Python for educational purposes. It provides essential functions for drawing shapes, handling user input, and integrating graphical elements smoothly.

import sys
import math
import random
import string
import time
import types
import tkinter
import os.path
_Windows = sys.platform == 'win32'
_root_window = None
_canvas = None
_canvas_xs = None
_canvas_ys = None
_canvas_x = None
_canvas_y = None
_canvas_col = None
_canvas_tsize = 12
_canvas_tserifs = 0


def formatColor(r, g, b):
    """
Convert RGB color values in the range [0, 1] to a hexadecimal color string.

This function takes the red, green, and blue components, scales them to the 
range [0, 255], and formats them as a hexadecimal string, which is commonly 
used for specifying colors in web design and graphics.

Parameters:
    r (float): The red component of the color, a value between 0 and 1.
    g (float): The green component of the color, a value between 0 and 1.
    b (float): The blue component of the color, a value between 0 and 1.

Returns:
    str: A string representing the color in hexadecimal format, starting with '#'.

Example:
    >>> hex_color = formatColor(0.5, 0.75, 0.2)
    >>> print(hex_color)
    '#7fbf33'
"""
    return '#%02x%02x%02x' % (int(r * 255), int(g * 255), int(b * 255))


def colorToVector(color):
    """
Convert a hexadecimal color string to a normalized RGB vector.

This function takes a color specified in hexadecimal format (e.g., '#RRGGBB')
and converts the individual red, green, and blue components into a list of 
floating-point numbers, normalized to the range [0, 1].

Parameters:
    color (str): A string representing a color in hexadecimal format, starting 
    with a '#' followed by six hexadecimal digits.

Returns:
    list of float: A list containing the normalized RGB components, where each 
    component is in the range [0, 1].

Example:
    >>> rgb_vector = colorToVector('#7fbf33')
    >>> print(rgb_vector)
    [0.4980392156862745, 0.7529411764705882, 0.2]
"""
    return list(map(lambda x: int(x, 16) / 256.0, [color[1:3], color[3:5],
        color[5:7]]))


if _Windows:
    _canvas_tfonts = ['times new roman', 'lucida console']
else:
    _canvas_tfonts = ['times', 'lucidasans-24']
    pass


def sleep(secs):
    """
Pause execution for a specified number of seconds.

This function suspends the program execution for the given amount of time. 
If a graphical window is open, it uses the Tkinter event loop to ensure that 
the window remains responsive during the sleep period.

Parameters:
    secs (float): The number of seconds to pause execution. This can be a 
    fractional value for more precise sleep durations.

Returns:
    None

Example:
    >>> print("Starting sleep...")
    >>> sleep(2)
    >>> print("Finished sleeping after 2 seconds.")
"""
    global _root_window
    if _root_window == None:
        time.sleep(secs)
    else:
        _root_window.update_idletasks()
        _root_window.after(int(1000 * secs), _root_window.quit)
        _root_window.mainloop()


def begin_graphics(width=640, height=480, color=formatColor(0, 0, 0), title
    =None):
    """
Initialize the graphics window and set up the drawing canvas.

This function creates a new window for graphic output, establishes the canvas size, 
background color, and configures user interaction bindings. If the graphics window 
is already open, it will be closed and replaced with the new one.

Parameters:
    width (int, optional): The width of the canvas in pixels. Default is 640.
    height (int, optional): The height of the canvas in pixels. Default is 480.
    color (str, optional): The background color of the canvas in hexadecimal format 
    (e.g., '#RRGGBB'). Default is black ('#000000').
    title (str, optional): The title of the graphics window. If not provided, 
    defaults to 'Graphics Window'.

Returns:
    None

Example:
    >>> begin_graphics(800, 600, '#FFFFFF', 'My Graphics Window')
    >>> clear_screen()  # Clear the screen after initializing
"""
    global _root_window, _canvas, _canvas_x, _canvas_y, _canvas_xs, _canvas_ys, _bg_color
    if _root_window is not None:
        _root_window.destroy()
    _canvas_xs, _canvas_ys = width - 1, height - 1
    _canvas_x, _canvas_y = 0, _canvas_ys
    _bg_color = color
    _root_window = tkinter.Tk()
    _root_window.protocol('WM_DELETE_WINDOW', _destroy_window)
    _root_window.title(title or 'Graphics Window')
    _root_window.resizable(0, 0)
    try:
        _canvas = tkinter.Canvas(_root_window, width=width, height=height)
        _canvas.pack()
        draw_background()
        _canvas.update()
    except:
        _root_window = None
        raise
    _root_window.bind('<KeyPress>', _keypress)
    _root_window.bind('<KeyRelease>', _keyrelease)
    _root_window.bind('<FocusIn>', _clear_keys)
    _root_window.bind('<FocusOut>', _clear_keys)
    _root_window.bind('<Button-1>', _leftclick)
    _root_window.bind('<Button-2>', _rightclick)
    _root_window.bind('<Button-3>', _rightclick)
    _root_window.bind('<Control-Button-1>', _ctrl_leftclick)
    _clear_keys()


_leftclick_loc = None
_rightclick_loc = None
_ctrl_leftclick_loc = None


def _leftclick(event):
    """
Handle the left mouse button click event.

This function is called when a left mouse button click occurs within the graphics 
window. It records the coordinates of the click for later use.

Parameters:
    event (tkinter.Event): The event object containing information about the mouse 
    click, including the x and y coordinates.

Returns:
    None

Example:
    >>> # This function is typically used internally and not called directly.
    >>> # When a left click occurs, it captures the position in the global variable.
"""
    global _leftclick_loc
    _leftclick_loc = event.x, event.y


def _rightclick(event):
    """
Handle the right mouse button click event.

This function is invoked when a right mouse button click occurs within the graphics 
window. It records the coordinates of the click for subsequent processing.

Parameters:
    event (tkinter.Event): The event object containing information about the mouse 
    click, including the x and y coordinates.

Returns:
    None

Example:
    >>> # This function is typically used internally and not called directly.
    >>> # Upon a right click in the graphics window, it captures the position in a 
    >>> global variable for further use.
"""
    global _rightclick_loc
    _rightclick_loc = event.x, event.y


def _ctrl_leftclick(event):
    """
Handle the control-modified left mouse button click event.

This function is triggered when a left mouse button click occurs while the 
Control key is pressed within the graphics window. It records the coordinates 
of the click for later processing.

Parameters:
    event (tkinter.Event): The event object containing information about the mouse 
    click, including the x and y coordinates.

Returns:
    None

Example:
    >>> # This function is typically used internally and not called directly.
    >>> # When a control-modified left click happens, it saves the position in a 
    >>> global variable for further handling.
"""
    global _ctrl_leftclick_loc
    _ctrl_leftclick_loc = event.x, event.y


def wait_for_click():
    """
Wait for a mouse button click in the graphics window.

This function continually checks for mouse button clicks and returns the 
coordinates of the first left, right, or control-modified left click detected, 
along with the type of click.

Returns:
    tuple: A tuple containing the coordinates of the mouse click (x, y) and 
    a string indicating the type of click ('left', 'right', or 'ctrl_left').

Example:
    >>> coordinates, click_type = wait_for_click()
    >>> print(f"Mouse clicked at {coordinates} with a {click_type} click.")
"""
    while True:
        global _leftclick_loc
        global _rightclick_loc
        global _ctrl_leftclick_loc
        if _leftclick_loc != None:
            val = _leftclick_loc
            _leftclick_loc = None
            return val, 'left'
        if _rightclick_loc != None:
            val = _rightclick_loc
            _rightclick_loc = None
            return val, 'right'
        if _ctrl_leftclick_loc != None:
            val = _ctrl_leftclick_loc
            _ctrl_leftclick_loc = None
            return val, 'ctrl_left'
        sleep(0.05)


def draw_background():
    """
Draw the background of the graphics canvas.

This function fills the canvas with the specified background color by drawing 
a polygon that covers the entire canvas area. It is called during initialization 
of the graphics window and when clearing the screen.

Parameters:
    None

Returns:
    None

Example:
    >>> # Typically called internally when setting up the graphics environment.
    >>> draw_background()  # Fills the canvas with the background color.
"""
    corners = [(0, 0), (0, _canvas_ys), (_canvas_xs, _canvas_ys), (
        _canvas_xs, 0)]
    polygon(corners, _bg_color, fillColor=_bg_color, filled=True, smoothed=
        False)


def _destroy_window(event=None):
    """
Terminate the graphics program and close the window.

This function is invoked when the graphics window is closed by the user. 
It handles the cleanup process by exiting the program gracefully.

Parameters:
    event (tkinter.Event, optional): The event object associated with the 
    window close action. This parameter is optional and may not be used.

Returns:
    None

Example:
    >>> # This function is typically bound to the window close event and is 
    >>> # not called directly by the user.
    >>> _destroy_window()  # Closes the graphics window and exits the program.
"""
    sys.exit(0)


def end_graphics():
    """
Close the graphics window and clean up resources.

This function is responsible for terminating the graphics context, closing 
the window, and resetting any internal state related to the graphics module. 
It ensures that all resources are released properly when finishing the graphics session.

Parameters:
    None

Returns:
    None

Example:
    >>> end_graphics()  # Closes the graphics window and resets the graphics module.
"""
    global _root_window, _canvas, _mouse_enabled
    try:
        try:
            sleep(1)
            if _root_window != None:
                _root_window.destroy()
        except SystemExit as e:
            print('Ending graphics raised an exception:', e)
    finally:
        _root_window = None
        _canvas = None
        _mouse_enabled = 0
        _clear_keys()


def clear_screen(background=None):
    """
Clear all drawn elements from the graphics canvas and redraw the background.

This function removes all existing shapes, text, and images from the canvas 
and repaints the background, effectively resetting the canvas to its initial state.

Parameters:
    background (str, optional): An optional background color in hexadecimal format 
    (e.g., '#RRGGBB'). If provided, this color will be used to repaint the background.

Returns:
    None

Example:
    >>> clear_screen()  # Clears the canvas and resets it to the default background color.
    >>> clear_screen('#FF0000')  # Clears the canvas and sets the background to red.
"""
    global _canvas_x, _canvas_y
    _canvas.delete('all')
    draw_background()
    _canvas_x, _canvas_y = 0, _canvas_ys


def polygon(coords, outlineColor, fillColor=None, filled=1, smoothed=1,
    behind=0, width=1):
    """
Draw a polygon on the graphics canvas.

This function creates a polygon defined by a list of coordinates and allows 
customization of its appearance, including outline color, fill color, 
and whether it is filled or smoothed.

Parameters:
    coords (list of tuple): A list of (x, y) tuples representing the vertices 
    of the polygon.
    outlineColor (str): The color of the polygon's outline in hexadecimal format 
    (e.g., '#RRGGBB').
    fillColor (str, optional): The color to fill the polygon in hexadecimal format. 
    If not provided, defaults to the outline color.
    filled (int, optional): A flag indicating whether the polygon should be filled. 
    Defaults to 1 (filled).
    smoothed (int, optional): A flag indicating whether the edges of the polygon 
    should be smoothed. Defaults to 1 (smoothed).
    behind (int, optional): A layer indicator for drawing order. Higher values 
    correspond to being more visible. Defaults to 0 (drawn in front).
    width (int, optional): The width of the polygon's outline. Defaults to 1.

Returns:
    int: An identifier for the drawn polygon, which can be used for further manipulation.

Example:
    >>> polygon([(50, 50), (150, 50), (100, 100)], '#FF0000', fillColor='#00FF00', filled=1)
    >>> # This creates a filled green triangle with a red outline on the canvas.
"""
    c = []
    for coord in coords:
        c.append(coord[0])
        c.append(coord[1])
    if fillColor == None:
        fillColor = outlineColor
    if filled == 0:
        fillColor = ''
    poly = _canvas.create_polygon(c, outline=outlineColor, fill=fillColor,
        smooth=smoothed, width=width)
    if behind > 0:
        _canvas.tag_lower(poly, behind)
    return poly


def square(pos, r, color, filled=1, behind=0):
    """
Draw a square on the graphics canvas.

This function creates a square centered at a specified position, allowing 
for customization of its size, color, and whether it is filled.

Parameters:
    pos (tuple): A tuple (x, y) representing the center position of the square.
    r (float): Half the side length of the square.
    color (str): The color of the square in hexadecimal format (e.g., '#RRGGBB').
    filled (int, optional): A flag indicating whether the square should be filled. 
    Defaults to 1 (filled).
    behind (int, optional): A layer indicator for drawing order. Higher values 
    correspond to being more visible. Defaults to 0 (drawn in front).

Returns:
    int: An identifier for the drawn square, which can be used for further manipulation.

Example:
    >>> square((100, 100), 50, '#FF0000', filled=1)
    >>> # This creates a filled red square centered at (100, 100) with a side length of 100.
"""
    x, y = pos
    coords = [(x - r, y - r), (x + r, y - r), (x + r, y + r), (x - r, y + r)]
    return polygon(coords, color, color, filled, 0, behind=behind)


def circle(pos, r, outlineColor, fillColor=None, endpoints=None, style=
    'pieslice', width=2):
    """
Draw a circle or arc on the graphics canvas.

This function creates a circle or an arc centered at a specified position, 
allowing for customization of its radius, outline color, fill color, and style.

Parameters:
    pos (tuple): A tuple (x, y) representing the center position of the circle.
    r (float): The radius of the circle.
    outlineColor (str): The color of the circle's outline in hexadecimal format 
    (e.g., '#RRGGBB').
    fillColor (str, optional): The color to fill the circle in hexadecimal format. 
    If not provided, it defaults to the outline color.
    endpoints (list, optional): A list containing the start and end angles of the 
    arc in degrees. If not provided, the entire circle is drawn.
    style (str, optional): The style of the arc, which can be 'pieslice', 'arc', 
    or 'chord'. Defaults to 'pieslice'.
    width (int, optional): The width of the outline. Defaults to 2.

Returns:
    int: An identifier for the drawn circle or arc, which can be used for further manipulation.

Example:
    >>> circle((100, 100), 50, '#00FF00', fillColor='#0000FF', endpoints=[0, 180])
    >>> # This creates a filled blue semicircle centered at (100, 100) with a green outline.
"""
    x, y = pos
    x0, x1 = x - r - 1, x + r
    y0, y1 = y - r - 1, y + r
    if endpoints == None:
        e = [0, 359]
    else:
        e = list(endpoints)
    while e[0] > e[1]:
        e[1] = e[1] + 360
    return _canvas.create_arc(x0, y0, x1, y1, outline=outlineColor, fill=
        fillColor or outlineColor, extent=e[1] - e[0], start=e[0], style=
        style, width=width)


def image(pos, file='../../blueghost.gif'):
    """
Draw an image on the graphics canvas.

This function displays an image at a specified position within the graphics window. 
The image is loaded from a file and can be used for various graphical representations.

Parameters:
    pos (tuple): A tuple (x, y) representing the position where the image will be drawn.
    file (str, optional): The path to the image file (in GIF format) to be displayed. 
    Default is '../../blueghost.gif'.

Returns:
    int: An identifier for the drawn image, which can be used for further manipulation.

Example:
    >>> image((150, 150), '../../path/to/image.gif')
    >>> # This displays the specified image centered at the coordinates (150, 150) 
    >>> # within the graphics window.
"""
    x, y = pos
    return _canvas.create_image(x, y, image=tkinter.PhotoImage(file=file),
        anchor=tkinter.NW)


def refresh():
    """
Update the graphics canvas to reflect any changes made.

This function refreshes the canvas by updating any displays and ensuring that 
all drawn elements are rendered correctly. It is useful for redrawing or 
updating the graphics in real-time without closing the window.

Parameters:
    None

Returns:
    None

Example:
    >>> refresh()  # This call refreshes the canvas to ensure all graphics are updated.
"""
    _canvas.update_idletasks()


def moveCircle(id, pos, r, endpoints=None):
    """
Move a circular object on the graphics canvas.

This function updates the position and dimensions of a circular object defined by 
its identifier on the canvas. It allows for movement and resizing of the circle 
while optionally updating the arc's extent if defined.

Parameters:
    id (int): The identifier of the circular object on the canvas that needs to be moved.
    pos (tuple): A tuple (x, y) representing the new center position of the circle.
    r (float): The radius of the circle.
    endpoints (list, optional): A list containing the start and end angles of the arc 
    in degrees. If not provided, the entire circle will be used.

Returns:
    None

Example:
    >>> moveCircle(circle_id, (200, 200), 50)  # Moves the circle identified by `circle_id` to (200, 200) with a radius of 50.
"""
    global _canvas_x, _canvas_y
    x, y = pos
    x0, x1 = x - r - 1, x + r
    y0, y1 = y - r - 1, y + r
    if endpoints == None:
        e = [0, 359]
    else:
        e = list(endpoints)
    while e[0] > e[1]:
        e[1] = e[1] + 360
    if os.path.isfile('flag'):
        edit(id, ('extent', e[1] - e[0]))
    else:
        edit(id, ('start', e[0]), ('extent', e[1] - e[0]))
    move_to(id, x0, y0)


def edit(id, *args):
    """
Modify the properties of a graphical object on the canvas.

This function allows for the editing of various attributes of a graphical object 
(using its identifier), including colors, dimensions, and other characteristics.

Parameters:
    id (int): The identifier of the graphical object to be modified.
    *args: A variable length argument list that specifies the properties to edit. 
    Each property should be provided as a key-value pair (e.g., ('property_name', value)).

Returns:
    None

Example:
    >>> edit(object_id, ('fill', '#FF0000'), ('outline', '#0000FF'))  
    >>> # This modifies the object identified by `object_id` to have a red fill 
    >>> # and a blue outline.
"""
    _canvas.itemconfigure(id, **dict(args))


def text(pos, color, contents, font='Helvetica', size=12, style='normal',
    anchor='nw'):
    """
Draw text on the graphics canvas.

This function allows you to place text at a specified position on the canvas with 
customizable font, size, style, and color.

Parameters:
    pos (tuple): A tuple (x, y) representing the position where the text will be drawn.
    color (str): The color of the text in hexadecimal format (e.g., '#RRGGBB').
    contents (str): The string content to be displayed as text.
    font (str, optional): The font type to be used for the text. Defaults to 'Helvetica'.
    size (int, optional): The font size for the text. Defaults to 12.
    style (str, optional): The font style (e.g., 'normal', 'bold', 'italic'). Defaults to 'normal'.
    anchor (str, optional): The anchor position for the text. Defaults to 'nw' (northwest).

Returns:
    int: An identifier for the drawn text, which can be used for further manipulation.

Example:
    >>> text_identifier = text((100, 100), '#000000', 'Hello, World!', font='Arial', size=14)
    >>> # This draws the text "Hello, World!" at position (100, 100) in black using Arial font.
"""
    global _canvas_x, _canvas_y
    x, y = pos
    font = font, str(size), style
    return _canvas.create_text(x, y, fill=color, text=contents, font=font,
        anchor=anchor)


def changeText(id, newText, font=None, size=12, style='normal'):
    """
Change the content or style of an existing text object on the canvas.

This function updates the text of a graphical object identified by its ID. It allows 
for modification of the displayed text as well as its font attributes.

Parameters:
    id (int): The identifier of the text object to be modified.
    newText (str): The new text content to display.
    font (str, optional): The new font type for the text. If provided, will replace 
    the current font.
    size (int, optional): The new font size for the text. If provided, will replace 
    the current size. Defaults to 12 if not provided.
    style (str, optional): The new font style (e.g., 'normal', 'bold', 'italic'). 
    If provided, will replace the current style.

Returns:
    None

Example:
    >>> changeText(text_id, 'New Text Content', font='Courier', size=16, style='bold')
    >>> # This updates the existing text object identified by `text_id` to display 
    >>> # 'New Text Content' in the Courier font, size 16, and bold style.
"""
    _canvas.itemconfigure(id, text=newText)
    if font != None:
        _canvas.itemconfigure(id, font=(font, '-%d' % size, style))


def changeColor(id, newColor):
    """
Change the color of an existing graphical object on the canvas.

This function updates the fill color of a graphical object identified by its ID. 
It allows for the modification of color attributes for various types of objects, 
including shapes and text.

Parameters:
    id (int): The identifier of the graphical object whose color is to be changed.
    newColor (str): The new color for the object in hexadecimal format (e.g., '#RRGGBB').

Returns:
    None

Example:
    >>> changeColor(shape_id, '#FF5733')
    >>> # This changes the fill color of the object identified by `shape_id` to a 
    >>> # bright reddish-orange.
"""
    _canvas.itemconfigure(id, fill=newColor)


def line(here, there, color=formatColor(0, 0, 0), width=2):
    """
Draw a line between two points on the graphics canvas.

This function creates a straight line connecting two specified coordinates and allows 
for customization of its color and width.

Parameters:
    here (tuple): A tuple (x0, y0) representing the starting point of the line.
    there (tuple): A tuple (x1, y1) representing the ending point of the line.
    color (str, optional): The color of the line in hexadecimal format (e.g., '#RRGGBB'). 
    Defaults to black ('#000000').
    width (int, optional): The width of the line. Defaults to 2.

Returns:
    int: An identifier for the drawn line, which can be used for further manipulation.

Example:
    >>> line_id = line((50, 50), (150, 150), color='#00FF00', width=3)
    >>> # This creates a green line from coordinates (50, 50) to (150, 150) with a width of 3.
"""
    x0, y0 = here[0], here[1]
    x1, y1 = there[0], there[1]
    return _canvas.create_line(x0, y0, x1, y1, fill=color, width=width)


_keysdown = {}
_keyswaiting = {}
_got_release = None


def _keypress(event):
    """
Handle the keypress event in the graphics window.

This function is invoked when a key is pressed while the graphics window is focused. 
It records the pressed key for later processing, allowing for user input handling.

Parameters:
    event (tkinter.Event): The event object containing information about the key 
    press, including the key symbol and character.

Returns:
    None

Example:
    >>> # This function is typically bound to the key press event and not called 
    >>> # directly by the user.
    >>> # It automatically records the key pressed by the user in the internal state.
"""
    global _got_release
    _keysdown[event.keysym] = 1
    _keyswaiting[event.keysym] = 1
    _got_release = None


def _keyrelease(event):
    """
Handle the key release event in the graphics window.

This function is invoked when a key is released while the graphics window is focused. 
It records the release of the key to manage state changes related to key inputs.

Parameters:
    event (tkinter.Event): The event object containing information about the key 
    release, including the key symbol.

Returns:
    None

Example:
    >>> # This function is typically bound to the key release event and not called 
    >>> # directly by the user.
    >>> # It automatically updates the internal state to reflect which keys are no longer pressed.
"""
    global _got_release
    try:
        del _keysdown[event.keysym]
    except:
        pass
    _got_release = 1


def remap_arrows(event):
    """
Remap arrow key presses to corresponding character inputs.

This function transforms the input from arrow key presses into character inputs 
('w', 'a', 's', 'd') to facilitate character movement controls in a more intuitive 
fashion. It modifies the event object directly to change the character representation 
of the key pressed.

Parameters:
    event (tkinter.Event): The event object containing information about the key 
    press, including the key code.

Returns:
    None

Example:
    >>> # This function is typically called internally during key press handling.
    >>> # It automatically remaps arrow key events to corresponding character movements.
"""
    if event.char in ['a', 's', 'd', 'w']:
        return
    if event.keycode in [37, 101]:
        event.char = 'a'
    if event.keycode in [38, 99]:
        event.char = 'w'
    if event.keycode in [39, 102]:
        event.char = 'd'
    if event.keycode in [40, 104]:
        event.char = 's'


def _clear_keys(event=None):
    """
Clear the state of pressed keys in the graphics input handling.

This function resets the internal dictionaries that track currently pressed keys and 
the waiting keys. It ensures that there are no lingering states from previous key 
presses, providing a clean slate for new input.

Parameters:
    event (tkinter.Event, optional): The event object associated with the call. 
    This parameter is optional and may not be used.

Returns:
    None

Example:
    >>> _clear_keys()  # This call clears the current key states, preparing for new input.
"""
    global _keysdown, _got_release, _keyswaiting
    _keysdown = {}
    _keyswaiting = {}
    _got_release = None


def keys_pressed(d_o_e=lambda arg: _root_window.dooneevent(arg), d_w=
    tkinter._tkinter.DONT_WAIT):
    """
Retrieve the currently pressed keys in the graphics window.

This function checks for keys that are currently pressed down and returns their 
symbols. It can also handle event processing during the check to ensure that 
the graphics window remains responsive.

Parameters:
    d_o_e (callable, optional): A function for managing event handling (default is 
    a lambda function for `dooneevent`).
    d_w (int, optional): The wait type for event handling, where the default is 
    `tkinter._tkinter.DONT_WAIT`.

Returns:
    list: A list of keys that are currently pressed in the graphics window.

Example:
    >>> pressed_keys = keys_pressed()
    >>> print(pressed_keys)  # This prints the list of currently pressed keys, 
    >>>                      # which could include keys like ['w', 'a', 's', 'd'].
"""
    d_o_e(d_w)
    if _got_release:
        d_o_e(d_w)
    return _keysdown.keys()


def keys_waiting():
    """
Retrieve and clear the list of keys that have been pressed but not yet processed.

This function checks for keys that have been pressed and recorded while waiting 
to be handled. It retrieves this list and clears the internal state, ensuring 
that previously recorded key presses do not affect future input handling.

Parameters:
    None

Returns:
    list: A list of keys that were pressed and are waiting to be processed.

Example:
    >>> waiting_keys = keys_waiting()
    >>> print(waiting_keys)  # This prints the list of keys that have been pressed
    >>>                   # and are waiting to be processed, such as ['Shift', 'Control'].
"""
    global _keyswaiting
    keys = _keyswaiting.keys()
    _keyswaiting = {}
    return keys


def wait_for_keys():
    """
Block execution until at least one key is pressed.

This function continuously checks for key presses and waits until one or more keys 
are detected. It can be useful for controlling flow in interactive applications where 
user input is required before proceeding.

Parameters:
    None

Returns:
    list: A list of keys that were pressed when the function returns.

Example:
    >>> pressed_keys = wait_for_keys()
    >>> print(f"Pressed keys: {pressed_keys}")  # This prints the keys that were pressed during the wait.
"""
    keys = []
    while keys == []:
        keys = keys_pressed()
        sleep(0.05)
    return keys


def remove_from_screen(x, d_o_e=lambda arg: _root_window.dooneevent(arg),
    d_w=tkinter._tkinter.DONT_WAIT):
    """
Remove a graphical object from the canvas.

This function deletes a specified graphical object from the canvas, effectively 
removing it from view. It allows for dynamic updates to the graphics displayed 
in the window.

Parameters:
    x (int): The identifier of the graphical object to be removed from the canvas.
    d_o_e (callable, optional): A function for managing event handling (default is 
    a lambda function for `dooneevent`).
    d_w (int, optional): The wait type for event handling, where the default is 
    `tkinter._tkinter.DONT_WAIT`.

Returns:
    None

Example:
    >>> remove_from_screen(object_id)  # This removes the object identified by `object_id` from the canvas.
"""
    _canvas.delete(x)
    d_o_e(d_w)


def _adjust_coords(coord_list, x, y):
    """
Adjust the coordinates of a list of points by specified offsets.

This function modifies the given list of coordinates by adding specified 
offsets in the x and y directions. It is useful for repositioning graphical objects 
on the canvas based on user input or movement.

Parameters:
    coord_list (list of float): A list of coordinates to be adjusted, where 
    each coordinate is represented as a float value.
    x (float): The offset value to be added to the x-coordinates.
    y (float, optional): The offset value to be added to the y-coordinates. 
    Defaults to 0 if not provided.

Returns:
    list of float: The adjusted list of coordinates after applying the offsets.

Example:
    >>> adjusted_coords = _adjust_coords([10.0, 20.0, 30.0, 40.0], 5.0, 10.0)
    >>> print(adjusted_coords)  # This results in [15.0, 30.0, 35.0, 50.0], 
    >>>                       # adjusting each x and y coordinate by the specified offsets.
"""
    for i in range(0, len(coord_list), 2):
        coord_list[i] = coord_list[i] + x
        coord_list[i + 1] = coord_list[i + 1] + y
    return coord_list


def move_to(object, x, y=None, d_o_e=lambda arg: _root_window.dooneevent(
    arg), d_w=tkinter._tkinter.DONT_WAIT):
    """
Move a graphical object to a specified position on the canvas.

This function repositions a graphical object by updating its coordinates to a 
new location. It handles both single-point moves and standard x-y coordinate 
format.

Parameters:
    object (int): The identifier of the graphical object to be moved.
    x (float or tuple): The new x-coordinate to move the object to, or a tuple 
    containing both x and y coordinates if y is not provided.
    y (float, optional): The new y-coordinate to move the object to. If not 
    provided, x should be a tuple containing both the x and y coordinates.

    d_o_e (callable, optional): A function for managing event handling (default is 
    a lambda function for `dooneevent`).
    d_w (int, optional): The wait type for event handling, where the default is 
    `tkinter._tkinter.DONT_WAIT`.

Returns:
    None

Example:
    >>> move_to(object_id, 100, 200)  # This moves the object with ID `object_id` to position (100, 200).
    >>> move_to(other_object_id, (150, 250))  # This moves the object with ID `other_object_id` to (150, 250).
"""
    if y is None:
        try:
            x, y = x
        except:
            raise 'incomprehensible coordinates'
    horiz = True
    newCoords = []
    current_x, current_y = _canvas.coords(object)[0:2]
    for coord in _canvas.coords(object):
        if horiz:
            inc = x - current_x
        else:
            inc = y - current_y
        horiz = not horiz
        newCoords.append(coord + inc)
    _canvas.coords(object, *newCoords)
    d_o_e(d_w)


def move_by(object, x, y=None, d_o_e=lambda arg: _root_window.dooneevent(
    arg), d_w=tkinter._tkinter.DONT_WAIT, lift=False):
    """
Move a graphical object by specified offsets on the canvas.

This function updates the position of a graphical object by adding specified 
offset values to its current coordinates. It allows for relative movement, which 
can be useful for animations or user interactions.

Parameters:
    object (int): The identifier of the graphical object to be moved.
    x (float): The offset to be added to the object's x-coordinate.
    y (float, optional): The offset to be added to the object's y-coordinate. 
    If not provided, x should be interpreted as a tuple containing both offsets.

    d_o_e (callable, optional): A function for managing event handling (default is 
    a lambda function for `dooneevent`).
    d_w (int, optional): The wait type for event handling, where the default is 
    `tkinter._tkinter.DONT_WAIT`.
    lift (bool, optional): A flag indicating whether to raise the object to the 
    front of other objects after moving it. Defaults to False.

Returns:
    None

Example:
    >>> move_by(object_id, 10, 15)  # This moves the object with ID `object_id` 
    >>>                          # by 10 units to the right and 15 units down.
    >>> move_by(another_object_id, (5, -5), lift=True)  # Moves `another_object_id` 
    >>>                                                  # 5 units to the right and 5 units up, raising it to the front.
"""
    if y is None:
        try:
            x, y = x
        except:
            raise Exception('incomprehensible coordinates')
    horiz = True
    newCoords = []
    for coord in _canvas.coords(object):
        if horiz:
            inc = x
        else:
            inc = y
        horiz = not horiz
        newCoords.append(coord + inc)
    _canvas.coords(object, *newCoords)
    d_o_e(d_w)
    if lift:
        _canvas.tag_raise(object)


def writePostscript(filename):
    """Writes the current canvas to a postscript file."""
    psfile = open(filename, 'w')
    psfile.write(_canvas.postscript(pageanchor='sw', y='0.c', x='0.c'))
    psfile.close()


ghost_shape = [(0, -0.5), (0.25, -0.75), (0.5, -0.5), (0.75, -0.75), (0.75,
    0.5), (0.5, 0.75), (-0.5, 0.75), (-0.75, 0.5), (-0.75, -0.75), (-0.5, -
    0.5), (-0.25, -0.75)]
if __name__ == '__main__':
    begin_graphics()
    clear_screen()
    ghost_shape = [(x * 10 + 20, y * 10 + 20) for x, y in ghost_shape]
    g = polygon(ghost_shape, formatColor(1, 1, 1))
    move_to(g, (50, 50))
    circle((150, 150), 20, formatColor(0.7, 0.3, 0.0), endpoints=[15, -15])
    sleep(2)
