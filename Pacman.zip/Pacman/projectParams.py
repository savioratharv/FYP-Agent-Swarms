# """
# projectParams.py
# 
# Description:
# This Python file contains constant definitions and configuration parameters associated with the
# Pacman AI projects developed at the University of California, Berkeley. It includes 
# licensing information and attribution guidelines that specify the conditions under which 
# the code can be used and modified.
# 
# Licensing Information:
# The code contained within this file is free to use and extend for educational purposes, 
# provided that the following conditions are met:
# 1. The solutions are not distributed or published.
# 2. This licensing notice is retained within any copies of the code.
# 3. Clear attribution is provided to the University of California, Berkeley, which includes a 
#    link to the official website http://ai.berkeley.edu.
# 
# Attribution Information:
# The Pacman AI projects were developed by the University of California, Berkeley. The 
# core components of the projects, including foundational code and autograding scripts, 
# were primarily created by the following individuals:
# - John DeNero (denero@cs.berkeley.edu)
# - Dan Klein (klein@cs.berkeley.edu)
# Student-side autograding functionalities were introduced by:
# - Brad Miller
# - Nick Hay
# - Pieter Abbeel (pabbeel@cs.berkeley.edu)
# 
# Constants:
# - STUDENT_CODE_DEFAULT: A string that specifies the default student code files. 
#   The default files included are 'searchAgents.py' and 'search.py'.
#   
# - PROJECT_TEST_CLASSES: A string that indicates the file name of the project test classes,
#   specifically 'searchTestClasses.py'.
# 
# - PROJECT_NAME: A string that denotes the title of the project, which is 'Project 1: Search'.
# 
# - BONUS_PIC: A boolean value that indicates whether to include a bonus picture; 
#   it is set to False by default.
# 
# End of documentation.
# """

STUDENT_CODE_DEFAULT = 'searchAgents.py,search.py'
PROJECT_TEST_CLASSES = 'searchTestClasses.py'
PROJECT_NAME = 'Project 1: Search'
BONUS_PIC = False
