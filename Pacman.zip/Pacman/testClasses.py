# This file, "testClasses.py," is part of an educational project developed at UC Berkeley focused on AI and related subjects. The file defines a series of classes that model questions and test cases for an automated grading system. The classes are intended for use in evaluating student submissions by executing various test cases and assigning points based on the results. 
# 
# The primary class is "Question," which serves as the foundation for various types of questions. It is designed to hold a maximum number of points and a list of test cases. The class can be extended to implement different grading strategies.
# 
# The "PassAllTestsQuestion" class extends the "Question" class and requires that all test cases be passed for the student to receive credit. The "ExtraCreditPassAllTestsQuestion" class adds an additional feature, allowing students to earn extra credit if they pass all tests.
# 
# The "HackedPartialCreditQuestion" class provides a mechanism for awarding partial credit based on a points system, where test cases can specify the number of points they are worth. The "Q6PartialCreditQuestion" and "PartialCreditQuestion" classes also allow for flexible grading with partial credit, but can fail the overall question if certain test cases do not pass. 
# 
# Finally, the "NumberPassedQuestion" class assigns a grade based on the number of test cases passed, providing another method for evaluating student performance.
# 
# The "TestCase" class is a template for creating specific test cases associated with the questions. Each test case can execute a predefined grading strategy and provide feedback messages indicating whether the test passed or failed. 
# 
# Key methods include:
# 
# - "raiseNotDefined()": Raises an error when a method has not been implemented, ensuring that subclasses provide necessary functionality.
# - "addTestCase(testCase, thunk)": Adds test cases to the question.
# - "execute(grades)": Executes the grading logic based on the specific question type.
# - "testPass(grades)" and "testFail(grades)": Record the state of test results and provide formatted messages for feedback.
# 
# The design aims to facilitate the automatic grading of programming assignments while providing transparent feedback to students about their performance on specific tests. The code adheres to the principles of clarity and simplicity, focusing on educational use and extensibility. 
# 
# Overall, "testClasses.py" serves as a critical component in a controlled grading environment, providing both structure and flexibility for evaluating student submissions in an academic setting.

import inspect
import re
import sys


class Question(object):

    def raiseNotDefined(self):
        """
Raises an error indicating that a method has not been implemented.

This method is intended to be called in subclasses to signal when a
particular method is required but has not yet been defined. It prints 
a message to the standard output identifying which method is missing 
its implementation and then terminates the program.

Parameters:
    None

Returns:
    None

Usage Example:
    class ExampleClass:
        def raiseNotDefined(self):
            print('Method not implemented: %s' % inspect.stack()[1][3])
            sys.exit(1)
        
        def someMethod(self):
            self.raiseNotDefined()  # This will call the method to indicate it's not implemented.
"""
        print('Method not implemented: %s' % inspect.stack()[1][3])
        sys.exit(1)

    def __init__(self, questionDict, display):
        """
Initializes a Question instance with the specified parameters.

This constructor method sets up a new Question object by initializing 
its maximum points, test cases, and display message based on the 
provided dictionary.

Parameters:
    questionDict (dict): A dictionary containing question metadata.
        It must include the key 'max_points' specifying the maximum
        points for this question.
    display (str): A string that represents the display message for 
        the question.

Returns:
    None

Usage Example:
    question_data = {'max_points': 10}
    display_message = 'Example Question'
    question = Question(question_data, display_message)
    print(question.getMaxPoints())  # Output: 10
    print(question.getDisplay())     # Output: Example Question
"""
        self.maxPoints = int(questionDict['max_points'])
        self.testCases = []
        self.display = display

    def getDisplay(self):
        """
Returns the display message associated with the Question.

This method retrieves the display message that describes the question,
which can be used for presenting the question to the user or for 
displaying in a user interface.

Parameters:
    None

Returns:
    str: The display message for the question.

Usage Example:
    question_data = {'max_points': 10}
    display_message = 'Example Question'
    question = Question(question_data, display_message)
    print(question.getDisplay())  # Output: Example Question
"""
        return self.display

    def getMaxPoints(self):
        """
Returns the maximum points that can be awarded for the Question.

This method provides access to the maximum points assigned to the 
question, which represents the highest score a student can achieve 
by successfully completing it.

Parameters:
    None

Returns:
    int: The maximum points that can be awarded for this question.

Usage Example:
    question_data = {'max_points': 10}
    display_message = 'Example Question'
    question = Question(question_data, display_message)
    print(question.getMaxPoints())  # Output: 10
"""
        return self.maxPoints

    def addTestCase(self, testCase, thunk):
        """
Adds a test case to the Question.

This method associates a test case with the current question and links 
it to a specific grading function (thunk) that will be executed during 
the grading process.

Parameters:
    testCase (TestCase): An instance of the TestCase class representing 
        the test to be added to the Question.
    thunk (function): A function that takes a grading object as an 
        argument. This function will be called to evaluate the test 
        case during execution.

Returns:
    None

Usage Example:
    question_data = {'max_points': 10}
    display_message = 'Example Question'
    question = Question(question_data, display_message)
    
    def sample_test(grades):
        # Evaluate some condition for the test case
        return True

    test_case = TestCase(question, {'path': 'path/to/test'})
    question.addTestCase(test_case, sample_test)
"""
        self.testCases.append((testCase, thunk))

    def execute(self, grades):
        """
Executes the grading logic for the Question.

This method is intended to evaluate all associated test cases and 
determine the result based on the specific grading strategy of 
the Question. It modifies the grades object based on whether the 
tests pass or fail.

Parameters:
    grades (Grades): An instance of the Grades class that manages 
        the scoring and messaging for the question. It is modified 
        according to the test results.

Returns:
    None

Usage Example:
    question_data = {'max_points': 10}
    display_message = 'Example Question'
    question = PassAllTestsQuestion(question_data, display_message)
    
    def sample_test(grades):
        # Evaluate some condition for the test case
        return True

    test_case = TestCase(question, {'path': 'path/to/test'})
    question.addTestCase(test_case, sample_test)
    
    question.execute(grades)  # Executes the grading logic and updates the grades object.
"""
        self.raiseNotDefined()


class PassAllTestsQuestion(Question):

    def execute(self, grades):
        """
Executes the grading logic for the Question.

This method evaluates all the associated test cases for the Question 
and updates the given grades object based on the results of the 
tests. The specific implementation of this method will vary depending 
on the type of Question, determining how points are awarded and 
whether to assign credit or failure.

Parameters:
    grades (Grades): An instance of the Grades class that is used to 
        track the scores and messages related to the question. The 
        grades object may be modified to reflect test outcomes.

Returns:
    None

Usage Example:
    question_data = {'max_points': 10}
    display_message = 'Example Question'
    question = HackedPartialCreditQuestion(question_data, display_message)
    
    def sample_test(grades):
        # Logic for the test case that returns True if the test passes
        return True

    test_case = TestCase(question, {'path': 'path/to/test'})
    question.addTestCase(test_case, sample_test)
    
    grades = Grades()  # Assuming Grades is initialized appropriately
    question.execute(grades)  # Executes the grading logic for the question.
"""
        testsFailed = False
        grades.assignZeroCredit()
        for _, f in self.testCases:
            if not f(grades):
                testsFailed = True
        if testsFailed:
            grades.fail('Tests failed.')
        else:
            grades.assignFullCredit()


class ExtraCreditPassAllTestsQuestion(Question):

    def __init__(self, questionDict, display):
        """
Initializes a TestCase instance with the specified parameters.

This constructor method sets up a new TestCase object by linking it
to a specific question and defining its properties based on the
provided test dictionary.

Parameters:
    question (Question): An instance of the Question class that 
        this test case is associated with.
    testDict (dict): A dictionary containing metadata for the test 
        case, which must include a 'path' key representing the 
        location or identifier of the test.

Returns:
    None

Usage Example:
    question_data = {'max_points': 10}
    display_message = 'Example Question'
    question = Question(question_data, display_message)

    test_case_data = {'path': 'path/to/test'}
    test_case = TestCase(question, test_case_data)
    print(test_case.getPath())  # Output: path/to/test
"""
        Question.__init__(self, questionDict, display)
        self.extraPoints = int(questionDict['extra_points'])

    def execute(self, grades):
        """
Executes the test case against the given grading context.

This method is intended to carry out the specific logic of the test 
case as defined in the subclass. It evaluates the test and updates 
the grades object accordingly, providing feedback on whether the test 
passed or failed.

Parameters:
    grades (Grades): An instance of the Grades class that is used to 
        capture the results of the test execution and to modify the 
        grading state based on the test outcome.
    moduleDict (dict): A dictionary representing the module 
        namespace that may be required for executing the test.
    solutionDict (dict): A dictionary representing the solution 
        namespace that may be referenced during the test execution.

Returns:
    None

Usage Example:
    class SampleTestCase(TestCase):
        def execute(self, grades, moduleDict, solutionDict):
            # Logic to evaluate the test case
            if some_condition:
                return self.testPass(grades)
            else:
                return self.testFail(grades)

    question_data = {'max_points': 10}
    display_message = 'Example Question'
    question = Question(question_data, display_message)

    test_case = SampleTestCase(question, {'path': 'path/to/test'})
    grades = Grades()  # Assuming Grades is appropriately defined
    test_case.execute(grades, {}, {})  # Executes the test case logic.
"""
        testsFailed = False
        grades.assignZeroCredit()
        for _, f in self.testCases:
            if not f(grades):
                testsFailed = True
        if testsFailed:
            grades.fail('Tests failed.')
        else:
            grades.assignFullCredit()
            grades.addPoints(self.extraPoints)


class HackedPartialCreditQuestion(Question):

    def execute(self, grades):
        """
Executes the grading logic for the test case.

This method is responsible for running the defined test case logic, 
evaluating the results against the specified grading criteria, and 
updating the provided grades object with the results of the test. 
The execution of the test may involve calling different methods to 
report passing or failing outcomes.

Parameters:
    grades (Grades): An instance of the Grades class that is used to 
        track the scoring and messaging related to the test case. 
        The method will modify this object based on the test result.
    moduleDict (dict): A dictionary representing the module 
        namespace, potentially required for executing the logic of 
        the test case.
    solutionDict (dict): A dictionary representing the correct 
        solutions or expected behavior that may be referenced during 
        the execution of the test case.

Returns:
    None

Usage Example:
    class CustomTestCase(TestCase):
        def execute(self, grades, moduleDict, solutionDict):
            # Custom logic for evaluating the test case
            if some_condition:
                return self.testPass(grades)
            else:
                return self.testFail(grades)

    question_data = {'max_points': 10}
    display_message = 'Sample Question'
    question = Question(question_data, display_message)
    
    test_case = CustomTestCase(question, {'path': 'path/to/test'})
    grades = Grades()  # Assuming Grades is correctly initialized
    test_case.execute(grades, {}, {})  # Executes the test logic.
"""
        grades.assignZeroCredit()
        points = 0
        passed = True
        for testCase, f in self.testCases:
            testResult = f(grades)
            if 'points' in testCase.testDict:
                if testResult:
                    points += float(testCase.testDict['points'])
            else:
                passed = passed and testResult
        if int(points) == self.maxPoints and not passed:
            grades.assignZeroCredit()
        else:
            grades.addPoints(int(points))


class Q6PartialCreditQuestion(Question):
    """Fails any test which returns False, otherwise doesn't effect the grades object.
    Partial credit tests will add the required points."""

    def execute(self, grades):
        """
Executes the grading logic for the question.

This method evaluates all the associated test cases for the Question and 
determines the results based on the specific grading strategy of the Question. 
It updates the provided grades object according to whether the tests pass or fail.

Parameters:
    grades (Grades): An instance of the Grades class that is used to 
        manage the scoring and messaging related to the question. 
        This object is modified to reflect the outcomes of the test cases.

Returns:
    None

Usage Example:
    question_data = {'max_points': 10}
    display_message = 'Example Question'
    question = PassAllTestsQuestion(question_data, display_message)

    def sample_test(grades):
        # Logic for the test case that returns True if the test passes
        return True

    test_case = TestCase(question, {'path': 'path/to/test'})
    question.addTestCase(test_case, sample_test)

    grades = Grades()  # Assuming Grades is initialized appropriately
    question.execute(grades)  # Executes the grading logic for the question.
"""
        grades.assignZeroCredit()
        results = []
        for _, f in self.testCases:
            results.append(f(grades))
        if False in results:
            grades.assignZeroCredit()


class PartialCreditQuestion(Question):
    """Fails any test which returns False, otherwise doesn't effect the grades object.
    Partial credit tests will add the required points."""

    def execute(self, grades):
        """
Evaluates all test cases for the question and updates the grades accordingly.

This method runs the test cases associated with the question and 
determines whether they pass or fail. Based on the results, it 
modifies the grades object to reflect the outcomes, such as 
assigning full credit, partial credit, or failing the question.

Parameters:
    grades (Grades): An instance of the Grades class that tracks 
        the score and messages for the question. It is updated 
        based on the results of the executed test cases.

Returns:
    None

Usage Example:
    question_data = {'max_points': 10}
    display_message = 'Sample Question'
    question = PassAllTestsQuestion(question_data, display_message)

    def sample_test(grades):
        # Example logic for the test case
        return True  # Pass the test

    test_case = TestCase(question, {'path': 'path/to/test'})
    question.addTestCase(test_case, sample_test)

    grades = Grades()  # Initialize the grades object
    question.execute(grades)  # Execute the grading logic for the question.
"""
        grades.assignZeroCredit()
        for _, f in self.testCases:
            if not f(grades):
                grades.assignZeroCredit()
                grades.fail('Tests failed.')
                return False


class NumberPassedQuestion(Question):
    """Grade is the number of test cases passed."""

    def execute(self, grades):
        """
Executes the test case logic and updates the grading results.

This method is intended to carry out the specific evaluation of the 
test case, determining if it passes or fails based on the test logic 
defined in the subclass. It updates the provided grades object to 
reflect the test outcome.

Parameters:
    grades (Grades): An instance of the Grades class that tracks the 
        scores and messages associated with the test case. The 
        grading results will be modified according to the test 
        results.
    moduleDict (dict): A dictionary representing the namespace of 
        modules that may be required for executing the test case 
        logic.
    solutionDict (dict): A dictionary representing the expected 
        solutions or references that may be needed during the test 
        case execution.

Returns:
    None

Usage Example:
    class ExampleTestCase(TestCase):
        def execute(self, grades, moduleDict, solutionDict):
            # Sample logic to evaluate the test case
            if some_condition:
                return self.testPass(grades)
            else:
                return self.testFail(grades)

    question_data = {'max_points': 10}
    display_message = 'Example Question'
    question = Question(question_data, display_message)

    test_case = ExampleTestCase(question, {'path': 'path/to/test'})
    grades = Grades()  # Assuming Grades is defined and initialized
    test_case.execute(grades, {}, {})  # Executes the test case logic.
"""
        grades.addPoints([f(grades) for _, f in self.testCases].count(True))


class TestCase(object):

    def raiseNotDefined(self):
        """
Raises an error indicating that a method has not been implemented.

This utility method is intended to be called in subclasses to 
signal that a certain method, which is expected to be defined, has 
not yet been implemented. It prints a message to the standard output 
specifying which method is missing and then terminates the program.

Parameters:
    None

Returns:
    None

Usage Example:
    class MyClass:
        def raiseNotDefined(self):
            print('Method not implemented: %s' % inspect.stack()[1][3])
            sys.exit(1)

        def someMethod(self):
            self.raiseNotDefined()  # This will indicate that 'someMethod' needs to be implemented.
"""
        print('Method not implemented: %s' % inspect.stack()[1][3])
        sys.exit(1)

    def getPath(self):
        """
Returns the path associated with the test case.

This method retrieves the file path or identifier for the test case,
which is used to reference the specific test being executed. It is 
essential for organizing and managing test cases within the grading 
framework.

Parameters:
    None

Returns:
    str: The path associated with the test case.

Usage Example:
    test_case_data = {'path': 'path/to/test'}
    test_case = TestCase(question, test_case_data)
    print(test_case.getPath())  # Output: path/to/test
"""
        return self.path

    def __init__(self, question, testDict):
        """
Initializes a TestCase instance with the specified parameters.

This constructor method sets up a new TestCase object by linking it 
to a specific question and defining its properties based on the 
provided test dictionary.

Parameters:
    question (Question): An instance of the Question class that 
        this test case is associated with.
    testDict (dict): A dictionary containing metadata for the test 
        case, which must include a 'path' key representing the 
        location or identifier of the test.

Returns:
    None

Usage Example:
    question_data = {'max_points': 10}
    display_message = 'Example Question'
    question = Question(question_data, display_message)

    test_case_data = {'path': 'path/to/test'}
    test_case = TestCase(question, test_case_data)
    print(test_case.getPath())  # Output: path/to/test
"""
        self.question = question
        self.testDict = testDict
        self.path = testDict['path']
        self.messages = []

    def __str__(self):
        """
Returns a string representation of the TestCase.

This method is intended to provide a human-readable representation 
of the TestCase object, which could be useful for debugging, logging, 
or displaying information about the test case in a user interface. 
The exact format of the string representation should be defined in 
the subclass implementation.

Parameters:
    None

Returns:
    str: A string representation of the TestCase.

Usage Example:
    class CustomTestCase(TestCase):
        def __str__(self):
            return f'TestCase for question: {self.question.getDisplay()}, path: {self.path}'

    question_data = {'max_points': 10}
    display_message = 'Example Question'
    question = Question(question_data, display_message)

    test_case = CustomTestCase(question, {'path': 'path/to/test'})
    print(test_case)  # Output: TestCase for question: Example Question, path: path/to/test
"""
        self.raiseNotDefined()

    def execute(self, grades, moduleDict, solutionDict):
        """
Executes the test case logic and updates the grading results.

This method is responsible for carrying out the defined test case logic,
evaluating the results based on specific conditions, and updating the 
provided grades object to reflect whether the test passed or failed. 
The implementation should be defined in the subclass, where the actual 
test evaluation will be executed.

Parameters:
    grades (Grades): An instance of the Grades class that is used to 
        capture the results of the test execution and modify the 
        grading state based on the test outcome.
    moduleDict (dict): A dictionary representing the module 
        namespace that may be required for executing the test case.
    solutionDict (dict): A dictionary representing the solution 
        namespace that may be referenced during the test execution.

Returns:
    None

Usage Example:
    class CustomTestCase(TestCase):
        def execute(self, grades, moduleDict, solutionDict):
            # Logic to evaluate the test case
            if some_condition:
                return self.testPass(grades)
            else:
                return self.testFail(grades)

    question_data = {'max_points': 10}
    display_message = 'Sample Question'
    question = Question(question_data, display_message)

    test_case = CustomTestCase(question, {'path': 'path/to/test'})
    grades = Grades()  # Assuming Grades is initialized appropriately
    test_case.execute(grades, {}, {})  # Executes the test case logic.
"""
        self.raiseNotDefined()

    def writeSolution(self, moduleDict, filePath):
        """
Writes the solution for the test case to the specified file path.

This method is intended to save the solution corresponding to the 
test case in a file identified by the provided file path. The 
exact implementation and format of the solution writing should be 
defined in the subclass.

Parameters:
    moduleDict (dict): A dictionary representing the module 
        namespace that may be utilized to access necessary 
        information for writing the solution.
    filePath (str): The path to the file where the solution should 
        be written.

Returns:
    bool: True if the solution was successfully written to the file; 
        False otherwise.

Usage Example:
    class CustomTestCase(TestCase):
        def writeSolution(self, moduleDict, filePath):
            with open(filePath, 'w') as f:
                f.write('Solution content')
            return True

    question_data = {'max_points': 10}
    display_message = 'Example Question'
    question = Question(question_data, display_message)

    test_case = CustomTestCase(question, {'path': 'path/to/test'})
    success = test_case.writeSolution({}, 'path/to/solution.txt')  # Output: True if writing was successful
"""
        self.raiseNotDefined()
        return True

    def testPass(self, grades):
        """
Records a passing result for the test case and updates the grades accordingly.

This method updates the grades object to reflect that the test case 
has passed, adding an appropriate message to the grading output. 
It may also include additional messages that were recorded during 
the execution of the test case.

Parameters:
    grades (Grades): An instance of the Grades class that is used to 
        update the scoring and messaging for the test case. The 
        method modifies this object based on the passing outcome.

Returns:
    bool: True if the test case passed successfully; otherwise, False.

Usage Example:
    class CustomTestCase(TestCase):
        def execute(self, grades, moduleDict, solutionDict):
            if some_condition:
                return self.testPass(grades)
            else:
                return self.testFail(grades)

    question_data = {'max_points': 10}
    display_message = 'Sample Question'
    question = Question(question_data, display_message)

    test_case = CustomTestCase(question, {'path': 'path/to/test'})
    grades = Grades()  # Initialize the grades object
    test_case.execute(grades, {}, {})  # Executes the test
"""
        grades.addMessage('PASS: %s' % (self.path,))
        for line in self.messages:
            grades.addMessage('    %s' % (line,))
        return True

    def testFail(self, grades):
        """
Records a failing result for the test case and updates the grades accordingly.

This method updates the grades object to reflect that the test case 
has failed. It adds an appropriate failure message to the grading 
output, which can help in debugging and provides feedback on 
the specific reason for the failure.

Parameters:
    grades (Grades): An instance of the Grades class that is used to 
        update the scoring and messaging for the test case. The 
        method modifies this object based on the failing outcome.

Returns:
    bool: False, indicating that the test case did not pass.

Usage Example:
    class CustomTestCase(TestCase):
        def execute(self, grades, moduleDict, solutionDict):
            if not some_condition:
                return self.testFail(grades)
            else:
                return self.testPass(grades)

    question_data = {'max_points': 10}
    display_message = 'Sample Question'
    question = Question(question_data, display_message)

    test_case = CustomTestCase(question, {'path': 'path/to/test'})
    grades = Grades()  # Initialize the grades object
    result = test_case.execute(grades, {}, {})  # Executes the test
    print(result)  # Output: False if the test case has failed
"""
        grades.addMessage('FAIL: %s' % (self.path,))
        for line in self.messages:
            grades.addMessage('    %s' % (line,))
        return False

    def testPartial(self, grades, points, maxPoints):
        """
Records a partial result for the test case and updates the grades accordingly.

This method handles the evaluation of test cases that award partial 
credit. It updates the grades object with the points earned based 
on the test outcome and provides detailed feedback, including any 
extra credit earned.

Parameters:
    grades (Grades): An instance of the Grades class that is used to 
        capture the scores and messages associated with the test case. 
        This object is modified to reflect the points awarded for 
        the partial success of the test.

    points (int or float): The number of points awarded for the 
        successful execution of the test case.

    maxPoints (int or float): The maximum number of points that can 
        be awarded for the test case, used to determine the extent of 
        the partial credit.

Returns:
    bool: True, indicating that the test case has recorded a partial 
        success.

Usage Example:
    class CustomTestCase(TestCase):
        def execute(self, grades, moduleDict, solutionDict):
            if some_condition:
                return self.testPartial(grades, 5, 10)  # Award 5 out of 10 points
            else:
                return self.testFail(grades)

    question_data = {'max_points': 10}
    display_message = 'Sample Question'
    question = Question(question_data, display_message)

    test_case = CustomTestCase(question, {'path': 'path/to/test'})
    grades = Grades()  # Initialize the grades object
    result = test_case.execute(grades, {}, {})  # Executes the test
    print(result)  # Output: True if the test case recorded partial credit
"""
        grades.addPoints(points)
        extraCredit = max(0, points - maxPoints)
        regularCredit = points - extraCredit
        grades.addMessage('%s: %s (%s of %s points)' % ('PASS' if points >=
            maxPoints else 'FAIL', self.path, regularCredit, maxPoints))
        if extraCredit > 0:
            grades.addMessage('EXTRA CREDIT: %s points' % (extraCredit,))
        for line in self.messages:
            grades.addMessage('    %s' % (line,))
        return True

    def addMessage(self, message):
        """
Adds a message to the list of messages associated with the test case.

This method takes a message string, splits it by new lines, and 
appends each line to the internal message list for the test case. 
This is used to collect feedback and results during the execution 
of the test, which can later be reported to the user.

Parameters:
    message (str): A string containing the message to be added. 
        This can include multiple lines of text, which will be split 
        and added individually to the message list.

Returns:
    None

Usage Example:
    test_case = TestCase(question, {'path': 'path/to/test'})
    test_case.addMessage("Test executed successfully.\\nAdditional info.")
    print(test_case.messages)  # Output: ['Test executed successfully.', 'Additional info.']
"""
        self.messages.extend(message.split('\n'))
