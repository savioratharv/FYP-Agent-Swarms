# """
# Pacman Eight Puzzle Module
# 
# This module implements an eight puzzle game consisting of a 3x3 grid 
# where one of the positions is empty (denoted by 0). The goal of the 
# puzzle is to arrange the tiles in ascending order by sliding them 
# into the empty space.
# 
# Classes:
# --------
# 1. EightPuzzleState
#    This class represents the state of the eight puzzle, including the 
#    mechanics of the puzzle such as movement of tiles, checking goal 
#    state, and generating legal moves.
# 
#    Methods:
#    - __init__(self, numbers): Initializes the eight puzzle with a 
#      given configuration of numbers.
#    - isGoal(self): Checks if the current configuration matches the 
#      goal state of the puzzle.
#    - legalMoves(self): Returns a list of legal moves available from 
#      the current state.
#    - result(self, move): Returns a new instance of EightPuzzleState 
#      that results from applying the specified move to the current 
#      state.
#    - __eq__(self, other): Compares two EightPuzzleState objects for 
#      equality.
#    - __hash__(self): Returns the hash value of the puzzle state.
#    - __str__(self): Returns a string representation of the puzzle 
#      suitable for display.
# 
# 2. EightPuzzleSearchProblem (search.SearchProblem)
#    This class extends the SearchProblem class to represent the search 
#    problem associated with the eight puzzle.
# 
#    Methods:
#    - __init__(self, puzzle): Initializes the search problem with a 
#      given starting puzzle state.
#    - getStartState(self): Returns the starting state of the search 
#      problem.
#    - isGoalState(self, state): Checks if a given state is the goal 
#      state.
#    - getSuccessors(self, state): Returns a list of valid successor 
#      states along with the corresponding actions and costs.
#    - getCostOfActions(self, actions): Returns the total cost associated 
#      with a list of actions.
# 
# Functions:
# ----------
# 1. loadEightPuzzle(puzzleNumber): 
#    Loads and returns an EightPuzzleState object for a specified 
#    configuration of the eight puzzle from pre-defined data.
# 
# 2. createRandomEightPuzzle(moves=100): 
#    Generates and returns a random eight puzzle by applying a specified 
#    number of random legal moves to a solved puzzle.
# 
# The module concludes with a main block that demonstrates the usage of 
# the EightPuzzleState and EightPuzzleSearchProblem classes by creating 
# a random puzzle, solving it using breadth-first search, and displaying 
# the solution step-by-step.
# """

import search
import random


class EightPuzzleState:
    """
    The Eight Puzzle is described in the course textbook on
    page 64.

    This class defines the mechanics of the puzzle itself.  The
    task of recasting this puzzle as a search problem is left to
    the EightPuzzleSearchProblem class.
    """

    def __init__(self, numbers):
        """
          Constructs a new eight puzzle from an ordering of numbers.

        numbers: a list of integers from 0 to 8 representing an
          instance of the eight puzzle.  0 represents the blank
          space.  Thus, the list

            [1, 0, 2, 3, 4, 5, 6, 7, 8]

          represents the eight puzzle:
            -------------
            | 1 |   | 2 |
            -------------
            | 3 | 4 | 5 |
            -------------
            | 6 | 7 | 8 |
            ------------

        The configuration of the puzzle is stored in a 2-dimensional
        list (a list of lists) 'cells'.
        """
        self.cells = []
        numbers = numbers[:]
        numbers.reverse()
        for row in range(3):
            self.cells.append([])
            for col in range(3):
                self.cells[row].append(numbers.pop())
                if self.cells[row][col] == 0:
                    self.blankLocation = row, col

    def isGoal(self):
        """
          Checks to see if the puzzle is in its goal state.

            -------------
            |   | 1 | 2 |
            -------------
            | 3 | 4 | 5 |
            -------------
            | 6 | 7 | 8 |
            -------------

        >>> EightPuzzleState([0, 1, 2, 3, 4, 5, 6, 7, 8]).isGoal()
        True

        >>> EightPuzzleState([1, 0, 2, 3, 4, 5, 6, 7, 8]).isGoal()
        False
        """
        current = 0
        for row in range(3):
            for col in range(3):
                if current != self.cells[row][col]:
                    return False
                current += 1
        return True

    def legalMoves(self):
        """
          Returns a list of legal moves from the current state.

        Moves consist of moving the blank space up, down, left or right.
        These are encoded as 'up', 'down', 'left' and 'right' respectively.

        >>> EightPuzzleState([0, 1, 2, 3, 4, 5, 6, 7, 8]).legalMoves()
        ['down', 'right']
        """
        moves = []
        row, col = self.blankLocation
        if row != 0:
            moves.append('up')
        if row != 2:
            moves.append('down')
        if col != 0:
            moves.append('left')
        if col != 2:
            moves.append('right')
        return moves

    def result(self, move):
        """
          Returns a new eightPuzzle with the current state and blankLocation
        updated based on the provided move.

        The move should be a string drawn from a list returned by legalMoves.
        Illegal moves will raise an exception, which may be an array bounds
        exception.

        NOTE: This function *does not* change the current object.  Instead,
        it returns a new object.
        """
        row, col = self.blankLocation
        if move == 'up':
            newrow = row - 1
            newcol = col
        elif move == 'down':
            newrow = row + 1
            newcol = col
        elif move == 'left':
            newrow = row
            newcol = col - 1
        elif move == 'right':
            newrow = row
            newcol = col + 1
        else:
            raise 'Illegal Move'
        newPuzzle = EightPuzzleState([0, 0, 0, 0, 0, 0, 0, 0, 0])
        newPuzzle.cells = [values[:] for values in self.cells]
        newPuzzle.cells[row][col] = self.cells[newrow][newcol]
        newPuzzle.cells[newrow][newcol] = self.cells[row][col]
        newPuzzle.blankLocation = newrow, newcol
        return newPuzzle

    def __eq__(self, other):
        """
            Overloads '==' such that two eightPuzzles with the same configuration
          are equal.

          >>> EightPuzzleState([0, 1, 2, 3, 4, 5, 6, 7, 8]) ==               EightPuzzleState([1, 0, 2, 3, 4, 5, 6, 7, 8]).result('left')
          True
        """
        for row in range(3):
            if self.cells[row] != other.cells[row]:
                return False
        return True

    def __hash__(self):
        """
Returns the hash value of the current EightPuzzleState instance.

This method overrides the built-in __hash__ method to provide a 
hash value based on the configuration of the puzzle's cells. This 
is particularly useful for storing puzzle states in data structures 
such as sets or dictionaries where uniqueness is determined by the 
hash value.

Parameters:
-----------
None

Returns:
--------
int: A hash value representing the unique configuration of the 
     puzzle state.

Usage Example:
--------------
>>> puzzle = EightPuzzleState([0, 1, 2, 3, 4, 5, 6, 7, 8])
>>> hash_value = hash(puzzle)
>>> print(hash_value)
"""
        return hash(str(self.cells))

    def __getAsciiString(self):
        """
          Returns a display string for the maze
        """
        lines = []
        horizontalLine = '-' * 13
        lines.append(horizontalLine)
        for row in self.cells:
            rowLine = '|'
            for col in row:
                if col == 0:
                    col = ' '
                rowLine = rowLine + ' ' + col.__str__() + ' |'
            lines.append(rowLine)
            lines.append(horizontalLine)
        return '\n'.join(lines)

    def __str__(self):
        """
Returns a string representation of the EightPuzzleState instance.

This method provides a visual representation of the eight puzzle 
grid in a human-readable format. The grid is displayed with 
rows and columns, and the empty space is represented by a blank 
space (instead of the number 0).

Parameters:
-----------
None

Returns:
--------
str: A formatted string that illustrates the current state of 
     the puzzle.

Usage Example:
--------------
>>> puzzle = EightPuzzleState([1, 0, 2, 3, 4, 5, 6, 7, 8])
>>> print(puzzle)
-------------
| 1 |   | 2 |
-------------
| 3 | 4 | 5 |
-------------
| 6 | 7 | 8 |
-------------
"""
        return self.__getAsciiString()


class EightPuzzleSearchProblem(search.SearchProblem):
    """
      Implementation of a SearchProblem for the  Eight Puzzle domain

      Each state is represented by an instance of an eightPuzzle.
    """

    def __init__(self, puzzle):
        """Creates a new EightPuzzleSearchProblem which stores search information."""
        self.puzzle = puzzle

    def getStartState(self):
        """
Returns the starting state of the EightPuzzleSearchProblem.

This method retrieves the initial configuration of the eight puzzle 
which serves as the starting point for the search algorithm. The 
returned state is an instance of the EightPuzzleState class.

Parameters:
-----------
None

Returns:
--------
EightPuzzleState: The initial state of the eight puzzle from which 
                  the search problem begins.

Usage Example:
--------------
>>> puzzle = EightPuzzleState([1, 2, 3, 0, 4, 5, 6, 7, 8])
>>> problem = EightPuzzleSearchProblem(puzzle)
>>> start_state = problem.getStartState()
>>> print(start_state)
-------------
| 1 | 2 | 3 |
-------------
|   | 4 | 5 |
-------------
| 6 | 7 | 8 |
-------------
"""
        return puzzle

    def isGoalState(self, state):
        """
Checks if the given state is the goal state of the eight puzzle.

This method determines whether the current configuration of the 
eight puzzle matches the predefined goal state. The goal state is 
the arrangement where the numbers are in ascending order, with the 
blank space located at the top-left corner.

Parameters:
-----------
state (EightPuzzleState): The state of the puzzle to be checked 
                           against the goal state.

Returns:
--------
bool: True if the state matches the goal configuration, otherwise 
      False.

Usage Example:
--------------
>>> puzzle = EightPuzzleState([1, 2, 3, 4, 5, 6, 7, 8, 0])
>>> problem = EightPuzzleSearchProblem(puzzle)
>>> is_goal = problem.isGoalState(puzzle)
>>> print(is_goal)
True
"""
        return state.isGoal()

    def getSuccessors(self, state):
        """
          Returns list of (successor, action, stepCost) pairs where
          each succesor is either left, right, up, or down
          from the original state and the cost is 1.0 for each
        """
        succ = []
        for a in state.legalMoves():
            succ.append((state.result(a), a, 1))
        return succ

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.  The sequence must
        be composed of legal moves
        """
        return len(actions)


EIGHT_PUZZLE_DATA = [[1, 0, 2, 3, 4, 5, 6, 7, 8], [1, 7, 8, 2, 3, 4, 5, 6, 
    0], [4, 3, 2, 7, 0, 5, 1, 6, 8], [5, 1, 3, 4, 0, 2, 6, 7, 8], [1, 2, 5,
    7, 6, 8, 0, 4, 3], [0, 3, 1, 6, 8, 2, 7, 5, 4]]


def loadEightPuzzle(puzzleNumber):
    """
      puzzleNumber: The number of the eight puzzle to load.

      Returns an eight puzzle object generated from one of the
      provided puzzles in EIGHT_PUZZLE_DATA.

      puzzleNumber can range from 0 to 5.

      >>> print(loadEightPuzzle(0))
      -------------
      | 1 |   | 2 |
      -------------
      | 3 | 4 | 5 |
      -------------
      | 6 | 7 | 8 |
      -------------
    """
    return EightPuzzleState(EIGHT_PUZZLE_DATA[puzzleNumber])


def createRandomEightPuzzle(moves=100):
    """
      moves: number of random moves to apply

      Creates a random eight puzzle by applying
      a series of 'moves' random moves to a solved
      puzzle.
    """
    puzzle = EightPuzzleState([0, 1, 2, 3, 4, 5, 6, 7, 8])
    for i in range(moves):
        puzzle = puzzle.result(random.sample(puzzle.legalMoves(), 1)[0])
    return puzzle


if __name__ == '__main__':
    puzzle = createRandomEightPuzzle(25)
    print('A random puzzle:')
    print(puzzle)
    problem = EightPuzzleSearchProblem(puzzle)
    path = search.breadthFirstSearch(problem)
    print('BFS found a path of %d moves: %s' % (len(path), str(path)))
    curr = puzzle
    i = 1
    for a in path:
        curr = curr.result(a)
        print('After %d move%s: %s' % (i, ('', 's')[i > 1], a))
        print(curr)
        input('Press return for the next state...')
        i += 1
